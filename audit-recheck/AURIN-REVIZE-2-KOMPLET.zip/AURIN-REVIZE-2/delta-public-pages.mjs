// Runs the original current public-page functions and the exact early GET/HEAD
// branch extracted from entrypoint.js. This is not the full Worker bootstrap.
import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import * as pages from '/workspace/health-api-recheck/src/site-pages.js';

const src=readFileSync('/workspace/health-api-recheck/src/entrypoint.js','utf8');
const route=src.match(/async function staticRoute\(url, request, env\) \{[\s\S]*?\n\}/)[0];
const branch=src.match(/if \(STATIC_PATHS\.has\(url\.pathname\) && \(request\.method === 'GET' \|\| request\.method === 'HEAD'\)\) \{[\s\S]*?\n    \}/)[0];
const names=['overviewPage','privacyPage','termsPage','supportPage','robotsTxt','sitemapXml'];
const make=new Function(...names,'emailConfigured','openSignup',`${route}\nreturn async function(request){const url=new URL(request.url),env={},STATIC_PATHS=new Set(['/','/privacy','/terms','/support','/robots.txt','/sitemap.xml']);${branch}};`);
const invoke=make(...names.map(name=>pages[name]),()=>false,()=>false);
const results=[];
for(const path of ['/','/privacy','/terms','/support','/robots.txt','/sitemap.xml']){
 const get=await invoke(new Request('https://aurin.health'+path));
 const head=await invoke(new Request('https://aurin.health'+path,{method:'HEAD'}));
 assert.equal(get.status,200);assert.equal(head.status,200);
 assert.equal(get.headers.get('content-type'),head.headers.get('content-type'));
 assert.equal(await head.text(),'');assert.ok((await get.text()).length>0);
 results.push({path,get:200,head:200,headBodyEmpty:true,contentType:head.headers.get('content-type')});
}
const html=await pages.overviewPage(new Request('https://aurin.health/')).text();
const ld=JSON.parse(html.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1]);
assert.equal(ld['@graph'][0].url,'https://aurin.health');
assert.equal(ld['@graph'][0].offers.description,'Free test version in TestFlight');
assert.ok(html.includes('<meta name="twitter:card" content="summary_large_image">'));
assert.ok(!html.includes('Free AI coach for iPhone'));
const out={reviewed_commit:'775c79b1432d743a1d503f803214dda348f555ed',routeChecks:results,structuredData:true,linkPreviewMetadata:true,limits:'Original early branch and staticRoute only; email/open-signup configuration locally false; no full Worker/import of private prompts, external crawler or production request.'};
writeFileSync('/workspace/aurin-reaudit-2026-10-20/delta-public-pages.json',JSON.stringify(out,null,2));
console.log(JSON.stringify(out));
