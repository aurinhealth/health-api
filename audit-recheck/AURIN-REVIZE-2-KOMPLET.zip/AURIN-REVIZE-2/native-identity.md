# Nativní identita a HealthKit — opakovaná revize

Aktuální commit: `74a459d0f99fa6503e4e37035777915921427a06`. Původní: `02d575e570a179a5c156bcc9708877a2c18f3de8`. Aplikační soubory nebyly změněny.

**Stav přidělených původních nálezů:** A01 opraveno pro původní změnu účtu na stejném serveru; A02 částečně; A10 částečně; A11 částečně; A12 opraveno. Dva nové konkrétní nálezy jsou popsány samostatně. Nově nalezený neznamená nově zavedený.

## A01: fixed — Hlavní HealthKit import nepokračuje po změně účtu

**Místo:** ios-native/Loadwise/App/AppleHealth.swift:338

**Důkaz opravy:** Původní AppleHealth.perform nyní před každým uploadem kontroluje generaci, enabled a accountUnconfirmed (338). signedIn nejprve získá /me (AppModel375–377); při neznámé identitě zůstává accountUnchecked (374,390–391), při jiném účtu checkAccount zavolá pause (410), které přes disconnect zvýší generation (AppleHealth206). I collect zahájený před změnou účtu tedy přes toto místo pokračovat nemůže.

**Co zbývá:** Opraven je konkrétní původní tok AppleHealth.run/reader.collect. Samostatný importér CycleHealth tento mechanismus nepoužívá a je veden jako nový nález N-NATIVE-CYCLE, nikoli jako druhé započítání A01. Přepnutí live/staging zůstává výslovně navržené jako přenos stejného device-level zapnutí do zvoleného serveru (AppModel1417–1419); status fixed se vztahuje na původní změnu účtu při přihlášení na stejném serveru, nikoli na důkaz per-server vlastnictví oprávnění.

**Oprava:** Původní oprava je ve zdroji přítomná; přidat runtime regresi generace během zadrženého collect a aplikovat společnou identitu i na další importéry.

**Akceptace:** A→401→B: nový i rozpracovaný hlavní AppleHealth import neodešle data pod B; opakovat při neúspěšném /me.

**Ověření:** Statická analýza změny i volajících; iOS/HealthKit runtime nebyl dostupný.

## A02: partial — Nový vstup do outboxu je chráněný, již běžící smyčka může přejít na nový účet

**Místo:** ios-native/Loadwise/App/AppModel.swift:862

**Důkaz opravy:** Nový sendOutbox vstup hlídá accountUnconfirmed (834) a signedIn ověřuje /me před prvním zveřejněním phase (375–377). Položky mají owner ID a smyčka kontroluje isOthers (863). Již běžící sendWaiting ale po await api.sendQueued znovu nekontroluje phase/accountUnconfirmed/generaci; porovnává jen staré uložené ID, které se mění až po novém /me.

**Co zbývá:** Zadržet úspěšnou odpověď A1. Souběžný jiný požadavek dostane401, clearLocal(expired:true) zachová A2 i identitu A. Přihlášení B nastaví cookie B a accountUnchecked=true, /me B je zadržené. Uvolněná A1 nechá starou smyčku přejít k A2; owner A souhlasí se stále uloženým ID A, takže api.sendQueued odešle A2 s cookie B. APIClient používá sdílené aktuální cookies (54–61,642–647).

**Oprava:** Každému odesílacímu běhu přidělit snapshot account+server+session generation; při změně identity běh zastavit a před KAŽDÝM dalším odesláním ověřit aktuální generaci i potvrzenou identitu. Nestačí hlídat jen vstup sendOutbox.

**Akceptace:** Zadržet A1 odpověď a B /me, vyvolat expiraci A a B login; A2 nesmí být odeslána pod B. Ověřit i přepnutí serveru a legacy položky bez owner.

**Ověření:** Staticky dosažitelný asynchronní tok; skutečný iOS běh nebyl proveden. Přepnutí serveru samo frontu explicitně maže (1426–1427), takže pouhá shoda číselných UID nebyla vydávána za samostatný důkaz odeslání fronty.

## A10: partial — Odhlášení cyklus vyčistí, ale pozdní odpověď ho může obnovit pod dalším účtem

**Místo:** ios-native/Loadwise/App/AppModel+Cycle.swift:9

**Důkaz opravy:** Nový forgetAccountData nastaví cycle=nil, cycleHealthSynced=false, odstraní pill a export (AppModel415–419), volá se při běžném logoutu (1447) i zjištěném jiném účtu (411). loadCycle však po await api.cycle bez kontroly vlastníka/generace přiřadí cycle a uloží pill nastavení (9–14).

**Co zbývá:** A spustí obnovení Dnes; refresh(announce:true) vytváří samostatný Task (AppModel456), který může čekat na loadCycle (494–498). A se odhlásí a B přihlásí. clearLocal běžící announcedRefresh neruší a loadCycle pozdní odpověď A přijme, takže B znovu vidí A cyklus a ukládají se A pill preference. HealthView při nenil cycle počáteční načtení přeskočí (93). Další cesta bez závodu, omezená na interní testery: live A a staging B mají stejné číselné UID, ale jiný e-mail. switchServer použije clearLocal(expired:true), a anotherAccount426–429 shodu ID přijme jako stejný účet bez serverového namespace; cycle ani pill se nevymažou.

**Oprava:** Zavést account+server/session generation na čtení i zápis cyklu a zkontrolovat ho po každém await před změnou modelu, lokálních nastavení nebo voláním CycleHealth. Při změně identity rušit staré obnovení.

**Akceptace:** Zadržet A /cycle v obnovení Dnes, logout A, login B, uvolnit odpověď: B nevidí A cycle, nevzniknou A připomínky a pozdní odpověď nezahájí import.

**Ověření:** Statická analýza celého volajícího toku včetně samostatného announcedRefresh Task; iOS runtime nebyl dostupný.

## A11: partial — Export se při potvrzené změně účtu resetuje, ale během nepotvrzené identity může použít staré preference

**Místo:** ios-native/Loadwise/App/AppModel.swift:713

**Důkaz opravy:** AppleHealthExport.reset nově odstraní prefs i written ledger (47–50) a forgetAccountData ho při běžném logoutu/jiném účtu volá. Při expired:true se export zachovává. Pokud B /me selže, signedIn přesto nastaví phase.signedIn (377) a retry loadAccountInitial čeká; accountUnconfirmed hlídá import/outbox, nikoli refreshFood nebo saveFoodDay. refreshFood spustí export snapshotu B na713 se stále platnými globálními prefs A.

**Co zbývá:** A má povolený export výživy/vody, jeho session vyprší. B se přihlásí; první /me selže a druhé je pomalé. B otevře Jídlo a jeho /food-today uspěje dřív než ověření identity. Export použije A preference, i když B má export vypnutý. Samostatný export neobsahuje účet ani accountUnconfirmed guard (AppleHealthExport215–217). Další cesta bez selhání /me, omezená na interní testery: live A a staging B mají stejné numerické UID a odlišný e-mail. switchServer uchová export a anotherAccount kvůli shodě ID reset přeskočí; následný Food export B použije A prefs. Account ID je unikátní jen v rámci serveru.

**Oprava:** Do potvrzení identity blokovat veškeré automatické HealthKit exporty, ne jen import/outbox. Preference i ledger navázat na account+server a po await ověřovat generaci; serverové prefs B přijmout až pro potvrzeného vlastníka.

**Akceptace:** A export ON→expired→B, B /me selže/zůstane zadržený, B food uspěje: žádný export bez potvrzených B preferencí. Po B /me se musí použít B nastavení.

**Ověření:** Statický dosažitelný tok a původní kód exportu; nebylo prováděno skutečné HealthKit zapisování.

## A12: fixed — Vypnutí všech kategorií nyní zastavuje hlavní HealthKit import

**Místo:** ios-native/Loadwise/Screens/AppleHealthViews.swift:120

**Důkaz opravy:** Původní prázdný onChange guard je nahrazen health.disconnect (120–122). disconnect nastaví enabled=false, uloží ho, odstraní resume key, zastaví observers a zvýší generation (AppleHealth204–209); pending collect je blokovaný kontrolou338.

**Co zbývá:** Neprázdný předchozí výběr categories zůstává uložený, takže po znovuotevření stránky se mohou zobrazit staré zapnuté přepínače, přestože enabled=false a čtení je vypnuté. Jde o návaznou UX nepřesnost, nikoli pokračování původního uploadu při všech OFF.

**Oprava:** Původní oprava zastavení je ve zdroji. Pro konzistentní nastavení ukládat i skutečný prázdný výběr, odlišit ho od prvního spuštění a otestovat znovuotevření.

**Akceptace:** Všechno OFF zastaví běžný i rozpracovaný hlavní import, po relaunchi čtení zůstane OFF a nastavení ukazuje odpovídající výběr.

**Ověření:** Statická analýza onChange/disconnect/perform; neproběhl runtime test s iOS oprávněními.

## N-NATIVE-CYCLE · P1 — Samostatný import cyklu z HealthKitu může po změně účtu odeslat data pod novou session

**Místo:** ios-native/Loadwise/App/CycleHealth.swift:45

**Příčina:** CycleHealth.sync vezme sdílený APIClient, awaituje flowDays (několik HK queries) a následně volá importAppleCycle bez session/account/server generation guard. Nový AppleHealth.generation tento oddělený importér nechrání. clearLocal jen přepne cycleHealthSynced a zresetuje model, HealthKit queries ani pokračující sync neinvaliduje.

**Dopad/scénář:** A s povoleným cyklem zahájí import 400 dní citlivých údajů. B se přihlásí během HealthKit čtení. Po jeho dokončení používá APIClient aktuální cookie B a do B se odešlou data telefonu, jejichž import zahájil A; přijímací route neověřuje zapnutí cyklu a přijme je i při B cycle disabled.

**Oprava:** Importér cyklu musí mít stejný account+server+generation kontext jako hlavní import; ověřit ho po každém čtení a před uploadem. Přijímací route má dodatečně vyžadovat odpovídající aktivní nastavení/volbu.

**Akceptace:** Zadržet flowDays A, odhlásit nebo nechat vypršet A, přihlásit B s cyklem OFF, uvolnit HealthKit výsledek: žádný POST ani zápis do B. Totéž při přepnutí serveru.

**Ověření:** Nativní race staticky doložený: AppModel+Cycle12–14 zahajuje samostatný sync; CycleHealth45–54 nemá kontrolu. Lokálně spuštěná původní current route/store a skutečné SQLite: B user_id22, cycleEnabled=false, POST /cycle/apple vrátil200 saved1 a uložil řádek B. Jazyk, datum a přihlášený kontext izolované; žádné reálné HealthKit ani síťové volání.

**Vznik:** Nově nalezený starší tok; netvrdíme, že vznikl opravami od prvního auditu.

## N-NATIVE-MUSCLES · P2 — Svalová únava předchozího účtu přetrvává po běžném odhlášení a ovlivní sestavení tréninku

**Místo:** ios-native/Loadwise/Screens/MuscleViews.swift:122

**Příčina:** AppModel.muscleFatigue je sdílené pole modelu (58), které clearLocal ani forgetAccountData nevymažou. model.muscles ho vrací pro každého nedemo uživatele. MusclesWidget a builder ho načítají jen když je nil.

**Dopad/scénář:** A otevře Svaly a odhlásí se, B se přihlásí na stejném telefonu. Widget bez jakéhokoli načítání ukáže A únavu a připravenost; sestavovač může automaticky vybrat focus podle A svalů (GymTools284–288). Nevyžaduje závod nebo chybu sítě.

**Oprava:** Vyčistit svalový model při ztrátě/změně identity a navázat výsledky loadMuscles na generaci account+server; po přihlášení B načíst B data. Zahrnout všechny per-account objekty do společného resetu.

**Akceptace:** A se zřetelně unavenými svaly→běžný logout→B: widget ani předvolba builderu nikdy nepoužijí A model; zadržená A odpověď /muscles ho nesmí později obnovit.

**Ověření:** Statický jednoznačný běžný tok: property58, kompletní clearLocal1434–1479 a forgetAccountData415–419 neobsahují reset; MuscleViews12,112–122 a GymTools284–288 starý model použijí. iOS runtime nebyl k dispozici.

**Vznik:** Nově nalezený starší tok; netvrdíme, že vznikl opravami od prvního auditu.

## Pokrytí

| Soubor | Hloubka | Tok |
|---|---|---|
| ios-native/Loadwise/App/AppModel.swift | detail | identity/signin/signout/server switch, outbox loop, refresh task, food/health callbacks; relevant changed regions and callers |
| ios-native/Loadwise/App/AppleHealth.swift | detail | settings persistence, connect/disconnect/pause/resume, observers, run/perform generation boundaries |
| ios-native/Loadwise/App/AppleHealthExport.swift | detail | prefs/reset/ledger, food/weight/workout exports and async boundaries |
| ios-native/Loadwise/App/Outbox.swift | flow | owner semantics, storage and nil legacy owner |
| ios-native/Loadwise/App/AppModel+Cycle.swift | detail | all cycle reads/writes and side effects |
| ios-native/Loadwise/App/CycleHealth.swift | detail | all importer/setup/query async boundaries |
| ios-native/Loadwise/App/Reminders.swift | flow | pill persistence, scheduling, cancellation and new forgetPill |
| ios-native/Loadwise/App/RootView.swift | flow | signedIn creation, account task, background/scene refresh |
| ios-native/Loadwise/App/BackgroundRefresh.swift | detail | all refresh/HealthKit/widget async boundaries |
| ios-native/Loadwise/App/SettingsStore.swift | flow | profile/account roles writes and shared user defaults |
| ios-native/Loadwise/Data/APIClient.swift | flow | dynamic server, shared cookies, async request/cache and queued retry |
| ios-native/Loadwise/Data/ServerChoice.swift | detail | server namespace and selection |
| ios-native/Loadwise/Screens/AppleHealthViews.swift | detail | all category UI and ALL OFF |
| ios-native/Loadwise/Screens/SyncViews.swift | flow | export prefs local/server reconciliation |
| ios-native/Loadwise/Screens/MuscleViews.swift | flow | shared fatigue model, widget initial loads and screen fetch |
| ios-native/Loadwise/Screens/GymTools.swift | flow | muscle focus initialization |
| ios-native/Loadwise/Screens/HealthView.swift | flow | cycle display/load |
| ios-native/Loadwise/Screens/CycleViews.swift | flow | cycle load tasks and model reuse |
| ios-native/Loadwise/Screens/SettingsPages/SettingsProfile.swift | flow | email/account metadata load |
| ios-native/Loadwise/App/WatchWorkout.swift | detail | complete changed workout conversion, warmup/cooldown/work/recovery/targets; no new confirmed defect |
| ios-native/Loadwise/Data/WorkoutModels.swift | flow | PlannedWorkout.Step intensity/target decode contract |
| ios-native/LoadwiseTests/OutboxTests.swift | flow | new owner/identity assertions, lacks running-loop transition scenario |
| src/routes-cycle.js | detail | cycle import receiver auth/Origin/settings checks |
| src/cycle-store.js | flow | cycle settings and per-current-user Apple import persistence |

## Omezení

- Swift compiler, Xcode/iOS simulator and actual HealthKit were unavailable; native conclusions distinguish statically reachable paths from runtime proof.
- No production sessions/data, live provider calls or HealthKit permission changes were used.
- Regression test source was inspected but not treated as execution.
- WatchWorkout API/device behavior requires a supported iPhone/Watch runtime; no confirmed source-level defect was found in its changed conversion.
- The all-OFF fix stops reading; persistence of the visible empty selection remains a separate UX recommendation.
