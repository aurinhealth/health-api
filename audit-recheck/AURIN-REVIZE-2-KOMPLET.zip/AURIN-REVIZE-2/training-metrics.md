# Opakovaná revize — tréninkové výpočty a metriky

Commit: `74a459d0f99fa6503e4e37035777915921427a06`. Původní stav: `02d575e570a179a5c156bcc9708877a2c18f3de8`.

Výsledek této části: **5 původních nálezů opraveno, 2 částečně opraveny; 2 nové potvrzené chyby P2.**

## A07 — fixed — Běžecký limit přidává běhy i při vyčerpaném rozpočtu

Místo: `src/week-planner.js:338`.

capRunVolume nyní vyřazuje běhy pod minimem 20 min a po zaokrouhlení nepřekročí zbývající prostor. Původní 4 běžecké dny dávají celkem 60 min místo 80. Po již hotových 60 min nevznikne další běh. Prošlo 308 kombinací limitu, již obsazených minut a délek návrhů.

**Co zbývá:** Původní chyba minimálních délek je opravená; vstup committed má samostatnou zbývající chybu A08.

**Oprava:** Zachovat opravu a přidat regresi pro součet všech ponechaných návrhů.

**Ověření dokončení:** Pro nulový prostor nevznikne běh; součet návrhů nepřekročí max(0, cap-committed).

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## A08 — partial — Dnešní plánovaný běh se neodečte z týdenního rozpočtu

Místo: `src/week-planner.js:353`.

Dnešní samotný plánovaný běh se již započítává. committedRunMinutes však počítá dnešek jako Math.max(planned,done), bez párování konkrétních aktivit. Skutečný weekProposal s ranním hotovým 30min během a jiným večerním plánovaným 30min během započte jen 30 min a navrhne dalších 30 min při cap=60.

**Co zbývá:** Dva různé dnešní běhy jsou považovány za jeden: skutečně obsazeno 60, započteno 30, nový návrh 30, celkem 90 při limitu 60. Stejný helper používá entrypoint.js:737.

**Oprava:** Párovat plán a dokončení podle identifikátoru/vazby či překryvu; sečíst nesplněné plány a dokončené odlišné běhy. Souhrnné max bez identity nestačí.

**Ověření dokončení:** Ranní hotový a večerní jiný plán se započítají oba; plán se svým skutečným dokončením se započítá právě jednou.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## A17 — fixed — Desetinné intenzity se v mezerách zón označí jako sprint

Místo: `src/workout-model.js:40`.

zoneOf nyní vybírá poslední zónu podle její dolní hranice, takže nejsou mezery mezi celými procenty. Původní reálný převod vlastního workoutu dává při 75,5 % na kole endurance a při 77,5 % běhu recovery, nikoli sprint.

**Co zbývá:** Původní desetinná mezera opravena. Ověření není fyziologická validace hranic zón.

**Oprava:** Zachovat nové hraniční regrese.

**Ověření dokončení:** Desetinné hodnoty mezi horní celou hranicí a začátkem další zóny zůstanou v nižší zóně.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## A18 — partial — Upravená vlastní šablona mění detail starších plánů

Místo: `src/workout-library.js:70`.

Nově plánované vlastní tréninky čtou neměnné planned_own_workouts kopie; pozdější úprava a smazání šablony je neovlivní. Pro staré own-<id> však zůstává fallback do saved_workouts a není přítomna migrace starých schedule odkazů. Runtime: starý plán Legacy ride/sport ride se po editaci šablony jmenuje Edited run/sport run; po smazání šablony scheduledLink vrací null.

**Co zbývá:** Oprava chrání nová plánování, nikoli všechny existující plány vzniklé před upgradem. Jejich název/sport/detail a odkazy pro následné operace závisejí na měnitelné šabloně. Staré již přepsané struktury nelze bez důvěryhodného uloženého eventu automaticky obnovit.

**Oprava:** Zpětně převést staré schedule odkazy na neměnné kopie, ideálně z uloženého lokálního/provider eventu; zachovat použitelný detail a vazbu i po smazání šablony.

**Ověření dokončení:** Vytvořit databázi s plánem před upgradem, provést upgrade, editovat/smazat šablonu a ověřit původní název, sport, strukturu a scheduledLink. Nové plány nadále zůstávají stabilní.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## A19 — fixed — Wahoo aktivita chybí ve svalové únavě a regeneraci

Místo: `src/muscle-fatigue.js:337`.

SQL výběr nyní zahrnuje source_family=wahoo pro activity. Původní syntetická 3h aktivita s TSS 180 se načte: 1 Wahoo aktivita, TSS 180. Zachován filtr record_role!=duplicate a společné zpracování storedActivities.

**Co zbývá:** Původní vyloučení Wahoo odstraněno. Nebyla spuštěna skutečná Wahoo synchronizace.

**Oprava:** Zachovat společný výběr zdrojů a test Wahoo.

**Ověření dokončení:** Stejná uložená aktivita se zahrne pro Wahoo stejně jako pro Intervals.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## A20 — fixed — Dnes a Zdraví počítají jiný spánkový dluh

Místo: `src/app-health.js:86`.

Health i Today nyní volají stejnou weekSleepDebt nad všemi sessions. Původní scénář noc 420 min + zdřímnutí 60 min při potřebě 480 vrací na obou obrazovkách dluh 0.

**Co zbývá:** Původní rozdíl odstraněn. Správnost samotného klinického modelu není tímto ověřena.

**Oprava:** Udržet společný výpočet a stejná vstupní data.

**Ověření dokončení:** Stejný vstup včetně zdřímnutí dá Health.sleep.debt.minutes == Today.strain.target.debt.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## A21 — fixed — Vážení se při UTC půlnoci přiřadí špatnému dni

Místo: `src/app-health.js:122`.

Health i Today používají localDate místo UTC slice. V America/New_York se vzorek 2026-10-20T01:00:00Z správně zobrazí v 2026-10-19 s hodnotou 80 na obou obrazovkách.

**Co zbývá:** Původní přiřazení UTC dnu odstraněno. Ověření lokálního převodu není runtime telefonu.

**Oprava:** Zachovat regresi pro časová pásma na obou stranách UTC.

**Ověření dokončení:** Vzorek kolem UTC půlnoci se ukáže na místním dni, nikoli jako budoucí den.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

## N-training-snapshot-race — P2 — Dvě souběžná plánování stejné vlastní šablony vytvoří duplicitní kalendářové události

Místo: `src/workout-templates.js:103`.

**Příčina:** plannedCopy dělá SELECT na shodný obsah a poté INSERT s náhodným ID. V tabulce je unikátní jen (user_id,id), nikoli vlastník+šablona+obsah. Dva requesty mohou oba přečíst žádnou kopii a založit odlišná ID. Tato ID se promítají do external_id události, takže deduplikace plánování je už nespojí.

**Dopad a reprodukce:** Při souběžném opakování stejného POST /my-workouts/:id/schedule vzniknou na stejný den dva stejné plány a mohou se nezávisle exportovat poskytovatelům. Lokální reprodukce původního plannedCopy, scheduleWorkoutInIntervals a storeLocalEvent na skutečném SQLite vytvořila 2 kopie, 2 local_workouts a 2 workout_schedule_links.

**Oprava:** Zavést deterministický identifikátor či unikátní otisk obsahu kopie a atomický INSERT ON CONFLICT se znovunačtením vítězné kopie; zajistit idempotenci stejného plánování stejného obsahu/dne.

**Ověření dokončení:** Pozastavit dva SELECT stejného obsahu před INSERT, dokončit oba requesty a ověřit jednu kopii, jednu kalendářovou událost a jedno exportní zadání.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny. Výběr výsledku SELECT byl bariérou deterministicky souběžný. Samotné původní SQL, výpočet external_id a lokální ukládání byly skutečné; pouze delivery do providerů a metadata byly izolované.

## N-training-compose-budget — P2 — AI workout může překročit denní časový limit po úpravě pro venkovní prostředí

Místo: `src/entrypoint.js:2375`.

**Příčina:** libraryDay stanoví maxDurationMinutes a běžné hledání filtruje již renderované workouty. Nová /workouts/compose tuto mez nepředá validátoru; composeFits kontroluje původní strukturu s tolerancí ±5 min a až poté se přidá venkovní rozjetí. Po renderForEnvironment už žádná kontrola limitu není.

**Dopad a reprodukce:** Při automatické délce 30 min a denním maximu 30 min projde validní tempo struktura 5+25+5=35 min. Venkovní render prodlouží úvodních 5 min na 15, takže uživatel obdrží 45min trénink. Dynamicky spuštěná původní routa s izolovaným validním composerem vrátila HTTP 200 a 45 min, ačkoli filters.maxDurationMinutes=30. Nativní knihovna tento fallback automaticky vyžádá po result.compose=true.

**Oprava:** Validovat délku a příslušné limity nad konečným renderem pro požadované prostředí. Pro automatickou délku vynucovat tvrdý denní rozpočet; při delším výsledku upravit strukturu a přepočítat nebo výsledek odmítnout.

**Ověření dokončení:** Pro automatický limit 30 min, outdoor a původní zahřátí 5 min nesmí compose vrátit workout nad 30 min. Přidat stejné kontraktní kontroly délky pro search a compose a ověřit cache odpovědi.

Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny. composeFits, buildWorkout a renderForEnvironment byly původní. Routa byla spuštěna s izolovanými metadaty a předem daným validním výsledkem composeru; reálný AI model, prompty ani síť nebyly testovány.

## Provedené kontroly

- `node /workspace/aurin-reaudit-2026-10-20/training-metrics-repro.mjs` — exit 0: Původní veřejné funkce, skutečné SQLite; 308 kombinací běžeckého capu a jednotlivé reprodukce oprav i zbývajících/nových chyb.
- `node --test tests/plan-week-targets.test.mjs tests/workout-library.test.mjs tests/workout-templates.test.mjs tests/app-health.test.mjs tests/muscle-fatigue.test.mjs tests/ai-workout-compose.test.mjs` — exit 1: Všech 6 testových souborů skončilo při importu chybějícího src/private/lang.js. Nejde o 6 funkčních regresí; soukromé soubory nebyly napodobeny.

## Omezení

- Žádná skutečná AI generace, soukromé instrukce, provider API ani iOS runtime.
- Izolované funkce mají lokální překladovou funkci L a nahrazené nesouvisející metadatové/doručovací závislosti; nejde o plnou Worker integraci.
- A18 platí jako částečná oprava pro upgrade historických dat, nově vytvářené snapshoty řeší původní přepis délky.
- Odborná účinnost tréninkových a spánkových heuristik nebyla empiricky validována.
- Kontrola se vztahuje výhradně ke commitu 74a459d0f99fa6503e4e37035777915921427a06.

## Pokrytí

- `src/week-planner.js`: detail
- `src/adaptive-week.js`: detail
- `src/workout-model.js`: detail
- `src/workout-templates.js`: detail
- `src/workout-library.js`: detail
- `src/app-health.js`: detail
- `src/app-today.js`: detail
- `src/recovery-model.js`: detail
- `src/muscle-fatigue.js`: detail
- `src/ai-workout-compose.js`: detail
- `src/ai-workout-pick.js`: detail
- `src/endurance-templates.js`: detail
- `src/local-workouts.js`: detail
- `src/entrypoint.js`: flow
- `src/fitness-insights.js`: flow
- `src/user-time.js`: flow
- `src/readiness.js`: flow
- `src/tenancy.js`: flow
- `ios-native/Loadwise/Screens/TrainingLibrary.swift`: flow
- `ios-native/Loadwise/Data/APIClient+Training.swift`: flow
- `src/workout-explanation.js`: overview
- `src/planned-start.js`: overview
- `src/planned-workout.js`: overview
- `tests/plan-week-targets.test.mjs`: overview
- `tests/workout-library.test.mjs`: overview
- `tests/workout-templates.test.mjs`: overview
- `tests/app-health.test.mjs`: overview
- `tests/muscle-fatigue.test.mjs`: overview
- `tests/ai-workout-compose.test.mjs`: overview
- `tests/training-time-budget.test.mjs`: overview
