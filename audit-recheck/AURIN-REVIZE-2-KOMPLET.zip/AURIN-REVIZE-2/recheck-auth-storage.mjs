// Executes original public modules with isolated language/irrelevant I/O imports.
// No application source changes, private prompts, real accounts or external calls.
import vm from 'node:vm';
import {readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {webcrypto,createHmac} from 'node:crypto';
import {createD1} from '/workspace/health-api-recheck/tests/helpers/d1.mjs';

const root='/workspace/health-api-recheck/src';
const results=[];
function loader(doubles={}, extra={}) {
  const context=vm.createContext({console,crypto:webcrypto,TextEncoder,TextDecoder,Headers,Request,Response,URL,URLSearchParams,btoa,atob,Date,Uint8Array,Uint32Array,AbortSignal,fetch:async()=>{throw Error('Unexpected external fetch');},...extra});
  const cache=new Map();
  async function load(file) {
    if(cache.has(file))return cache.get(file);
    const name=path.basename(file), values=name==='lang.js'?{L:(cs,en)=>en}:doubles[name];
    let src;
    if(!values)src=readFileSync(file,'utf8')+(name==='google-login.js'?'\nexport {appHandoffToken as issueForProof};':'');
    const mod=values?new vm.SyntheticModule(Object.keys(values),function(){for(const [k,v]of Object.entries(values))this.setExport(k,v);},{context,identifier:file}):new vm.SourceTextModule(src,{context,identifier:file});
    cache.set(file,mod);
    await mod.link((s,r)=>load(path.resolve(path.dirname(r.identifier),s)));
    return mod;
  }
  return {load,cache};
}
const record=x=>{results.push(x);console.log(JSON.stringify(x));};

// A03: pending is no longer a false success; after the first failure a retry writes once.
{
  const DB=createD1(), {load}=loader();
  const mod=await load(path.join(root,'idempotency.js'));await mod.evaluate();
  const env={DB,USER_ID:7}, url=new URL('https://app.test/app/api/fluids');
  const req=()=>new Request(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ml:250,requestId:'review-pending-00001'})});
  let entered,release,writes=0;
  const started=new Promise(r=>entered=r), gate=new Promise(r=>release=r);
  const first=mod.namespace.withIdempotency(req(),env,url,async()=>{entered();await gate;return Response.json({message:'simulated storage failure'},{status:500});});
  await started;
  const pending=[];
  for(let i=0;i<5;i++){
    const response=await mod.namespace.withIdempotency(req(),env,url,async()=>{writes++;return Response.json({status:'ok'});});
    pending.push({status:response.status,retryAfter:response.headers.get('Retry-After')});
  }
  assert.ok(pending.every(x=>x.status===503&&x.retryAfter==='5'));
  release();assert.equal((await first).status,500);
  const retried=await mod.namespace.withIdempotency(req(),env,url,async()=>{writes++;return Response.json({status:'ok'});});
  assert.equal(retried.status,200);assert.equal(writes,1);
  const replay=await mod.namespace.withIdempotency(req(),env,url,async()=>{writes++;return Response.json({status:'unexpected'});});
  assert.equal(replay.status,200);assert.equal(writes,1);
  record({id:'A03',proof:'server pending/failure/retry/replay',pending,successfulRetry:retried.status,storedReplay:replay.status,writes,clientLimit:'native statically still drops on fifth retry; not executed here'});
}

// A04: actual Google callback rejects A -> B before token exchange or credential writes.
{
  let exchanges=0;const writes=[];
  const {load}=loader({'connection-secrets.js':{saveConnectionSecret:async(env,provider,value)=>writes.push({uid:env.USER_ID,provider,value})}},{fetch:async()=>{exchanges++;return Response.json({refresh_token:'test-refresh-only',scope:'test-scope'});}});
  const mod=await load(path.join(root,'google-oauth.js'));await mod.evaluate();
  const env={USER_ID:11,GOOGLE_CLIENT_ID:'test-client',GOOGLE_CLIENT_SECRET:'test-secret'};
  const start=await mod.namespace.handleGoogleOAuth(new Request('https://aurin.health/oauth/google?consent=1'),env,'/oauth/google');
  const state=new URL(start.headers.get('Location')).searchParams.get('state');
  const cookie=start.headers.get('Set-Cookie').split(';')[0];
  const req=()=>new Request('https://aurin.health/oauth/google/callback?state='+state+'&code=test-only',{headers:{Cookie:cookie}});
  const wrong=await mod.namespace.handleGoogleOAuth(req(),{...env,USER_ID:22},'/oauth/google/callback');
  assert.equal(wrong.status,403);assert.equal(exchanges,0);assert.equal(writes.length,0);
  const right=await mod.namespace.handleGoogleOAuth(req(),env,'/oauth/google/callback');
  assert.equal(right.status,302);assert.equal(exchanges,1);assert.equal(writes.length,2);assert.ok(writes.every(x=>x.uid===11));
  record({id:'A04',proof:'original Google callback with isolated token exchange/storage',wrongAccountStatus:wrong.status,wrongAccountExchanges:0,wrongAccountWrites:0,correctAccountStatus:right.status,credentialsSavedFor:writes.map(x=>({uid:x.uid,provider:x.provider}))});
}

// A05: original handoff + dashboard auth, real SQL, real HMAC and one-time claims.
{
  const DB=createD1();
  DB.sqlite.exec(`CREATE TABLE users(id INTEGER PRIMARY KEY,session_epoch INTEGER);INSERT INTO users VALUES(11,0);CREATE TABLE auth_challenges(challenge TEXT PRIMARY KEY,purpose TEXT,user_id INTEGER,expires_at INTEGER);`);
  let intercept=null;
  const wrapped={...DB,batch:async statements=>{if(intercept)await intercept();return DB.batch(statements);}};
  const {load,cache}=loader({'tenancy.js':{ensureTenancy:async()=>{},signInGoogleUser:async()=>({id:11}),bumpSessionEpoch:async()=>0},'github-oidc.js':{verifyGitHubActionsToken:async()=>{throw Error('unused');}}});
  const mod=await load(path.join(root,'google-login.js'));await mod.evaluate();
  const auth=cache.get(path.join(root,'dashboard-auth.js')).namespace;
  const env={DB:wrapped,GOOGLE_CLIENT_ID:'test-client',GOOGLE_CLIENT_SECRET:'test-secret',SESSION_SECRET:'test-session-secret-not-real',OWNER_EMAIL:'owner@example.invalid'};
  const verifier='v'.repeat(43),challenge=Buffer.from(await webcrypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier))).toString('base64url');
  const issue=epoch=>mod.namespace.issueForProof(11,challenge,env.SESSION_SECRET,epoch);
  const exchange=token=>mod.namespace.handleGoogleLogin(new Request('https://aurin.health/auth/app/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,verifier})}),env,'/auth/app/session');
  const token=await issue(0);
  assert.equal((await exchange(token)).status,200);assert.equal((await exchange(token)).status,401);
  const unused=await issue(0);DB.sqlite.exec('UPDATE users SET session_epoch=1 WHERE id=11');
  assert.equal((await exchange(unused)).status,401);
  record({id:'A05',proof:'straight replay and pre-exchange revocation',firstStatus:200,replayStatus:401,unusedTokenAfterRevocationStatus:401});

  DB.sqlite.exec('UPDATE users SET session_epoch=0 WHERE id=11');
  const racing=await issue(0);let entered,release;
  const started=new Promise(r=>entered=r),gate=new Promise(r=>release=r);
  intercept=async()=>{entered();await gate;};
  const inFlight=exchange(racing);
  await started; // epoch 0 was checked; the one-time claim has not finished yet.
  DB.sqlite.exec('UPDATE users SET session_epoch=1 WHERE id=11');release();
  const response=await inFlight;
  assert.equal(response.status,200);
  const cookie=response.headers.get('Set-Cookie').split(';')[0];
  const session=await auth.verifyDashboardSession(new Request('https://aurin.health/app/api/me',{headers:{Cookie:cookie}}),env.SESSION_SECRET);
  assert.equal(session.epoch,1);assert.equal(auth.sessionMatchesUser({kind:'user',epoch:session.epoch},{sessionEpoch:1}),true);
  record({id:'A05',proof:'revocation between epoch check and session mint',issuedTokenEpoch:0,revokedEpoch:1,responseStatus:response.status,newCookieEpoch:session.epoch,validAfterRevocation:true});
}

// A25: original handler + original SQLite rate limiter; only delivery and irrelevant imports doubled.
{
  const DB=createD1();DB.sqlite.exec(`CREATE TABLE users(id INTEGER PRIMARY KEY,email TEXT);INSERT INTO users VALUES(7,'member@example.invalid');`);
  for(const name of ['0014_passkeys_email_codes.sql','0027_email_code_limits.sql'])DB.sqlite.exec(readFileSync('/workspace/health-api-recheck/migrations/'+name,'utf8'));
  let sent=0;
  const env={DB,RAW_DB:DB,SESSION_SECRET:'test-only-secret',OWNER_EMAIL:'owner@example.invalid',EMAIL_FROM:'noreply@example.invalid',EMAIL:{send:async()=>{sent++;return {messageId:'local-'+sent};}}};
  const {load}=loader({'dashboard-auth.js':{signText:async(value,secret)=>createHmac('sha256',secret).update(value).digest('base64url'),sessionSecret:env=>env.SESSION_SECRET,timingSafeEqualString:(a,b)=>a===b,signedInResponse:async()=>Response.json({}),userSessionCookie:async()=>''},'site-pages.js':{siteLang:()=> 'en'},'app-review.js':{reviewCodeActive:()=>false},'tenancy.js':{normalizeEmail:value=>String(value||'').trim().toLowerCase(),emailCodeAccess:async()=> 'known',signInEmailUser:async()=>null,changeUserEmail:async()=>({}),bumpSessionEpoch:async()=>1}});
  const mod=await load(path.join(root,'email-login.js'));await mod.evaluate();
  const url=new URL('https://aurin.health/app/api/account/email/start'),user={id:7,email:'member@example.invalid',isOwner:false},statuses=[];
  for(let i=0;i<100;i++)statuses.push((await mod.namespace.handleEmailChange(new Request(url,{method:'POST',headers:{Origin:url.origin,'Content-Type':'application/json','CF-Connecting-IP':'192.0.2.1'},body:JSON.stringify({email:'target-'+i+'@example.invalid'})}),env,url,{signedIn:true,user})).status);
  assert.equal(statuses.filter(s=>s===200).length,2);assert.equal(sent,2);
  assert.equal(DB.sqlite.prepare("SELECT * FROM request_limits WHERE key='email-codes:day'").get(),undefined);
  const regular=await mod.namespace.sendCode(env,'legitimate@example.invalid','en');assert.equal(regular,true);
  record({id:'A25',proof:'rotating addresses now hit per-user limit without login budget',attempted:100,successfulChanges:2,refusedChanges:98,changeBudget:DB.sqlite.prepare("SELECT day_count FROM request_limits WHERE key='email-codes:change:day'").get().day_count,normalSigninCodeCanBeSent:regular,sentIncludingNormal:sent});
}

// A26: original tenancy/Apple sign-in, real SQLite; irrelevant catalog/runtime routing replaced.
{
  const {load}=loader({'user-data-routing.js':{routedUserDb:async()=>{throw Error('not used');}},'dashboard-auth.js':{sessionSecret:()=>'',signedInResponse:async()=>Response.json({})}});
  const tenancy=await load(path.join(root,'tenancy.js'));await tenancy.evaluate();
  const apple=await load(path.join(root,'apple-login.js'));await apple.evaluate();
  const schema=`CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE,name TEXT,role TEXT,disabled INTEGER DEFAULT 0,google_sub TEXT,last_login_at TEXT);CREATE TABLE user_invites(email TEXT PRIMARY KEY);CREATE TABLE schema_meta(key TEXT PRIMARY KEY,value TEXT);INSERT INTO schema_meta VALUES('user_data_sharding_enabled','1');CREATE TABLE user_data_shards(shard_key TEXT PRIMARY KEY,binding_name TEXT,state TEXT,accepting_new INTEGER,max_users INTEGER,max_bytes INTEGER);INSERT INTO user_data_shards VALUES('data-001','USER_DATA_001','ready',1,1,7000000000);CREATE TABLE user_data_routes(user_id INTEGER PRIMARY KEY,shard_key TEXT);CREATE TABLE signup_waitlist(email TEXT PRIMARY KEY);`;
  for(const mode of ['email','google','apple']) {
    const DB=createD1();DB.sqlite.exec(schema);
    const env={DB,USER_DATA_ROUTING:'true',OWNER_EMAIL:'owner@example.invalid',OPEN_SIGNUP:'true',ACCOUNT_LIMIT:'1'};
    const sign=email=>mode==='email'?tenancy.namespace.signInEmailUser(DB,env,email):mode==='google'?tenancy.namespace.signInGoogleUser(DB,env,{sub:'g-'+email,email}):apple.namespace.signInAppleUser(DB,env,{sub:'a-'+email,email});
    const users=await Promise.all(['a@example.invalid','b@example.invalid','c@example.invalid'].map(sign));
    assert.equal(users.filter(Boolean).length,1);assert.equal(DB.sqlite.prepare('SELECT COUNT(*) AS n FROM users').get().n,1);
    assert.equal(DB.sqlite.prepare('SELECT COUNT(*) AS n FROM signup_waitlist').get().n,2);
    record({id:'A26',proof:'three concurrent sign-ins race for one account/storage place',mode,createdAccounts:users.filter(Boolean).length,waitlisted:2});
  }
}

// New waitlist paths: no real Apple calls, original SQL/functions, generated ephemeral test key.
{
  const {load}=loader({'ip-rate-limit.js':{allowClient:async()=>true,allowRequest:async()=>true},'dashboard-auth.js':{sessionSecret:()=>''}});
  const mod=await load(path.join(root,'testflight-waitlist.js'));await mod.evaluate();
  const DB=createD1();await mod.namespace.listWaitlist(DB,{});
  const insert=DB.sqlite.prepare("INSERT INTO testflight_waitlist(email) VALUES(?)");
  for(let i=1;i<=301;i++)insert.run(`person-${i}@example.invalid`);
  const listed=await mod.namespace.listWaitlist(DB,{});
  assert.equal(listed.pending.length,300);assert.ok(!listed.pending.some(x=>x.id===1));
  record({id:'NEW-WAITLIST-TRUNCATION',proof:'oldest pending entry inaccessible in returned admin list',storedPending:301,returnedPending:listed.pending.length,oldestPendingId:1,oldestReturned:Math.min(...listed.pending.map(x=>x.id))});

  const db=createD1();await mod.namespace.listWaitlist(db,{});
  db.sqlite.exec("INSERT INTO testflight_waitlist(email) VALUES('first@example.invalid'),('second@example.invalid')");
  const pair=await webcrypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const pem='-----BEGIN PRIVATE KEY-----\n'+Buffer.from(await webcrypto.subtle.exportKey('pkcs8',pair.privateKey)).toString('base64')+'\n-----END PRIVATE KEY-----';
  const env={ASC_KEY_ID:'ephemeral-test',ASC_ISSUER_ID:'ephemeral-test',ASC_KEY_P8:pem};
  const members=Array.from({length:19},(_,i)=>`existing-${i}@example.invalid`),reads=[];
  let ready,release;const bothRead=new Promise(r=>ready=r),gate=new Promise(r=>release=r);
  const fetcher=async(url,init={})=>{
    const p=url.replace('https://api.appstoreconnect.apple.com/v1',''),method=init.method||'GET';
    const ok=data=>Response.json({data});
    if(p.startsWith('/apps?'))return ok([{id:'app'}]);
    if(p.startsWith('/apps/app/betaGroups'))return ok([{id:'group',attributes:{name:'Test',isInternalGroup:false}}]);
    if(p.startsWith('/betaGroups/group/betaTesters')) {
      const snapshot=members.map((email,i)=>({id:'t'+i,attributes:{email}}));reads.push(snapshot.length);
      if(reads.length===2)ready();await gate;return ok(snapshot);
    }
    if(p.startsWith('/betaTesters?'))return ok([]);
    if(p==='/betaTesters'&&method==='POST'){const email=JSON.parse(init.body).data.attributes.email;members.push(email);return ok({id:email});}
    if(p==='/betaTesterInvitations')return ok({});
    throw Error('Unexpected fake request '+method+' '+p);
  };
  const approvals=Promise.all([1,2].map(id=>mod.namespace.decideWaitlist(db,env,{id,decision:'approve'},fetcher)));
  await bothRead;release();const answers=await approvals;
  assert.equal(members.length,21);assert.ok(answers.every(x=>x.status==='ok'));
  record({id:'NEW-WAITLIST-CAPACITY',proof:'two owner approvals race for final tester slot',startingMembers:19,concurrentReads:reads,successfulApprovals:answers.length,endingMembers:members.length,declaredLimit:mod.namespace.TESTER_LIMIT,localInvited:db.sqlite.prepare("SELECT COUNT(*) AS n FROM testflight_waitlist WHERE status='invited'").get().n});
}

writeFileSync('/workspace/aurin-reaudit-2026-10-20/auth-storage-reproductions.json',JSON.stringify(results,null,2));
