# Následná revize: platforma, dokumentace a cyklus

Revidováno `74a459d0f99fa6503e4e37035777915921427a06` proti `02d575e570a179a5c156bcc9708877a2c18f3de8`. **Všechny čtyři původní body jsou v příslušném původním scénáři opravené.** Provozní běh workflow není tím automaticky prokázaný. **Dva další doložené nálezy** v cyklu jsou přítomné už ve starším kódu, nově odhalené při této revizi.

## A29 — fixed — Workflow mikroživin selže před sestavením katalogu

Místo: `.github/workflows/food-micros.yml:50`.

**Ověření opravy:** Před Run tests je nově checkout shaarkyn/aurin-prompts do src/private s PROMPTS_REPO_TOKEN (ř.50–55); testovací příkaz na ř.63 zůstává zachován. Původní chybějící krok je doplněný.

**Co zbývá / meze:** V tomto prostředí nejsou soukromé prompty ani token: skutečný GitHub dry-run a vytvoření artefaktu nebyly spuštěny. Dostupnost a rozsah secretu je provozní ověření.

**Doporučení:** Kódová oprava je přítomná. Při vydání ověřit čistý food-micros dry-run se skutečným soukromým checkoutem.

**Metoda:** Statická kontrola přesného pořadí a parametrů workflow; bez vzdáleného CI běhu.

## A30 — fixed — Návod slibuje nedostupné odpojení přihlášení Apple

Místo: `src/site-pages.js:887`.

**Ověření opravy:** EN privacy odkazuje pouze na Apple ID settings (ř.887), CS pouze na nastavení Apple ID (ř.989). Příslib odpojení v Nastavení → Účet byl odstraněn. Aktuální funkce privacyPage/supportPage/termsPage byly přímo vyrenderované; obě jazykové privacy odpovědi prošly ověřením obsahu.

**Co zbývá / meze:** Skutečné odebrání přihlášení v Apple ID nebylo provedeno. Support je podle projektu pouze anglický; české jsou privacy a terms.

**Doporučení:** Další oprava původního návodu není potřeba.

**Metoda:** Runtime render skutečných funkcí site-pages.js, bez sítě; statické porovnání změny EN/CS.

## A32 — fixed — Osobní adresa majitele zůstává v historické migraci

Místo: `migrations/0004_backfill_completed_strength_20261002.sql:16`.

**Ověření opravy:** Aktuální migrace používá owner@example.com namísto osobní adresy; OWNER_EMAIL v deploy nadále pochází ze secretu. Reálný lokální SQLite úspěšně provedl staging/schema.sql a upravenou migraci.

**Co zbývá / meze:** Starší Git historie a metadata commitů nebyla přepsána. Původní doporučení i akceptace mířily na aktuální publikovaný strom, nikoli na odstranění historie.

**Doporučení:** Původní změna aktuálního stromu je hotová; případnou práci s historií řešit samostatně.

**Metoda:** Kontrola aktuálního SQL a skutečné SQLite 3.53.1; platform-bootstrap.json.

## A33 — fixed — Záznam užité pilulky v minulém dni se po uložení nezobrazí

Místo: `src/cycle-model.js:79`.

**Ověření opravy:** Původní nativní scénář je opraven: normalizeCycleDay nyní přijímá vlastní řetězec taken (cycle-model.js:79). Reálné save(true) → list → calendar vrací taken; HH:MM i null fungují; opakovaná normalizace je idempotentní. Avšak saveCycleDay({pill:"taken"}) nadále uloží null, protože store přijímá pouze boolean true nebo čas.

**Co zbývá / meze:** Původní nativní chyba se v reprodukci neopakuje. Doplňková poznámka ke kontraktu: přímý API vstup pill:"taken" store nepřijímá, zatímco true a HH:MM ano. Aktuální nativní klient takový řetězec neposílá, proto tato poznámka není započítaná jako pokračující chyba ani nový nález.

**Doporučení:** Oprava původního nativního scénáře je hotová. Volitelně lze sjednotit i vstupní API reprezentaci pill:"taken", pokud má být součástí podporovaného kontraktu.

**Metoda:** recheck-platform-cycle.mjs, původní aktuální model/store a skutečné SQLite; platform-cycle-reproduction.json → A33. Nativní caller ověřen staticky na CycleViews.swift:449–450.

## N-platform-1 — P2 — Přepnutí měsíce v cyklu zkreslí dnešní stav a starší záznamy

Místo: `src/routes-cycle.js:19`.

**Příčina:** cycleView používá jeden dotaz od today−200 dní do první den vybraného měsíce+45 dní pro historický kalendář i výpočet dnešního stavu. Při starém měsíci není zadaný měsíc v načteném intervalu; při nedávném předchozím měsíci v něm naopak chybí poslední dny.

**Dopad a reprodukce:** Na 20.10.2026 uložená dnešní pilulka21:04 je v říjnovém zobrazení taken, ale při přepnutí na září state.date zůstane20.10 a pill.taken se změní na null. Nativní kalendář pod měsícem vykresluje dnešní PillCard z tohoto stavu. Lednový uložený flow3+cramps se zároveň vykreslí jako flow0 a prázdné symptomy; úprava takového zdánlivě prázdného dne může přepsat uložené krvácení na0.

**Oprava:** Oddělit okno vstupů pro dnešní výpočet od přesného rozsahu požadovaného kalendářního měsíce; neodvozovat dnešní stav z omezené historie zobrazeného měsíce.

**Akceptace:** Přepnutí mezi říjnem a zářím nemění stav dnešní již vzaté pilulky. Leden mimo today−200 zobrazí skutečně uložené hodnoty. Přidání symptomu do takového dne nepřepíše starý flow nesprávným výchozím0.

**Ověření:** Runtime recheck-platform-cycle.mjs: skutečné cycleView/cycle-store/cycle-model s lokálním SQLite; pouze jazykový import izolovaný. platform-cycle-reproduction.json → previousMonthCurrentState a oldCalendar. UI návaznost staticky CycleViews.swift:481,508,521–523 a443–450; AppModel+Cycle.swift:9–10.

## N-platform-2 — P2 — Souběžné změny cyklu přepisují jiné zápisy a mohou obnovit odvolané sdílení

Místo: `src/cycle-store.js:67`.

**Příčina:** saveCycleDay načte starý celý řádek a poté do UPSERT zapíše i nepředané hodnoty z tohoto snapshotu. saveCycleSettings obdobně načte a přepíše celé settings_json. Dvě nezávislé částečné změny tedy mohou obě vycházet ze stejného starého stavu a pozdější zápis vrátí jiná pole zpět.

**Dopad a reprodukce:** Dvě souběžné změny dne flow3 a symptoms[cramps] skončí flow0 a symptoms[cramps], přestože obě operace dokončí bez chyby. Souběh vypnutí shareWithCoach a změny času připomínky obnoví shareWithCoach:true; následující cycleForCoach pak může znovu předávat cyklus AI proti poslední volbě uživatele. Týká se např. více zařízení nebo souběžných nečekajících akcí, ne anonymního přístupu.

**Oprava:** Provádět částečné změny atomicky nad aktuálními hodnotami (jen předaná pole / atomická JSON aktualizace), nebo zavést verzi a CAS s opakováním na čerstvém stavu. Změna jiného nastavení nesmí obnovit odvolaný souhlas.

**Akceptace:** Obě pořadí a zadržené souběhy dvou různých změn zachovají jejich sjednocení. Po souběhu shareWithCoach:false a nesouvisející změny zůstane sdílení vypnuté a cycleForCoach vrátí null.

**Ověření:** Runtime recheck-platform-cycle.mjs s původním aktuálním store a reálným SQLite, přirozené Promise.all bez umělé implementace zápisů: platform-cycle-reproduction.json → concurrentPatch a concurrentSettings. Routes-cycle.js:37,42 předává změny do těchto funkcí bez společné transakce.

## Kontroly

- **passed** `node /workspace/aurin-reaudit-2026-10-20/recheck-platform-cycle.mjs` — A33 boolean/time/null/idempotence; canonical literal gap; historical/current calendar windows; day/settings concurrent lost updates; real SQLite.

- **passed** `node --test tests/cycle-model.test.mjs` — Pure current public model assertions executed; Node reports one test file.

- **blocked** `node --test tests/cycle-routes.test.mjs` — ERR_MODULE_NOT_FOUND src/private/lang.js; no fake private source supplied.

- **passed** `Direct Node import and render privacyPage/supportPage/termsPage` — EN/CS privacy and terms; Apple instructions no longer promise in-app unlink. Support remains English by project contract.

- **passed** `Python SQLite executes staging/schema.sql then migrations/0004_backfill_completed_strength_20261002.sql` — SQLite3.53.1, bootstrap and sanitized migration execute; platform-bootstrap.json.


## Omezení a průřezové body

- Bez Xcode/iOS runtime, Apple ID zásahu, reálného HealthKitu a běhu na telefonu.

- Soukromé prompty, PROMPTS_REPO_TOKEN a skutečné GitHub/Cloudflare environment nastavení nejsou dostupné; vzdálený food-micros dry-run, deploy ani rotace secretů nebyly provedeny.

- Cycle store/routes pro reprodukci používají skutečné aktuální funkce s izolovaným jazykovým importem; databáze je skutečné lokální SQLite, nikoli Cloudflare D1 v produkci.

- Nové nálezy v routes-cycle/cycle-store jsou nově odhalené; dotčené funkce se od původního commitu nezměnily. Nejde o tvrzení, že je zavedly opravné PR.

- Přetrvává dřívější průřezový provozní bod: soukromé prompty se v test/deploy a food workflow nestahují na společně připnutém SHA. To zde není nový samostatně započítaný potvrzený incident.

- Nebyly změněny aplikační soubory, historie ani produkční data.


## Pokrytí

- `.github/workflows/food-micros.yml` — detail

- `.github/workflows/deploy-worker.yml` — detail

- `migrations/0004_backfill_completed_strength_20261002.sql` — detail

- `staging/schema.sql` — bootstrap execution

- `src/cycle-model.js` — detail

- `src/cycle-store.js` — detail

- `src/routes-cycle.js` — detail

- `ios-native/Loadwise/App/AppModel+Cycle.swift` — detail

- `ios-native/Loadwise/Screens/CycleViews.swift` — targeted flow (calendar/logging/pill/settings/consent)

- `src/site-pages.js` — legal/support flow and runtime render; overview covered by root

- `tests/cycle-model.test.mjs` — runtime

- `tests/cycle-routes.test.mjs` — source and attempted runtime

- `tests/site-pages.test.mjs` — targeted assertions

- `.github/workflows/vydat.yml` — overview private/deploy refs
