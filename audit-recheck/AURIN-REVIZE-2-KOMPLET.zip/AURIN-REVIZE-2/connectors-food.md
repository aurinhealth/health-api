# Opakovaná revize: synchronizace, výživa a notifikace

Kontrolovaný commit: `74a459d0f99fa6503e4e37035777915921427a06`. Původní audit: `02d575e570a179a5c156bcc9708877a2c18f3de8`.

**Sedm původních bodů: 5 opravených, 2 částečně opravené. Tři další nálezy P2.**

| ID | Stav | Místo |
|---|---|---|
| A09 | fixed | src/entrypoint.js:263 |
| A16 | fixed | src/wahoo.js:191 |
| A22 | partial | src/sync-destinations.js:414 |
| A23 | partial | src/index.js:1227 |
| A24 | fixed | src/apple-food.js:94 |
| A27 | fixed | src/food-google-sync.js:22 |
| A28 | fixed | src/food-entry-management.js:123 |

A24 uzavírá původní nechtěné mazání při prázdném/odepřeném čtení. Nový opačný problém při skutečném smazání poslední položky je uveden zvlášť. A28 uzavírá původní chybějící ID uprostřed kopírování; nový neatomický přesun importovaných jídel je samostatný nález.

## A09 — Push kouče se neplánuje pro účty bez Google nebo Intervals (fixed)

**Místo:** [src/entrypoint.js:263](/workspace/health-api-recheck/src/entrypoint.js:263).

**Co je ověřeno:** Samostatný coach-push job má push:true a nevyžaduje providera; fan-out sjednocuje usersWithProviders a usersWithPushTokens, runUserJobs přijímá push job i s prázdným CONNECTED_PROVIDERS. Push tokeny zůstávají v centrální DB (user-data-routing.js). Lokální skutečný výběr fan-out poslal právě jednou uživatele Apple-only, WHOOP, Ultrahuman, Google a Intervals.

**Co zbývá / hranice:** Původní chyba koučovy notifikace je odstraněna. Oddělený problém ranní připravenosti pro WHOOP/Ultrahuman je uveden jako NEW-MORNING-PUSH; nejde o popření opravy kouče.

**Doporučení:** Zachovat samostatnou push selekci a její regresi pro všechny providery i účet bez serverového providera.

**Akceptace:** Uživatel s povoleným koučem a registrovaným telefonem je vybrán právě jednou bez ohledu na providera; vypnuté souhlasy/zakázané účty jsou vyřazeny.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Selekce a definice skutečných jobů byly provedeny, APNs a generování návrhů nebyly volány.

## A16 — Wahoo synchronizace vrací ručně opravený typ a kalorie (fixed)

**Místo:** [src/wahoo.js:191](/workspace/health-api-recheck/src/wahoo.js:191).

**Co je ověřeno:** Wahoo upsert používá KEEP_TYPE_SQL. Změna typu zapisuje loadwiseType a SQL zachová top-level type i loadwiseKcal/loadwiseKcalDevice. Reálná lokální posloupnost import Run/600 → edit Walk/250 → stejný Wahoo import ponechala Walk/250, marker Walk a původních 600 kcal.

**Co zbývá / hranice:** Ochrana platí pro nově označené úpravy; staré uživatelské volby typu uložené ještě před zavedením markeru nelze zpětně spolehlivě rozlišit od provider dat.

**Doporučení:** Zachovat společný SQL kontrakt a regresní průchod import → edit → resync.

**Akceptace:** Ručně změněný typ i kalorie zůstanou po opakovaném importu; reset kalorií nadále vrací hodnotu zařízení.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json.

## A22 — Rozpracovaná Google operace je označená jako odeslaná aktivita (partial)

**Místo:** [src/sync-destinations.js:414](/workspace/health-api-recheck/src/sync-destinations.js:414).

**Co je ověřeno:** Nová větev done:false ukládá operations/... jako pending a při retry nejprve GET, pak PATCH výsledného záznamu. To lokálně prošlo bez druhého POST. Každý pending však stále volá setStatus s attempts=attempts+1; retrySyncSends vybírá jen attempts<3.

**Co zbývá / hranice:** Po úvodním odeslání a dvou cron kontrolách zůstává status=pending, remote_id=operations/slow a attempts=3. I když se operace poté dokončí, další cron už neudělá žádný GET. Totéž vyvolají dočasně nedostupné odpovědi kontrol operace. UI pending ukazuje jen „odešle se“, tlačítko retry nabízí pouze pro error. Ruční serverové retry může záznam opravit, automatický tok se ale zastaví.

**Doporučení:** Oddělit počet skutečných selhání od čekání na přijatou operaci; pending průběžně kontrolovat s omezeným backoffem/TTL. Po překročení TTL přejít do srozumitelného obnovitelného stavu a nabídnout bezpečné retry. Vždy zachovat identitu operace nebo výsledného resource.

**Akceptace:** Operace pending přes tři kontroly a později done přejde automaticky do sent bez druhého POST. Ověřit i dočasné 503/timeouts a UI stavu pending/error.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Pro případ done:false byly původní funkce skutečně provedeny; reálné Google Health nebylo použito.

## A23 — Smazaná aktivita Intervals zůstává v aplikaci (partial)

**Místo:** [src/index.js:1227](/workspace/health-api-recheck/src/index.js:1227).

**Co je ověřeno:** ACTIVITY_DELETED nyní předává konkrétní ID až do importeru a maže je i mimo recent okno. Neprázdná odpověď také reconciliuje chybějící aktivity a vrací watch duplicitu na primary. Lokálně ověřeno: chybějící i2 odstraněno, watch2 znovu primary; pojmenované i1 odstraněno i při prázdné odpovědi.

**Co zbývá / hranice:** Původní scénář poslední smazané aktivity při úplném, ale prázdném refreshi stále selhává. Podmínka activities.length zcela přeskočí reconciliation. Týká se zejména spojení osobním API klíčem bez OAuth webhooků nebo ztraceného webhooku; stale aktivita dál ovlivňuje historii a výpočty.

**Doporučení:** Doplnit bezpečný způsob potvrzení smazání i při nulovém seznamu: autoritativní úplný interval či konkrétní delete události s obnovou po výpadku. Nepřevést každou neověřenou prázdnou/selhanou odpověď na plošné smazání.

**Akceptace:** Po odstranění jediné aktivity u API-key spojení se po úspěšném úplném refreshi odstraní i místní kopie; odpověď 503/neúplný seznam historii nemaže. Ověřit i obnovení po ztraceném webhooku a párování watch kopie.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Skutečný syncIntervalsActivities, pointStatement a removeIntervalsActivities, poskytovatel pouze lokálně nahrazen kompletními testovacími odpověďmi.

## A24 — Prázdné HealthKit čtení smaže importované jídlo a pití (fixed)

**Místo:** [src/apple-food.js:94](/workspace/health-api-recheck/src/apple-food.js:94).

**Co je ověřeno:** Prázdné pole jídel/pití ze zdroje apple-health se už nepovažuje za důkaz smazání. Lokálně importováno jedno jídlo a jeden nápoj, následné meals:[]/drinks:[] vrátilo saved:0,removed:0,changed:0 a oba záznamy zůstaly.

**Co zbývá / hranice:** Původní hromadné mazání při odepřeném/prázdném čtení je opravené. Opačný regresní důsledek pro skutečné smazání posledního záznamu je samostatně NEW-APPLE-LAST-DELETE.

**Doporučení:** Zachovat ochranu historie při neověřeném čtení a doplnit explicitní mazání potvrzených HealthKit objektů; nezrušit ochranu prázdného výsledku.

**Akceptace:** Odepření čtení či obnova HealthKitu nezpůsobí ztrátu serverové historie.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Samotné chování HealthKitu na fyzickém iPhonu nebylo provedeno.

## A27 — Google export nahradí zadaný čas jídla polednem UTC (fixed)

**Místo:** [src/food-google-sync.js:22](/workspace/health-api-recheck/src/food-google-sync.js:22).

**Co je ověřeno:** Lokální consumed_at bez offsetu nyní používá zonedTime v kontextu uživatele. Původní veřejná funkce vrátila z 07:30 v Praze 05:30Z, v New Yorku 11:30Z; po konci letního času v Praze 06:30Z. Čas se již nemění na 12:00Z.

**Co zbývá / hranice:** Neplatný/chybějící timestamp zůstává na zdokumentovaném poledním fallbacku. Historické neoznačené časové hodnoty samy neumožňují obnovit původní časové pásmo při cestování; to není nová prokázaná vada této opravy.

**Doporučení:** Zachovat regresní test více pásem a změny DST; pro nové zápisy preferovat jednoznačný čas s offsetem.

**Akceptace:** Explicitně zadaná lokální hodina a den se při exportu zachovají v příslušném pásmu, v létě i zimě.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. zonedTime/withTimeZone importované přímo z aktuálního user-time.js.

## A28 — Hromadná změna jídel selže po částečném uložení (fixed)

**Místo:** [src/food-entry-management.js:123](/workspace/health-api-recheck/src/food-entry-management.js:123).

**Co je ověřeno:** Původní kopírování ids:[1,999] už nevrací chybu po úspěšném zapsání prvního jídla. Funkce vrátí status:ok, done:[nové id], skipped:[999]; route připravuje export pro úspěšné položky. Reprodukce vytvořila právě jednu kopii.

**Co zbývá / hranice:** Oprava řeší původní chybějící ID uprostřed dávky. Nový takeOver uvnitř move/PATCH má vlastní neatomický zápis (NEW-TAKEOVER-PARTIAL). Native MealDetailView navíc ignoruje skipped; je vhodné zobrazit částečný výsledek, zvlášť při skutečné chybě DB a nikoli už smazaném ID.

**Doporučení:** Zachovat explicitní done/skipped; v UI zobrazit částečný výsledek a nepřeposílat znovu již dokončené položky.

**Akceptace:** První existující a druhé již chybějící jídlo: vrácená odpověď rozlišuje dokončené/přeskočené, úspěšné změny se připraví k exportu a nevzniká důvod opakovat celou dávku.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json.

## NEW-MORNING-PUSH · P2 — Ranní připravenost se neodesílá uživatelům pouze s WHOOP nebo Ultrahuman

**Místo:** [src/entrypoint.js:258](/workspace/health-api-recheck/src/entrypoint.js:258).

**Příčina:** morningPush zůstává pouze uvnitř jobu sync, který vyžaduje Google nebo Intervals. WHOOP/Ultrahuman job jen importuje a invaliduje cache. Oddělený Apple upload morningPush vyvolává, ale WHOOP/Ultrahuman takovou cestu nemají. Nový obecný push job volá pouze coachPush.

**Dopad:** Uživatel s telefonem, souhlasem, dostatkem nočních dat a zapnutou „Ranní připraveností“, ale pouze prstenem/WHOOP, nedostane slíbenou ranní notifikaci. Při vypnutém kouči mu nový coach job nepomůže. Chyba existovala i dříve, nově je zjištěna při kontrole sousedního toku A09.

**Oprava:** Zavést samostatný obecný job ranní připravenosti pro zařízení s tokenem a povolenými notifikacemi, případně jej volat po každém relevantním importu a zajistit pravidelnou obnovu při pozdním příchodu dat. Zachovat existující once-per-day claim a časové okno.

**Akceptace:** Pouze WHOOP a pouze Ultrahuman: po příchodu dnešní noci v 5–11 lokálně, morning=true/coach=false, dorazí právě jedna ranní připravenost. Totéž pro Apple/Google/Intervals bez duplikátů.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Byly provedeny skutečné definice USER_JOBS s izolovanými send/import callbacks: WHOOP/Ultrahuman vyvolaly pouze coach, Google morning+coach. Reálné APNs nikoli.

## NEW-APPLE-LAST-DELETE · P2 — Smazání posledního jídla nebo nápoje ve Zdraví se po opravě nepromítne do Aurinu

**Místo:** [src/apple-food.js:94](/workspace/health-api-recheck/src/apple-food.js:94).

**Příčina:** Ochrana A24 nerozlišuje prázdné neověřené čtení od skutečně prázdného úplného výsledku. Jakmile jsou meals nebo drinks prázdné, readMeals/readDrinks=false a žádný známý záznam daného druhu se nemaže. Klient posílá běžný full-window snapshot bez explicitních deleted IDs.

**Dopad:** Uživatel odstraní poslední importované jídlo či nápoj v Health zdroji. Aurin jej při dalších synchronizacích ponechá, a tím může dál počítat energii nebo hydrataci, dokud nepřijde další neprázdný import nebo jej uživatel nesmaže v Aurinu. Jde o regresní důsledek bezpečnějšího řešení A24.

**Oprava:** Přenášet potvrzená smazaná HealthKit ID z anchored queries nebo jiný explicitní důkaz úplnosti. Neobnovovat nebezpečné plošné mazání na základě libovolného prázdného pole. Stav a anchor vázat na účet/server.

**Akceptace:** Import jednoho jídla a jednoho nápoje → smazání obou ve zdroji → sync odstraní pouze jejich kopie v Aurinu. Odebrání oprávnění a prázdná odpověď během obnovy HealthKitu historii nemažou.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Backend lokálně po importu jednoho jídla a nápoje a následném prázdném snapshotu zachoval oba řádky. Emitování full-window snapshotu v AppleHealthReader.foodUpload staticky ověřeno; telefon nebyl spuštěn.

## NEW-TAKEOVER-PARTIAL · P2 — Přesun importovaného jídla může při selhání vytvořit kopii a po opakování další

**Místo:** [src/food-entry-management.js:61](/workspace/health-api-recheck/src/food-entry-management.js:61).

**Příčina:** Nový takeOver provede INSERT ruční kopie samostatně a až potom hideAppleFood, který vytváří a v batchi zapisuje tombstone a maže původní import. Selhání druhého kroku nastane po již potvrzeném INSERTu. Funkci používá single PATCH i bulk move a nová kopie nemá idempotentní vazbu na originál.

**Dopad:** Při dočasném selhání D1 v druhé části dostane uživatel chybu, ale kopie už existuje a originál také. Opakování stejného původního ID vytvoří druhou kopii a teprve odstraní import. V nové cílové datum se potom započítají dvě porce. U smíšené dávky může další úspěšná položka navíc změnit chybu na tiché skipped, které klient ignoruje.

**Oprava:** Provést vložení nové položky, tombstone a odstranění původní v jediné transakční D1 batch se sdíleným a stabilním identifikátorem přesunu; validovat vše před zápisem. Přidat idempotenci pro ztracenou odpověď a v UI nezahazovat skipped.

**Akceptace:** Vynutit selhání před tombstone/delete: buď se neprovede nic, nebo je přesun jednoznačně dokončen a vrácen. Opakované single PATCH i bulk move stejné originální položky nevytvoří druhou kopii. Ověřit i souběžné opakování a ztracenou odpověď.

**Ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Do skutečného DB.batch při hideAppleFood byla vložena jednorázová simulovaná přechodná chyba. V obou skutečných veřejných helperech bulkFoodEntries(action=move,ids=[1]) a updateFoodEntry(id=1,date=...) po chybě zůstaly originál+jedna ruční kopie; po retry dvě ruční kopie a žádný originál. Nejde o pozorovaný produkční incident.

## Ověření a omezení

Reprodukční skript: [recheck-connectors-food.mjs](./recheck-connectors-food.mjs). Výsledky: [connectors-food-reproductions.json](./connectors-food-reproductions.json), [log](./connectors-food-reproductions.log).

- Žádné reálné Google Health, Intervals, Wahoo, WHOOP, Ultrahuman, APNs nebo iOS runtime.
- Lokální reprodukce zachovávají příslušné business funkce a SQL; nesouvisející importy včetně L jsou izolovány. Schéma pro cílové řádky je vytvořeno ve skutečném SQLite; nejde o celý Worker integration test.
- TakeOver porucha je řízená simulace selhání skutečného D1 batch rozhraní, nikoli prokázaný produkční výpadek.
- LRO odpověď pouze s name bez done se v izolaci stále označí sent; bez ověření konkrétního odpovědního kontraktu Google se tato hraniční varianta nepočítá jako další samostatný nález.
- Nálezy jsou nové oproti původnímu reportu; NEW-MORNING-PUSH není nutně nově zavedená regrese.

## Pokrytí

| Soubor | Rozsah |
|---|---|
| src/entrypoint.js | USER_JOBS, fanOut/runUserJobs, Intervals webhook forwarding, morningPush, Apple upload, manual exercise send |
| src/tenancy.js | usersWithPushTokens/usersWithProviders, personal table classification |
| src/user-data-routing.js | push_tokens central routing |
| src/push.js | token storage, morning readiness gating and delivery guard |
| src/wahoo.js | activity row/upsert, import and webhook paths, changed plan intensity mapping |
| src/activity-type.js | KEEP_TYPE_SQL and Wahoo manual edit branch |
| src/activity-edits.js | calorie override helper and record lookup |
| src/sync-destinations.js | activity send, LRO polling, retries, statuses, sync prefs |
| src/index.js | Intervals activity import, pointStatement, reconciliation and exact deletions |
| src/intervals-webhook.js | event mapping and deleted ID forwarding |
| src/apple-food.js | snapshot import/deduplication/deletion/hidden IDs |
| src/apple-health.js | upload call into saveAppleFood |
| src/food-google-sync.js | food timestamp conversion, queue skipping and operation state review |
| src/food-entry-management.js | single/bulk edit-copy-delete and new takeOver |
| src/routes-food.js | single and bulk response/export handling |
| src/app-food.js | from_app label mapping |
| src/google-food.js | import into shared Apple/Google food helper and empty lists |
| src/food-log.js | mealConsumedAt and normal timestamp shapes |
| src/user-time.js | timezone conversion with DST |
| ios-native/Loadwise/App/AppleHealth.swift | foodUpload snapshot and collect window |
| ios-native/Loadwise/Screens/MealDetailView.swift | bulk consumer and skipped handling |
| ios-native/Loadwise/Screens/FoodEntryEditSheet.swift | single edit caller and error path |
| ios-native/Loadwise/Data/APIClient+Food.swift | bulk DTO returns skipped |
| ios-native/Loadwise/Screens/SyncViews.swift | pending/error retry UI |
| ios-native/Loadwise/Data/SyncModels.swift | status mapping |
