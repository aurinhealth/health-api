// Original current source, real local SQLite; unrelated imports isolated only.
// No private prompt files, external calls, app edits or provider credentials.
import {readFileSync, writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {createD1} from '/workspace/health-api-recheck/tests/helpers/d1.mjs';
import {localDateTime, localToday, zonedTime, withTimeZone} from '/workspace/health-api-recheck/src/user-time.js';
import {intervalsAuthorization} from '/workspace/health-api-recheck/src/intervals-auth.js';
import {grantedExtras, hasGoogleScope, HEALTH_PERMISSIONS, HEALTH_SCOPES, EXTRA_SCOPES} from '/workspace/health-api-recheck/src/google-scopes.js';
import {healthPointJson} from '/workspace/health-api-recheck/src/health-point-json.js';
import {routedUserDb} from '/workspace/health-api-recheck/src/user-data-routing.js';
const ROOT='/workspace/health-api-recheck/src/';
const source=name=>readFileSync(ROOT+name,'utf8');
const stripped=name=>source(name).replace(/^import .*;\r?\n/gm,'').replace(/\bexport /g,'');
const L=(cs,en)=>en;
const load=(file,names,imports={})=>new Function(...Object.keys(imports),stripped(file)+'\nreturn {'+names.join(',')+'};')(...Object.values(imports));
const sync=load('sync-destinations.js',['sendActivity','saveSyncPrefs','readSyncPrefs','retrySyncSends','retrySend','activitySends','sentIntervalsIds','sentByLoadwise','googleExercise','normalizeActivity'],{L,localDateTime,intervalsAuthorization,grantedExtras,hasGoogleScope,HEALTH_PERMISSIONS});
const types=load('activity-type.js',['changeActivityType','KEEP_TYPE_SQL'],{L,intervalsAuthorization,sendActivity:sync.sendActivity});
const edits=load('activity-edits.js',['setActivityKcal'],{L});
const wahoo=load('wahoo.js',['upsert'],{L,healthPointJson,KEEP_TYPE_SQL:types.KEEP_TYPE_SQL});
const apple=load('apple-food.js',['saveAppleFood','hideAppleFood','OTHER_APP_SOURCES'],{ensureFoodLogTable:async()=>{},ensureFluidLog:async()=>{}});
const food=load('food-entry-management.js',['bulkFoodEntries','updateFoodEntry','copyFoodEntry'],{L,hideAppleFood:apple.hideAppleFood,OTHER_APP_SOURCES:apple.OTHER_APP_SOURCES,scaleMicros:v=>v});
const googleFood=load('food-google-sync.js',['foodGooglePayload'],{L,localToday,zonedTime});
const tenancy=load('tenancy.js',['usersWithPushTokens','usersWithProviders'],{L,routedUserDb});
const results=[];
function report(id,name,detail){results.push({id,name,...detail});console.log(JSON.stringify(results.at(-1)));}
const activity={key:'gym:2026-10-19',sport:'gym',name:'Gym',date:'2026-10-19',start:'2026-10-19T10:00:00Z',minutes:45};
async function googleEnv(){const DB=createD1();await sync.saveSyncPrefs(DB,7,'google',{pushActivities:true});return {DB,USER_ID:7,GOOGLE_REFRESH_TOKEN:'test-only',GOOGLE_SCOPES:[...HEALTH_SCOPES,EXTRA_SCOPES.activityWrite]};}
function healthDb(){const DB=createD1();DB.userId=7;DB.sqlite.exec(`CREATE TABLE health_datapoints(id INTEGER PRIMARY KEY,user_id INTEGER,source_family TEXT,data_type TEXT,external_id TEXT,sample_time TEXT,start_time TEXT,end_time TEXT,value_numeric REAL,value_unit TEXT,payload_json TEXT,record_role TEXT DEFAULT 'primary',matched_activity_id TEXT,match_confidence REAL,updated_at TEXT,UNIQUE(user_id,source_family,data_type,external_id))`);return DB;}
function foodDb(){const DB=createD1();DB.userId=7;DB.sqlite.exec(`CREATE TABLE food_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,consumed_date TEXT,consumed_at TEXT,cookbook_page INTEGER,recipe_title TEXT,servings REAL DEFAULT 1,kcal REAL,protein_g REAL,carbs_g REAL,fat_g REAL,fiber_g REAL,source TEXT,note TEXT);CREATE TABLE fluid_log(id INTEGER PRIMARY KEY,user_id INTEGER,date TEXT,consumed_at TEXT,ml INTEGER,kind TEXT,external_id TEXT,source TEXT,app TEXT)`);return DB;}

// A16: real edit -> original Wahoo upsert preserves both overrides.
{
 const DB=healthDb();
 const original={data_type:'activity',external_id:'wahoo:1',sample_time:'2026-10-19T09:00:00',start_time:'2026-10-19T09:00:00',end_time:'2026-10-19T10:00:00',value_numeric:null,value_unit:null,payload:{id:'wahoo:1',type:'Run',name:'Morning run',moving_time:3600,calories:600}};
 await wahoo.upsert(DB,7,original).run();
 await types.changeActivityType({DB,USER_ID:7},{id:'wahoo:1',type:'Walk'});
 await edits.setActivityKcal({DB,USER_ID:7},{id:'wahoo:1',kcal:250});
 await wahoo.upsert(DB,7,original).run();
 const payload=JSON.parse(DB.sqlite.prepare('SELECT payload_json FROM health_datapoints').get().payload_json);
 assert.equal(payload.type,'Walk');assert.equal(payload.loadwiseType,'Walk');assert.equal(payload.calories,250);assert.equal(payload.loadwiseKcal,250);
 report('A16','Wahoo override survives sync',{status:'fixed',payload});
}

// A27: actual timezone implementation and original food payload function.
{
 const row={consumed_date:'2026-10-19',consumed_at:'2026-10-19T07:30:00',recipe_title:'Breakfast',kcal:300,note:'{}'};
 const stamps=['Europe/Prague','America/New_York'].map(zone=>({zone,time:withTimeZone(zone,()=>googleFood.foodGooglePayload(row).nutritionLog.interval.startTime)}));
 assert.equal(stamps[0].time,'2026-10-19T05:30:00.000Z');assert.equal(stamps[1].time,'2026-10-19T11:30:00.000Z');
 const winter=withTimeZone('Europe/Prague',()=>googleFood.foodGooglePayload({...row,consumed_date:'2026-10-26',consumed_at:'2026-10-26T07:30:00'}).nutritionLog.interval.startTime);
 assert.equal(winter,'2026-10-26T06:30:00.000Z');
 report('A27','Food wall clock converted, including DST',{status:'fixed',stamps,winter});
}

// A22: first operation is no longer success and retry does not duplicate POST.
{
 const env=await googleEnv(),calls=[];
 let done=false;
 const record='users/me/dataTypes/exercise/dataPoints/one';
 const fetchImpl=async(url,opts={})=>{const method=opts.method||'GET';calls.push(method);return Response.json(method==='POST'?{name:'operations/one',done:false}:method==='PATCH'?{name:record}:done?{name:'operations/one',done:true,response:{name:record}}:{name:'operations/one',done:false});};
 const first=await sync.sendActivity(env,activity,{fetchImpl,googleToken:async()=>'test-token',pollMs:0});
 assert.equal(first.sends[0].status,'pending');assert.deepEqual(calls,['POST','GET','GET','GET']);
 done=true;
 const second=await sync.retrySend(env,activity.key,'google',{fetchImpl,googleToken:async()=>'test-token'});
 assert.equal(second.status,'sent');assert.deepEqual(calls.slice(4),['GET','PATCH']);
 report('A22','Pending operation is retained, later GET then PATCH',{status:'fixed-path',first:first.sends[0],second,calls});
}

// A22 remaining: pending consumes the same 3-attempt failure budget, cron stops.
{
 const env=await googleEnv(),calls=[];
 let done=false;
 const record='users/me/dataTypes/exercise/dataPoints/slow';
 const fetchImpl=async(url,opts={})=>{calls.push(opts.method||'GET');return Response.json(done?{name:'operations/slow',done:true,response:{name:record}}:{name:'operations/slow',done:false});};
 await sync.sendActivity(env,activity,{fetchImpl,googleToken:async()=>'test-token',pollMs:0});
 const cron=[];
 for(let i=0;i<2;i++){
  env.DB.sqlite.exec("UPDATE sync_sends SET updated_at=datetime('now','-10 minutes')");
  cron.push(await sync.retrySyncSends(env,{fetchImpl,googleToken:async()=>'test-token'}));
 }
 const before=env.DB.sqlite.prepare('SELECT status,remote_id,attempts FROM sync_sends').get();
 assert.equal(before.attempts,3);assert.equal(before.status,'pending');
 done=true;env.DB.sqlite.exec("UPDATE sync_sends SET updated_at=datetime('now','-10 minutes')");
 const callsBefore=calls.length,stuck=await sync.retrySyncSends(env,{fetchImpl,googleToken:async()=>'test-token'});
 assert.deepEqual(stuck,[]);assert.equal(calls.length,callsBefore);
 report('A22','Completed operation remains pending after retry budget',{status:'remaining',before:{...before},cronRuns:cron.length,readyProviderButCronReads:stuck.length});
}

// A22 contract edge: name-only operations are still marked sent (no poll).
{
 const env=await googleEnv(),calls=[];
 const r=await sync.sendActivity(env,activity,{fetchImpl:async(url,opts)=>{calls.push(opts.method);return Response.json({name:'operations/name-only'});},googleToken:async()=>'test-token',pollMs:0});
 assert.equal(r.sends[0].status,'sent');assert.deepEqual(calls,['POST']);
 report('A22','Operation with omitted done is treated as success',{status:'contract-edge',send:r.sends[0],calls});
}

// A23: original importer, SQL upsert and removal, provider and clock isolated.
{
 const full=source('index.js');
 const point=full.slice(full.indexOf('function pointStatement('),full.indexOf('// GOOGLE NUTRITION API',full.indexOf('function pointStatement('))).replace(/\/\/ =+\n/g,'');
 const date=full.slice(full.indexOf('function dateDaysFromDate('),full.indexOf('function dateOnly(',full.indexOf('function dateDaysFromDate(')));
 const activities=full.slice(full.indexOf('function activityNumber('),full.indexOf('async function syncIntervalsEvents('));
 let answer=[{id:'i1',type:'Run',start_date_local:'2026-10-19T10:00:00',moving_time:3600}];
 const importer=new Function('dateDaysAgo','dateDaysFromNow','intervalsGet','sentIntervalsIds','readSyncPrefs','sentByLoadwise','CONFIG','KEEP_TYPE_SQL','healthPointJson',date+'\n'+point+'\n'+activities+'\nreturn syncIntervalsActivities;')(()=> '2026-10-01',()=> '2026-10-21',async()=>answer,sync.sentIntervalsIds,sync.readSyncPrefs,sync.sentByLoadwise,{activityDays:365},types.KEEP_TYPE_SQL,healthPointJson);
 const DB=healthDb(),env={DB,USER_ID:7};
 DB.sqlite.exec("INSERT INTO health_datapoints(user_id,source_family,data_type,external_id,start_time,payload_json) VALUES(7,'intervals','activity','activity:i1','2026-10-19T10:00:00','{}'),(7,'intervals','activity','activity:i2','2026-10-19T11:00:00','{}');INSERT INTO health_datapoints(user_id,source_family,data_type,external_id,start_time,payload_json,record_role,matched_activity_id) VALUES(7,'apple-health','exercise','watch2','2026-10-19T09:00:00Z','{}','duplicate','intervals:activity:i2')");
 const nonempty=await importer(env);
 assert.equal(nonempty.activities_removed,1);
 assert.equal(DB.sqlite.prepare("SELECT record_role FROM health_datapoints WHERE external_id='watch2'").get().record_role,'primary');
 answer=[];
 const empty=await importer(env);
 const retained=DB.sqlite.prepare("SELECT COUNT(*) n FROM health_datapoints WHERE source_family='intervals'").get().n;
 assert.equal(retained,1);
 const named=await importer(env,{deleted:'i1'});
 assert.equal(DB.sqlite.prepare("SELECT COUNT(*) n FROM health_datapoints WHERE source_family='intervals'").get().n,0);
 report('A23','Nonempty and named deletion repaired; last activity retained on empty refresh',{status:'partial',nonempty,empty,retainedAfterCompleteEmpty:retained,named});
}

// A24: denied/empty Apple read now keeps history; last-item deletion not reconciled.
{
 const DB=foodDb();
 const input={from:'2026-10-19',to:'2026-10-20',meals:[{id:'meal-one',date:'2026-10-19',kcal:500,name:'Meal'}],drinks:[{id:'water-one',date:'2026-10-19',ml:250}]};
 await apple.saveAppleFood(DB,7,input);
 const empty=await apple.saveAppleFood(DB,7,{...input,meals:[],drinks:[]});
 assert.equal(empty.removed,0);
 const counts={meals:DB.sqlite.prepare('SELECT COUNT(*) n FROM food_logs').get().n,drinks:DB.sqlite.prepare('SELECT COUNT(*) n FROM fluid_log').get().n};
 assert.deepEqual(counts,{meals:1,drinks:1});
 report('A24','Empty/denied read does not delete imported history',{status:'fixed-path',empty,counts});
 report('NEW-APPLE-LAST-DELETE','Deleting last imported meal/drink stays stale indefinitely',{status:'regression',providerNow:{meals:0,drinks:0},aurin:counts});
}

// A28: original missing-ID copy now returns per-item success instead of 400.
{
 const DB=foodDb();DB.sqlite.exec("INSERT INTO food_logs(user_id,consumed_date,consumed_at,recipe_title,kcal,source,note) VALUES(7,'2026-10-19','2026-10-19T07:30:00','Breakfast',300,'manual','{}')");
 const r=await food.bulkFoodEntries(DB,{action:'copy',ids:[1,999],date:'2026-10-20'});
 assert.equal(r.done.length,1);assert.deepEqual(r.skipped,[999]);
 assert.equal(DB.sqlite.prepare("SELECT COUNT(*) n FROM food_logs WHERE consumed_date='2026-10-20'").get().n,1);
 report('A28','Original partial-copy failure now reports done and skipped',{status:'fixed-path',result:r});
}

// New takeOver path can still commit then fail, inside either PATCH or bulk move.
for (const mode of ['bulk', 'single']) {
 const DB=foodDb();DB.sqlite.exec("INSERT INTO food_logs(user_id,consumed_date,consumed_at,recipe_title,kcal,source,note) VALUES(7,'2026-10-19','2026-10-19T07:30:00','Imported breakfast',300,'apple-health','{\"external_id\":\"hk:1\",\"app\":\"Yazio\"}')");
 const batch=DB.batch;
 let fail=true;
 DB.batch=async statements=>{if(fail){fail=false;throw new Error('Injected transient D1 batch failure');}return batch(statements);};
 let failed='';
 const change=()=>mode==='bulk'?food.bulkFoodEntries(DB,{action:'move',ids:[1],date:'2026-10-20'}):food.updateFoodEntry(DB,1,{date:'2026-10-20'});
 try{await change();}catch(error){failed=error.message;}
 assert.match(failed,/transient D1/);
 const afterFailure=DB.sqlite.prepare('SELECT source,consumed_date,COUNT(*) n FROM food_logs GROUP BY source,consumed_date').all().map(r=>({...r}));
 assert.equal(DB.sqlite.prepare("SELECT COUNT(*) n FROM food_logs WHERE source='manual'").get().n,1);
 const retry=await change();
 const afterRetry=DB.sqlite.prepare('SELECT source,consumed_date,COUNT(*) n FROM food_logs GROUP BY source,consumed_date').all().map(r=>({...r}));
 assert.equal(DB.sqlite.prepare("SELECT COUNT(*) n FROM food_logs WHERE source='manual'").get().n,2);
 report('NEW-TAKEOVER-PARTIAL','Imported meal move partially commits, error then retry duplicates',{status:'confirmed',mode,failed,afterFailure,retry,afterRetry});
}

// A09 and adjacent morning push: real jobs and fan-out selection, send functions stubbed.
{
 const full=source('entrypoint.js'),begin=full.indexOf('const minute = (cron,'),end=full.indexOf('const worker =',begin);
 const calls=[];
 const fns=new Function('usersWithProviders','usersWithPushTokens','pushConfigured','isReviewAccount','app','localHour','morningPush','coachPush','syncWhoop','syncUltrahuman','bumpCacheVersion',full.slice(begin,end).replace(/\bexport /g,'')+'\nreturn {fanOutUserJobs,USER_JOBS};')(tenancy.usersWithProviders,tenancy.usersWithPushTokens,env=>Boolean(env.APNS_KEY_P8),()=>false,{scheduled:async()=>{}},()=>8,async()=>{calls.push('morning');},async()=>{calls.push('coach');},async()=>({saved:1}),async()=>({saved:1}),async()=>{});
 const DB=createD1();DB.sqlite.exec("CREATE TABLE users(id INTEGER PRIMARY KEY,email TEXT,name TEXT,role TEXT,disabled INTEGER);CREATE TABLE connection_credentials(user_id INTEGER,provider TEXT);CREATE TABLE user_consents(user_id INTEGER,kind TEXT,withdrawn_at TEXT);CREATE TABLE push_tokens(user_id INTEGER,token TEXT)");
 for(const [id,provider] of [[1,null],[2,'whoop'],[3,'ultrahuman'],[4,'google'],[5,'intervals']]){DB.sqlite.prepare("INSERT INTO users VALUES(?,?,'User','user',0)").run(id,'user'+id+'@example.invalid');DB.sqlite.prepare("INSERT INTO user_consents VALUES(?,'health',NULL)").run(id);DB.sqlite.prepare('INSERT INTO push_tokens VALUES(?,?)').run(id,'t'+id);if(provider)DB.sqlite.prepare('INSERT INTO connection_credentials VALUES(?,?)').run(id,provider);}
 const selected=[];
 await fns.fanOutUserJobs({DB,APNS_KEY_P8:'test-only',USER_JOBS:{run:async m=>{selected.push(m.user.id);return {ok:true};}}},{},{cron:'* * * * *',scheduledTime:Date.parse('2026-10-19T07:25:00Z')});
 assert.deepEqual(selected.sort(),[1,2,3,4,5]);
 report('A09','Users with phones selected across providers',{status:'fixed',selected});
 const perProvider=[];
 for(const connected of [['whoop'],['ultrahuman'],['google']]){
  calls.length=0;
  const jobs=fns.USER_JOBS.filter(j=>j.due('* * * * *',new Date('2026-10-19T07:25:00Z'))&&(j.push||j.providers.some(p=>connected.includes(p))));
  for(const job of jobs.filter(j=>['sync','coach-push','whoop','ultrahuman'].includes(j.name)))await job.run({CONNECTED_PROVIDERS:connected},{},{cron:'* * * * *',scheduledTime:Date.parse('2026-10-19T07:25:00Z')});
  perProvider.push({connected,jobs:jobs.map(j=>j.name),notificationCalls:[...calls]});
 }
 assert.deepEqual(perProvider[0].notificationCalls,['coach']);assert.deepEqual(perProvider[1].notificationCalls,['coach']);assert.deepEqual(perProvider[2].notificationCalls,['morning','coach']);
 report('NEW-MORNING-PUSH','WHOOP and Ultrahuman-only never invoke morning readiness push',{status:'confirmed-selection',perProvider});
}

writeFileSync('/workspace/aurin-reaudit-2026-10-20/connectors-food-reproductions.json',JSON.stringify(results,null,2)+'\n');
