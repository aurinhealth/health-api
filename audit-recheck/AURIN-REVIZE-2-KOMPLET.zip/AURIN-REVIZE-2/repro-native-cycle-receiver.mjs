// Actual current cycle route + store, SQLite. Surrounding authentication/language/time isolated.
// This verifies the receiving side of the static native account-switch trace, not iOS runtime.
import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import * as model from '/workspace/health-api-recheck/src/cycle-model.js';
import { createD1 } from '/workspace/health-api-recheck/tests/helpers/d1.mjs';
const repo = '/workspace/health-api-recheck/';
const strip = source => source.replace(/^import .*;\n/gm, '').replace(/\bexport /g, '');
const storeSource = strip(readFileSync(repo + 'src/cycle-store.js', 'utf8'));
const language = (cs, en) => en;
const store = new Function('normalizeCycleSettings', 'normalizeCycleDay', 'SYMPTOMS', 'L', storeSource + '\nreturn {getCycleSettings,saveCycleSettings,listCycleDays,saveCycleDay,importAppleCycle};')(model.normalizeCycleSettings, model.normalizeCycleDay, model.SYMPTOMS, language);
const routeSource = strip(readFileSync(repo + 'src/routes-cycle.js', 'utf8'));
const handler = new Function(...Object.keys(store), 'cycleState', 'cycleMonth', 'askPeriodToday', 'L', 'localToday', routeSource + '\nreturn handleCycleApi;')(...Object.values(store), model.cycleState, model.cycleMonth, model.askPeriodToday, language, () => '2026-10-20');
const db = createD1();
db.userId = 22;
const before = await store.getCycleSettings(db);
assert.equal(before.enabled, false);
const url = new URL('https://example.invalid/app/api/cycle/apple');
const request = new Request(url, {method:'POST',headers:{Origin:url.origin,'Content-Type':'application/json'},body:JSON.stringify({days:[{date:'2026-10-19',flow:3,ovulationTest:true,symptoms:['hot_flashes']}]})});
const response = await handler(request, {DB:db}, {}, url, {signedIn:true});
assert.equal(response.status, 200);
const body = await response.json();
const row = db.sqlite.prepare('SELECT user_id,date,apple_flow,apple_ovulation,apple_symptoms FROM cycle_days').get();
assert.equal(row.user_id, 22);
assert.equal(row.apple_flow, 3);
assert.equal((await store.getCycleSettings(db)).enabled, false);
const result = {scope:'original route/store with synthetic signed-in B context; native switch trace reviewed statically', cycleEnabled:before.enabled, status:response.status, body, row};
writeFileSync('/workspace/aurin-reaudit-2026-10-20/native-cycle-receiver-result.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
