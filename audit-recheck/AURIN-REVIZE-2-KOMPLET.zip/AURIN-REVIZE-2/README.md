# Aurin — druhá revize, 21. října 2026

Revidovaný commit: `775c79b1432d743a1d503f803214dda348f555ed` v repozitáři `aurinhealth/health-api` (původně `shaarkyn/health-api`, stejné ID projektu).

- **AURIN-REVIZE-2.pdf**: hlavní 22stránkový report.
- **AURIN-REVIZE-2.md**: stejný report v textu, s odkazy na přesný commit.
- **STAV-OPRAV.csv**: všech 33 původních nálezů, 24 opravených a 9 částečných.
- **ZBYVAJICI-OPRAVY.csv**: 22 zbývajících úkolů, tedy 9 nedokončených oprav a 13 nových nálezů.
- **nalezy-sloucene.json** a **POKRYTI.csv**: strukturované výsledky a hloubka zdrojové kontroly.

Dílčí reporty vznikly nad commitem `74a459d`. Doplněk `delta-21-10` kontroluje dalších 8 commitů do `775c79b`; šest hlavních reprodukčních skriptů a browserový průchod byly zopakovány nad novějším kódem. Souhrnný report odlišuje statické ověření od skutečného provedení.

Výsledky `tests-current.tap` jsou z aktuálního commitu: 241 testových souborů, 26 úspěšných a 215 neúspěšných, dominantně kvůli chybějícím soukromým modulům už při importu. Nejde o 215 potvrzených vad produktu. iOS runtime a skuteční poskytovatelé nebyli spuštěni. `final-reproduction-verification.json` uvádí výsledky cílených kontrol.

Skripty jsou důkazní materiál z lokálního auditního prostředí. Obsahují jeho cesty `/workspace/health-api-recheck`; pro opakování jinde uprav kořen projektu. Dva VM moduly vyžadují `node --experimental-vm-modules`. Případné klíče, adresy a zdravotní údaje v lokálních reprodukcích jsou syntetické testovací hodnoty.

Dočasná GitHub větev slouží pouze k předání dokumentů. Po potvrzení stažení ji lze smazat. Aplikační zdroje nebyly měněny a není potřeba ji slučovat.
