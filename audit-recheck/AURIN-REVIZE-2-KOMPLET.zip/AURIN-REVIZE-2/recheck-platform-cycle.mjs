// Real current public cycle model/store/routes with isolated language dependency, real SQLite.
import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import * as model from '/workspace/health-api-recheck/src/cycle-model.js';
import {createD1} from '/workspace/health-api-recheck/tests/helpers/d1.mjs';
const root='/workspace/health-api-recheck';
const source=readFileSync(root+'/src/cycle-store.js','utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const store=new Function('normalizeCycleSettings','normalizeCycleDay','SYMPTOMS','L',source+'\nreturn {saveCycleSettings,saveCycleDay,listCycleDays,getCycleSettings};')(model.normalizeCycleSettings,model.normalizeCycleDay,model.SYMPTOMS,(cs,en)=>en);
const routeSource=readFileSync(root+'/src/routes-cycle.js','utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const {cycleView}=new Function('getCycleSettings','listCycleDays','cycleState','cycleMonth','askPeriodToday',routeSource+'\nreturn {cycleView};')(store.getCycleSettings,store.listCycleDays,model.cycleState,model.cycleMonth,model.askPeriodToday);
const results={};
{
 const db=createD1();db.userId=7;
 await store.saveCycleSettings(db,{enabled:true,contraception:'pill',packStart:'2026-10-01'});
 const saved=await store.saveCycleDay(db,{date:'2026-10-19',pill:true});
 const days=await store.listCycleDays(db,'2026-10-01','2026-10-31');
 const month=model.cycleMonth({settings:{enabled:true,contraception:'pill',packStart:'2026-10-01'},days,today:'2026-10-20'},'2026-10');
 assert.equal(saved.pill,'taken');assert.equal(days[0].pill,'taken');assert.equal(month.find(d=>d.date==='2026-10-19').pill,'taken');
 const time=await store.saveCycleDay(db,{date:'2026-10-19',pill:'21:04'});assert.equal(time.pill,'21:04');
 const cleared=await store.saveCycleDay(db,{date:'2026-10-19',pill:null});assert.equal(cleared.pill,null);
 assert.equal(model.normalizeCycleDay(model.normalizeCycleDay({date:'2026-10-19',pill:true})).pill,'taken');
 const canonical=await store.saveCycleDay(db,{date:'2026-10-19',pill:'taken'});
 results.A33={saved:saved.pill,loaded:days[0].pill,calendar:month.find(d=>d.date==='2026-10-19').pill,time:time.pill,cleared:cleared.pill,canonicalApiInput:canonical.pill};
}
{
 const db=createD1();db.userId=8;
 await store.saveCycleSettings(db,{enabled:true,lastPeriod:'2026-01-10'});
 await store.saveCycleDay(db,{date:'2026-01-10',flow:3,symptoms:['cramps']});
 const stored=(await store.listCycleDays(db,'2026-01-01','2026-01-31'))[0];
 const response=await cycleView(db,'2026-10-20','2026-01');
 const shown=response.days.find(d=>d.date==='2026-01-10');
 assert.equal(stored.flow,3);assert.equal(shown.flow,0);assert.deepEqual(shown.symptoms,[]);
 const edited=await store.saveCycleDay(db,{date:shown.date,flow:shown.flow,symptoms:['headache']});
 assert.equal(edited.flow,0);
 results.oldCalendar={stored,shown,afterEditingShownDay:edited,month:response.month};
}
{
 const db=createD1();db.userId=9;
 await store.saveCycleDay(db,{date:'2026-10-19',flow:0,symptoms:[]});
 await Promise.all([store.saveCycleDay(db,{date:'2026-10-19',flow:3}),store.saveCycleDay(db,{date:'2026-10-19',symptoms:['cramps']})]);
 const day=(await store.listCycleDays(db,'2026-10-19','2026-10-19'))[0];
 assert.deepEqual(day.symptoms,['cramps']);assert.equal(day.flow,0);
 results.concurrentPatch={expected:{flow:3,symptoms:['cramps']},actual:day};
}
{
 const db=createD1();db.userId=10;
 await store.saveCycleSettings(db,{enabled:true,shareWithCoach:true});
 await Promise.all([store.saveCycleSettings(db,{shareWithCoach:false}),store.saveCycleSettings(db,{pillReminderTime:'22:00'})]);
 const settings=await store.getCycleSettings(db);
 assert.equal(settings.shareWithCoach,true);assert.equal(settings.pillReminderTime,'22:00');
 results.concurrentSettings={requestedSharing:false,actualSharing:settings.shareWithCoach,pillReminderTime:settings.pillReminderTime};
}
{
 const db=createD1();db.userId=11;
 await store.saveCycleSettings(db,{enabled:true,contraception:'pill',packStart:'2026-10-01'});
 await store.saveCycleDay(db,{date:'2026-10-20',pill:'21:04'});
 const current=await cycleView(db,'2026-10-20','2026-10');
 const previous=await cycleView(db,'2026-10-20','2026-09');
 assert.equal(current.state.pill.taken,'21:04');assert.equal(previous.state.pill.taken,null);
 results.previousMonthCurrentState={currentMonthPill:current.state.pill.taken,previousMonthPill:previous.state.pill.taken,currentStateDate:previous.state.date};
}
writeFileSync('/workspace/aurin-reaudit-2026-10-20/platform-cycle-reproduction.json',JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
