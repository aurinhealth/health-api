# Závěrečná nezávislá kontrola vybraných důkazů

Kontrolovaný zdroj: `775c79b1432d743a1d503f803214dda348f555ed` (21. 10. 2026). Podklady: `connectors-food.json`, `training-metrics.json`, oba jejich reprodukční skripty a přímé čtení původních implementací i volajících cest. Tato kontrola aplikaci neměnila, nevolala externí služby a nevydává izolovaný composer za reálné volání AI.

## Závěr pro sloučení

U žádného z pěti přidělených případů jsem nenašel vyvracející kontrolu nebo nedosažitelnou podmínku. A08 a A18 zůstávají částečně opravené. Tři přidělené nové případy lze zachovat jako samostatné P2. Ostatních deset nových případů tato kontrola znovu nehodnotí; společně s jejich samostatnými již uloženými kontrolami není důvod kvůli těmto pěti případům snižovat souhrnných 13 nových nálezů.

## NEW-APPLE-LAST-DELETE — potvrzuji, nový P2

`saveAppleFood` v `src/apple-food.js:94–95` považuje pole Apple Health za přečtené pouze při neprázdném seznamu. `removedMeals` a `removedDrinks` na řádcích 136 a 154 jsou při prázdných seznamech vždy prázdné, i když dříve importované řádky existují. Nejde o tvrzení, že každá prázdná odpověď je autoritativní: dvě různé skutečnosti mají nyní stejný přenosový formát a server je nemůže rozlišit.

Dosažitelný zdrojový scénář potvrzuje `AppleHealthReader.foodUpload`: čte aktuální korelace/energy/water v okně a vrací pole bez seznamu smazaných UUID (`AppleHealth.swift:695–736`). Běžný sběr tuto funkci volá pro posledních 30 dní. Po skutečném smazání poslední cizí položky daného druhu vrátí prázdné pole a stávající řádek v Aurinu zůstane. Žádná alternativní explicitní delete cesta či předávání anchorů v této implementaci není.

Reprodukce konektorového reportu dokazuje odpovídající serverovou reakci přes původní funkci a skutečný SQLite; fyzické smazání v HealthKitu nebylo spuštěno. P2 odpovídá zastaralému součtu energie/hydratace. Jde o funkční regresi zavedenou ochranou A24, nikoli důvod vrátit nebezpečné plošné mazání. Správná oprava je explicitní potvrzená změna/smazání (např. HKDeletedObject přes anchored query), ne znovuzavedení mazání po libovolném prázdném poli. A24 lze současně uzavřít pro původní scénář ochrany historie při nedostupném čtení.

## A08 — potvrzuji částečnou opravu, P2

`committedRunMinutes` v `week-planner.js:353` je explicitně `Math.max(planned, done)` pro dnešek. `adaptive-week.js:146` do něj předává součty všech plánovaných a všech dokončených běhů, nikoli páry konkrétních aktivit. Tentýž helper se používá i v `entrypoint.js:741`. Dva odlišné 30min běhy (ranní dokončený a večerní plánovaný) tak přidají jen 30, i když již obsazují 60 min. Následná alokace dalších 30 min při limitu 60 je skutečná chyba v kontraktu limitu. Není nutné tvrdit, že všechny plánované a dokončené položky jsou vždy různé: skutečně spárovaný plán se svým dokončením se má nadále započítat jednou.

## A18 — potvrzuji částečnou opravu pouze pro legacy plány

`getWorkout` v `workout-library.js:70–75` nejprve čte neměnnou kopii, ale pro stará `own-<id>` čte měnitelný `saved_workouts`. V aktuálním stromu není doplnění starých vazeb na neměnné kopie. `/workouts/planned` v `entrypoint.js:2321–2327` preferuje právě tuto library hodnotu před uloženým eventem, takže editace stále existující šablony opravdu změní dřívější detail.

**Upřesnění dopadu po smazání:** netvrdit, že všechny kalendářové události nebo všechny jejich detaily zmizí. Pokud existuje uložený provider/lokální event, `/workouts/planned` i `plannedWorkout` umějí přejít na jeho obsah. Přesto `scheduledLink` při nedostupném workoutu vrací null a `pendingScheduledWorkouts` takovou položku vynechává. Nové snapshoty opravou chráněné jsou; zbývající požadavek je upgrade dřívějších dat, nikoli odmítnutí celé opravy.

## N-training-snapshot-race — potvrzuji nový P2

`plannedCopy` v `workout-templates.js:103–110` provádí oddělený SELECT shodného obsahu a INSERT s náhodným ID. Jediná primární unikátnost kopie je `(user_id,id)`; neexistuje obsahový unikátní klíč ani atomické získání jediné kopie. Dva requesty mohou oba dokončit SELECT před prvním INSERT. Bariéra v reprodukci řídí dosažitelný souběh, nenahrazuje vlastní SQL výsledky nebo zápisy.

Skutečná schedule route na řádcích 216–227 používá výsledné ID ve workoutu. Dvě ID vytvářejí dvě odlišná `external_id`, takže běžná deduplikace kalendáře je nespojí. Globální `idempotentRoute` pokrývá jen food/log, fluids a weight, ne tuto route. Komentář `plannedCopy` přitom výslovně stanoví opakované použití stejné nezměněné kopie. Nejde tedy jen o neškodné dvě identické databázové kopie bez dopadu. Reprodukce se skutečným lokálním schedulingem a SQLite dokazuje dvě události; skutečná doručení providerům nebyla testována.

## N-training-compose-budget — potvrzuji nový P2 s omezením důkazu

`libraryDay` v `entrypoint.js:2346–2352` nastaví `maxDurationMinutes` podle denního rozpočtu při automatické délce. Běžné hledání v `workout-library.js:121–135` konečnou délku kandidáta omezuje. `/compose` na řádcích 2368–2384 tuto mez dál nepoužije. Composer validuje původní strukturu s tolerancí ±5 min (`ai-workout-compose.js:156–161`), potom route použije `renderForEnvironment` bez další kontroly denního limitu.

Struktura 5+25+5 minut při zadání 30 min je podle skutečného validátoru přípustná; venkovní adaptace zahřátí prodlouží konečnou délku na 45 min. Izolovaný composer v testu vrací přípustný výsledek a skutečná route dokazuje absenci konečné kontroly. Nativní `TrainingLibrary.compose` vrácenou kartu přijímá bez vlastní délkové kontroly. Podmínky lze získat běžným automatickým výběrem délky s 30min rozpočtem a venkovním prostředím.

**Omezení:** důkaz říká „server přijme a vrátí takový platný výstup AI“, nikoli „model ho vždy či s určitou četností vytvoří“. Soukromé prompty ani model nebyly volány. Oprava má přesto vynucovat tvrdý limit na konečném renderu, protože samotná instrukce modelu takovou serverovou podmínku nezaručuje.

## Aktuálnost

V deltě `74a459d..775c79b` se nezměnily rozhodující implementace `week-planner`, `workout-templates`, `workout-library`, `ai-workout-compose`, `apple-food` ani `AppleHealth`. Změny `entrypoint` zde přidávají HEAD pro veřejné stránky a mění text potvrzení week_sport; posunuly řádky, nikoli rozebrané mechanismy. Citace výše jsou vztaženy k aktuálnímu commitu 775c79b.
