// Independent peer check through original API routes and scoped DB facade.
// Only language and the current-date clock are isolated; no external services.
import vm from 'node:vm';
import {readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createD1} from '/workspace/health-api-recheck/tests/helpers/d1.mjs';
const root='/workspace/health-api-recheck/src',today='2026-10-20';
const context=vm.createContext({console,Date,Number,Math,Map,Set,WeakMap,WeakSet,Symbol,RegExp,JSON,URL,Request,Response,Headers});
const cache=new Map();
async function load(file) {
 if(cache.has(file))return cache.get(file);
 const name=path.basename(file),vals=name==='lang.js'?{L:(cs,en)=>en}:name==='user-time.js'?{localToday:()=>today}:null;
 const m=vals?new vm.SyntheticModule(Object.keys(vals),function(){for(const[k,v]of Object.entries(vals))this.setExport(k,v);},{context,identifier:file}):new vm.SourceTextModule(readFileSync(file,'utf8'),{context,identifier:file});
 cache.set(file,m);await m.link((s,r)=>load(path.resolve(path.dirname(r.identifier),s)));return m;
}
const tenancy=await load(path.join(root,'tenancy.js'));await tenancy.evaluate();
const routes=await load(path.join(root,'routes-cycle.js'));await routes.evaluate();
const raw=createD1(),db=tenancy.namespace.scopedDb(raw,7),env={DB:db};
const call=async(pathname,body)=>{
 const url=new URL('https://aurin.health'+pathname);
 const request=body===undefined?new Request(url):new Request(url,{method:'POST',headers:{Origin:url.origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
 const response=await routes.namespace.handleCycleApi(request,env,{},url,{signedIn:true});
 assert.equal(response.status,200);
 return await response.json();
};
const results={};
await call('/app/api/cycle/settings',{enabled:true,shareWithCoach:true,contraception:'pill',packStart:'2026-10-01'});
await call('/app/api/cycle/day',{date:today,pill:'21:04'});
const current=await call('/app/api/cycle?month=2026-10');
const previous=await call('/app/api/cycle?month=2026-09');
assert.equal(current.state.pill.taken,'21:04');assert.equal(previous.state.pill.taken,null);
results.monthState={date:previous.state.date,currentMonthTaken:current.state.pill.taken,previousMonthTaken:previous.state.pill.taken};

await call('/app/api/cycle/day',{date:'2026-01-10',flow:3,symptoms:['cramps']});
const old=await call('/app/api/cycle?month=2026-01');
const shown=old.days.find(d=>d.date==='2026-01-10');
assert.equal(shown.flow,0);assert.equal(shown.symptoms.length,0);
await call('/app/api/cycle/day',{date:shown.date,month:old.month,flow:shown.flow,symptoms:['headache']});
assert.equal(raw.sqlite.prepare("SELECT flow FROM cycle_days WHERE user_id=7 AND date='2026-01-10'").get().flow,0);
results.oldCalendar={storedFlowBefore:3,shownFlow:shown.flow,storedFlowAfterEditingOtherField:0};

await call('/app/api/cycle/day',{date:'2026-10-19',flow:0,symptoms:[]});
await Promise.all([
 call('/app/api/cycle/day',{date:'2026-10-19',flow:3}),
 call('/app/api/cycle/day',{date:'2026-10-19',symptoms:['cramps']})
]);
const finalDay=raw.sqlite.prepare("SELECT flow,symptoms FROM cycle_days WHERE user_id=7 AND date='2026-10-19'").get();
assert.equal(finalDay.flow,0);assert.deepEqual(JSON.parse(finalDay.symptoms),['cramps']);
results.dayPatches={expectedFlow:3,actualFlow:finalDay.flow,actualSymptoms:JSON.parse(finalDay.symptoms)};

await Promise.all([
 call('/app/api/cycle/settings',{shareWithCoach:false}),
 call('/app/api/cycle/settings',{pillReminderTime:'22:00'})
]);
const settings=JSON.parse(raw.sqlite.prepare('SELECT settings_json FROM cycle_settings WHERE user_id=7').get().settings_json);
assert.equal(settings.shareWithCoach,true);assert.equal(settings.pillReminderTime,'22:00');
results.settingsPatches={requestedShareWithCoach:false,actualShareWithCoach:settings.shareWithCoach,actualReminder:settings.pillReminderTime};
writeFileSync('/workspace/aurin-reaudit-2026-10-20/auth-peer-cycle-routes.json',JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
