# Druhá revize: nativní uživatelské toky

Revidovaný commit: `74a459d0f99fa6503e4e37035777915921427a06`. Původní: `02d575e570a179a5c156bcc9708877a2c18f3de8`.

**Pět přidělených původních bodů má opravenou zdrojovou cestu. Dva nové P2 nálezy vyžadují opravu.** Nativní runtime nebyl dostupný; nejde o tvrzení, že scénáře proběhly na telefonu.

## Původní body

### A06 · fixed · Starší úprava cviku přepíše později dokončenou sérii

Místo: `ios-native/Loadwise/Screens/TrainingModeView.swift:976`.

saveEdited ukládá edited přes model.saveGym na ř.986 před prvním loadMuscles na ř.991; add totéž na ř.1009 před metadata na ř.1014. AppModel.saveGym ř.1061–1076 řadí přijaté snapshoty stejného dne. Původní zadržení gymMuscles už neodloží starší zápis za dokončení série.

Zbývá: Původní metadata race odstraněn. Odděleně byl nalezen dosud neřešený případ zahazování pending snapshotu po chybě předchozího požadavku (NF01).

Regrese: Zpozdit gymMuscles, přidat či upravit cvik a dokončit sérii; po reloadu musí zůstat hotová.

Ověření: Statická kontrola implementace, volajících a diffu. Xcode/Swift runtime není dostupný; scénář nebyl spuštěn na telefonu.

### A13 · fixed · Chyba potvrzení návrhu odstraní možnost opakování

Místo: `ios-native/Loadwise/Screens/CoachView.swift:305`.

Bubble má oddělené failed a decided; catch decide ukládá do failed na ř.316. Jen úspěch plní decided na ř.311. ActionCard ř.471–495 nadále zobrazuje tlačítka, pokud result chybí, a chybovou zprávu zvlášť. Opakování používá stejné draftId.

Zbývá: Potřeba nativně ověřit timeout, odmítnutí a následný úspěch. Současné klikání během požadavku je odlišné obecné riziko, pro tento stav neoznačeno jako potvrzená nová chyba.

Regrese: Při neúspěchu zůstanou Potvrdit/Ne a chyba; opakování stejného návrhu po úspěchu přepne kartu na výsledek.

Ověření: Staticky potvrzená větev catch i vykreslování karty; neproveden SwiftUI runtime test.

### A14 · fixed · Přepnutí dne dovoluje zapisovat podle starých odpovědí

Místo: `ios-native/Loadwise/Screens/JournalViews.swift:345`.

Sekce odpovědí se při day.date != date nevykreslují (ř.345–355). load ř.491–500 zachytí asked a odmítá odpověď i chybu jiného dne. Výsledek fixed/save se aplikuje jen při saved.date == date (ř.539,564).

Zbývá: Chyba GET nemá samostatné tlačítko retry, ale starý formulář nepovolí. Dlouhodobější pořadí změn stejného dne nebylo runtime ověřeno.

Regrese: Přepnout A→B, zadržet či shodit B GET; odpovědi A nesmí být upravitelné pod B. Opožděný GET/POST A nesmí nahradit zobrazené B.

Ověření: Statický průchod weekStrip→load→answer/save včetně modal JournalValueSheet; bez nativního runtime.

### A15 · fixed · Selhání načtení gymu může automaticky přepsat uložený trénink

Místo: `ios-native/Loadwise/Screens/GymLive.swift:337`.

LiveGym.load při gymDay chybě nastaví error a vrátí se před ensureHeader/markStarted/day/persist (ř.337–343). AppModel.gymDay ř.1088 odmítá status partial; DTO GymDay status nyní dekóduje. Chybové UI ř.57–70 nabízí zkusit znovu a zpět.

Zbývá: Offline je záměrně umožněn poslední existující cache; bez cache chyba nevede k prázdnému autosave. Neověřeno na iOS.

Regrese: GET 500, síťová chyba bez cache i HTTP200/status partial nesmí vyvolat POST náhradního dne; úspěšný retry načte původní série.

Ověření: Staticky ověřen celý tok API DTO→AppModel→LiveGym včetně místa prvního persist; runtime nedostupný.

### A31 · fixed · Neúspěšné smazání receptu vypadá jako úspěšné

Místo: `ios-native/Loadwise/Screens/AddFoodSheet.swift:273`.

Odstranění položky recipes.removeAll ř.276 je uvnitř do až za úspěšným await deleteRecipe ř.275. Catch ř.277–278 pouze nastaví notice; recept zůstane v seznamu.

Zbývá: Nativní viditelnost globálního notice a chování při ztracené odpovědi nebyly fyzicky ověřeny.

Regrese: Vynutit odmítnutí nebo chybu smazání: recept zůstane a zobrazí se chyba. Po úspěchu zmizí.

Ověření: Statická kontrola akce contextMenu a success/catch větví; bez nativního runtime.

## Nově zjištěné chyby

### NF01 · P2 · Chyba staršího gym zápisu opustí novější snapshot, který už volajícímu oznámil úspěch

Místo: `ios-native/Loadwise/App/AppModel.swift:1066`.

Příčina: Při souběžném saveGym druhá změna pouze nastaví gymPending a vrátí se jako úspěšná. Pokud právě probíhající deliver vyhodí OutboxRefusal.retry (např. HTTP503/429), smyčka skončí před next = gymPending. Pending zůstane jen v paměti a nikdo ho neodešle. deliver zachytává pouze síťové URLError, nikoli serverové retry.

Scénář a dopad: Uživatel přidá cvik a během pomalého POST dokončí sérii. Druhé uložení se tváří úspěšně, první později selže. Novější dokončená série není na serveru ani v outboxu. Při online znovuotevření gymDay načte starší serverový stav a přepíše i diskovou cache novějšího snapshotu.

Oprava: Uchovávat nejnovější snapshot trvale před potvrzením volajícímu a při jakémkoli selhání fronty jej zachovat k opakování. U callers čekajících na uložení dokončit až po skutečném zápisu či durable enqueue; rozlišit retry od trvalého odmítnutí.

Hotovo až když: Zadržet POST A, spustit save B s dokončenou sérií, A vrátit503 i429. B musí být uložen nebo trvale čekat a přežít ukončení aplikace; online GET nesmí přepsat neodeslané B.

Důkaz: Staticky doložený dosažitelný interleaving; AppModel1061–1076, deliver773–787, APIClient.sendQueued642–660, GymLive.persist510–519 a TrainingMode.complete1262–1315. Swift runtime nebyl dostupný.

Vztah k původní revizi: Stejný saveGym early-return/throw tok existoval již v 02d575e; jde o nově nalezenou dosavadní chybu, nikoli regresi opravy A06.

### NF02 · P2 · Pozdní AI návrh původních filtrů přepíše nový výběr knihovny

Místo: `ios-native/Loadwise/Screens/TrainingLibrary.swift:335`.

Příčina: Tlačítko Jiný návrh na ř.317 spouští neuložený unstructured Task. Změna filtrů zruší jen .task(id:) na ř.274, nikoli tuto úlohu. compose po await kontroluje pouze Task.isCancelled, nikoli shodu zachycených filtrů nebo generace, a bezpodmínečně přepisuje composed/composeVariant/composeMore.

Scénář a dopad: Pro filtry A uživatel požádá o jiný návrh, pak přepne délku/typ/prostředí na B. Načtení a AI návrh B doběhnou. Pozdější odpověď A zůstává nezrušená a nahradí B; obrazovka nadále ukazuje filtry B, ale karta i následné naplánování pracují s tréninkem A.

Oprava: Používat jeden řízený compose task zrušený při každé změně klíče filtrů. Před každou změnou stavu po await ověřit zachycený úplný klíč filtrů a generaci požadavku; stejná kontrola musí chránit i catch/defer/loading.

Hotovo až když: Zadržet variant1 filtrů A, změnit filtry na B a dokončit search+compose B, teprve potom pustit A. Zobrazený a plánovaný workout musí stále patřit B. Zopakovat s chybou A a s B bez podpory compose.

Důkaz: Statický průchod .task274, tlačítko317, compose331–350 a load446–466; APIClient+Training.composeWorkout parametrizuje request aktuálními filtry. Neproveden SwiftUI/URLSession runtime test.

Vztah k původní revizi: compose UI a neřízený Task jsou nové oproti původnímu auditu.

## Rozsah a limity

- `ios-native/Loadwise/Screens/TrainingModeView.swift`: detail
- `ios-native/Loadwise/Screens/GymLive.swift`: detail
- `ios-native/Loadwise/Screens/CoachView.swift`: detail
- `ios-native/Loadwise/Screens/JournalViews.swift`: detail
- `ios-native/Loadwise/Screens/AddFoodSheet.swift`: detail
- `ios-native/Loadwise/Screens/TrainingLibrary.swift`: detail
- `ios-native/Loadwise/Screens/CoachPick.swift`: flow
- `ios-native/Loadwise/Screens/CoachTextCard.swift`: flow
- `ios-native/Loadwise/Screens/CycleViews.swift`: flow
- `ios-native/Loadwise/Screens/PanelWidgets.swift`: flow
- `ios-native/Loadwise/Screens/HealthView.swift`: flow
- `ios-native/Loadwise/Screens/FoodEntryEditSheet.swift`: flow
- `ios-native/Loadwise/Screens/MealDetailView.swift`: flow
- `ios-native/Loadwise/Screens/BarcodeScanSheet.swift`: flow
- `ios-native/Loadwise/Data/APIClient.swift`: flow
- `ios-native/Loadwise/Data/APIClient+Training.swift`: flow
- `ios-native/Loadwise/Data/GymModels.swift`: flow
- `ios-native/Loadwise/Data/WorkoutModels.swift`: flow
- `ios-native/Loadwise/Data/FoodModels.swift`: flow
- `ios-native/Loadwise/App/AppModel.swift`: flow
- `ios-native/Loadwise/App/Outbox.swift`: flow

- Nebylo spuštěno SwiftUI, Xcode, iOS simulátor, HealthKit, kamera ani fyzický telefon.
- Stavy fixed znamenají opravený původní zdrojový tok; nikoli potvrzený produkční runtime.
- Nové NF01 a NF02 jsou staticky doložené souběhové cesty; žádný ručně přepsaný model není vydáván za běh původního Swift kódu.
- Neprovedeno systematické procházení všech obrazovek a přístupnosti; zde jde o zadanou oblast iOS a nové změny.

Aplikační zdroje jsem neměnil.
