# Nezávislá kontrola nových nálezů — cyklus a nativní souběh

Kontrolovaný commit: `74a459d0f99fa6503e4e37035777915921427a06`. Bez změn aplikačních zdrojů.

**Výsledek: oba nové cyklické nálezy jsou potvrzené. NF01 a NF02 jsou dosažitelné statické nativní toky; nenašel jsem ochranu, která by je vyvracela.** Níže jsou upřesnění, nikoli další samostatné nálezy.

## Rozsah vstupů kalendáře a současného stavu cyklu — potvrzeno runtime

- `src/routes-cycle.js:19` používá dolní mez `today-200` bez ohledu na zvolený měsíc a horní mez `month-01+45`. Stejná množina se použije současně pro historický kalendář a aktuální `state` na ř.21.
- Pro leden při dnešku20.10.2026 vychází dolní mez po horní. Uložený lednový záznam proto nebyl načten, přestože se kalendář za leden vykreslí; výchozí flow0 a prázdné symptomy vypadají jako skutečný stav.
- Při zářijovém kalendáři končí horní mez16.10., tedy před dneškem20.10. Dnešní záznam pilulky chybí ve `state`, přestože state.date zůstává dnešek.
- Nativní cesta je přirozená: `CycleCalendarView` dovoluje opakovaně jít do minulosti (CycleViews.swift:481,583–586), `.task(id:month)` načítá tento měsíc (521). `PillCard` pod kalendářem čte právě `model.cycle.state` (508–509). Výběr starého dne předá jeho zobrazené flow/symptoms do formuláře (522–523), který tato pole obě odesílá při ukládání (446,454).
- Nezávislý skript volá původní `handleCycleApi` a původní `tenancy.scopedDb` nad skutečným SQLite. Potvrdil Oct20 pill21:04→null po GET září i Jan10 flow3→zobrazené0→uložené0 po změně symptomů.

Oprava musí oddělit rozsah nutný pro aktuální model od rozsahu zobrazeného kalendáře, nebo použít sjednocení obou. Nesmí jen zvýšit konstantu200, protože horní mez pro minulý měsíc nadále vynechá dnešek.

## Ztracené souběžné patch operace cyklu včetně shareWithCoach — potvrzeno runtime

- `saveCycleSettings` čte celý JSON (`cycle-store.js:34`), složí další JSON (35–38) a celý jej přepíše (39).
- `saveCycleDay` podobně načte starý řádek (67), chybějící klíče doplní z tohoto snapshotu a v jednom UPSERTu přepíše všechna ručně zadaná pole (69–76). Jednotlivý UPSERT je atomický; celek SELECT→výpočet→UPSERT není.
- `scopedDb` zajišťuje rozsah identity a cache CREATE příkazů, nikoli serializaci požadavků (`tenancy.js:144–163`). `routedUserDb` předává prepare přímo databázi a zachovává transakci pouze pro explicitní batch (`user-data-routing.js:47–65`). Tyto funkce batch nepoužívají a žádný per-user zámek je neobaluje.
- Nezávislé běžné `Promise.all` dvou **původních HTTP handlerů**, bez umělých latchů, ztratilo změnu flow3 při souběžném patchi symptomů. Stejně tak oba settings POSTy uspěly200, ale `shareWithCoach:false` a nezávislé `pillReminderTime:22:00` skončily finálním `shareWithCoach:true`.
- Přirozený scénář jsou dva přihlášené telefony stejného účtu. V jednom klientu navíc `AppModel+Cycle` nemá frontu/lock a metody se mohou znovu zavolat přes await; některé picker/reminder akce spouštějí nezávislé Task. **Nepopisovat to jako dvě rychlá kliknutí na libovolné přepínače jedné stránky:** hlavní CycleSettingsView při saving některé ovládání zakazuje. Tato lokální ochrana neřeší souběh zařízení ani serverové API.

Oprava potřebuje atomické patchování konkrétních dodaných polí, případně revizi/CAS s bezpečným opakováním. Pouhá klientská serializace na jednom telefonu není dostatečná pro zachování volby shareWithCoach mezi zařízeními.

## NF01 — gym pending snapshot po chybě předchozího zápisu — potvrzeno staticky

- saveGym zapisuje cache před guardem (AppModel.swift:1063), při již probíhajícím zápisu pouze uloží gymPending a vrátí úspěch (1066).
- Předchozí HTTP503 či429 je `OutboxRefusal.retry` (APIClient.swift:659–660), `deliver` zachytává pouze URLError odpovídající isNoConnection (AppModel.swift:783; Outbox.swift:90–93). Výjimka proto opustí smyčku před načtením pending (1074–1075).
- Další snapshot se nedostane do outboxu ani na server; UI dokončení série obdrží úspěšný návrat a vymaže chybu (TrainingModeView.swift:1312–1313). Přirozené překrytí podporuje i `GymLive.persist`, který při editacích spouští nečekaný Task (510–519).
- **Upřesnění formulace:** obsah B už je v diskové `GymDayCache`, takže netvrdit, že vůbec není uložen na disk. Chybí mu však trvalý stav čekajícího odeslání a ochrana před online reloadem: gymDay používá čekající outbox, jinak preferuje server a přepíše cache (AppModel.swift:1084–1089). Proto je scénář následné ztráty platný.

Původní Swift runtime nebyl k dispozici; peer kontrola rovněž nepředstírá spuštění iOS kódu.

## NF02 — starší AI compose přepíše novější filtry — potvrzeno staticky

- Jiný návrh vytvoří neuchovaný `Task` (TrainingLibrary.swift:317). Nejde o task řízený `.task(id:)` na274.
- Po await compose kontroluje jen svůj cancellation stav, pak zapisuje composed/variant/more (335–341). Při změně minut, tolerance, systému, prostředí či obtížnosti se původní tlačítkový Task nikde nezruší a nemá kontrolu shody filtrů.
- Aktuální load B smaže composed, získá nové composeWanted a spustí compose B (446–466). Pozdější úspěch starého tlačítkového compose A může zapsat workout A do stejného @State pod filtry B; catch/defer může též změnit stav novějšího požadavku.
- API dotaz zachytí filtry při volání `composeWorkout` a zahrne je do URL (APIClient+Training.swift:144–158); serverová odpověď tedy skutečně odpovídá původnímu výběru A.
- Pro přesnou regresi měnit filtry v rámci **téže obrazovky téhož sportu**. Změna sportu může vytvořit jinou navigační identitu, a není pro důkaz potřebná.

## Nezávislé ověření

Příkaz: `node --experimental-vm-modules /workspace/aurin-reaudit-2026-10-20/auth-peer-cycle-routes.mjs` — exit0. Výstup: `auth-peer-cycle-routes.json`.

Skript používá původní veřejné modules/API/scoped DB a skutečné SQLite, pouze jazykovou závislost a aktuální datum izoluje. Žádné soukromé prompty, aplikační zdroje, produkční data ani externí služby nebyly měněny nebo volány.
