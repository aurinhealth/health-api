# Doplnění revize — změny z 21. října 2026

**Commit:** `775c79b1432d743a1d503f803214dda348f555ed`. **Předchozí kontrola:** `74a459d0f99fa6503e4e37035777915921427a06`.

Od rozpracované revize přibylo 8 commitů a změnilo se 14 souborů. Kontrola jejich finálního rozdílu **nezměnila verdikty 24 opravených a 9 částečně opravených původních bodů ani nezneplatnila 13 nově nalezených vad**. V tomto posledním rozdílu nebyla doložena další samostatná chyba.

## Co bylo prověřeno

- GitHub OIDC přešel z `shaarkyn/health-api` na `aurinhealth/health-api`; neměnné repository_id a owner_id zůstaly zachované. Kontroly audience, workflow, main ref, actor a podpisu nebyly odstraněny.
- Nový parametr SERVER ve workflow Vydat se překládá na commit, kontroluje se jeho příslušnost k historii main i to, že obsahuje vybraný app build. Ref se předává do deploye a release poznámek. Hodnota je v shellu předaná přes proměnnou a uvozovky, není vložená do shellového kódu.
- Předčasná veřejná větev Workeru nově obsluhuje HEAD stejně jako GET, bez databáze/session; HEAD vrací stejné hlavičky a prázdné tělo.
- Web přidal metadata pro náhledy a JSON-LD. Origin je stále omezený na známé hosty, JSON-LD escapuje znak menší než před vložením do scriptu. Texty už neslibují trvale bezplatnou aplikaci; bezplatnost je vymezená testováním.
- Změny week_sport mění název/detail a potvrzovací zprávu, nikoli ukládací tok. Překlady nových názvů a existující „jen tento týden“ jsou dostupné. StrainHero nyní otevírá existující route detailu námahy.
- Změna display:none pro skryté navigační CTA odstranila dřívější prázdné místo; prohlížečové ověření celé aktuální stránky provádí hlavní revize.

## Skutečně spuštěné kontroly

| Kontrola | Výsledek |
|---|---|
| `node tests/github-oidc.test.mjs` | 4 testy prošly: skutečné RSA podpisy, rotace lokálního JWKS, odmítnutí jiné identity/workflow/audience. |
| `node delta-public-pages.mjs` | Původní časná větev a staticRoute: 6 cest × GET/HEAD, status 200, prázdné HEAD a shodný content-type. Metadata JSON-LD a Twitter ověřena. |
| Shell workflow Vydat | 5 run bloků prošlo `bash -n`; jde o syntaxi, nikoli spuštění releasu. |
| `git diff --check 74a459d..775c79b` | Prošlo. |
| Aktuální `node tests/site-pages.test.mjs` | Blokuje chybějící `src/private/lang.js`. Soubor nově importuje celý entrypoint kvůli HEAD regresi. |

**Podstatná změna ověřitelnosti:** dřívějších 15 veřejných testů site-pages šlo 20. října spustit samostatně. V dnešní podobě kvůli novému importu Workeru nespustí ani tento soubor bez soukromých závislostí. Dřívější úspěch se nesmí vykazovat jako dnešní průchod standardní sady.

GET/HEAD kontrola používá přesnou původní větev a funkci staticRoute, ale ostatní Worker bootstrap neimportuje; email/open-signup konfigurace je lokálně false. Nejde o důkaz živého nasazení, skutečného crawleru nebo aktuálních provozních schválení. Nebyl spuštěn iOS ani release do TestFlightu. Ručně zvolený historický server potřebuje také kompatibilitu s aktuálním prostředím; kontrola původu commitu nenahrazuje integrační test.

## Podklady

- `delta-21-10.json`: přesný seznam 14 souborů a hloubka kontroly.
- `delta-github-oidc-tests.log`: standardní test OIDC.
- `delta-public-pages.mjs` a `delta-public-pages.json`: lokální GET/HEAD a metadata.
- `delta-release-shell.json`: výsledky shellové syntaktické kontroly.
- `delta-site-pages-standard.log`: skutečný blokátor aktuálního standardního testu.

Aplikační zdroje nebyly změněny.
