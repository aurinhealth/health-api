import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {join,extname} from 'node:path';
import {chromium} from '/opt/codex/runtimes/cua/lib/node_modules/playwright/index.mjs';
import {overviewPage,privacyPage,termsPage,supportPage} from '/workspace/health-api-recheck/src/site-pages.js';

const out='/workspace/aurin-reaudit-2026-10-20';
const root='/workspace/health-api-recheck';
const types={'.webp':'image/webp','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2'};
const pages={'/':overviewPage,'/privacy':privacyPage,'/terms':termsPage,'/support':supportPage};
const server=createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,'https://aurin.health');
    if(pages[u.pathname]){
      const response=pages[u.pathname](new Request(u));
      res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());return;
    }
    if(u.pathname==='/waitlist'&&req.method==='POST'){
      for await(const _ of req){} // UI-only local fixture; never contacts the real service.
      res.writeHead(200,{'content-type':'application/json'});res.end('{"status":"ok"}');return;
    }
    if(u.pathname.startsWith('/site/')||u.pathname==='/logo.svg'){
      const path=join(root,'public',u.pathname);
      const data=await readFile(path);res.writeHead(200,{'content-type':types[extname(path)]||'application/octet-stream'});res.end(data);return;
    }
    res.writeHead(404);res.end();
  }catch{res.writeHead(404);res.end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
const results=[];
try{
  for(const width of [320,390,1280]){
    const context=await browser.newContext({viewport:{width,height:900},reducedMotion:'reduce'});
    await context.route('**/*',async route=>{
      if(route.request().url().startsWith(origin))await route.continue();else await route.abort();
    });
    const page=await context.newPage(),errors=[],failed=[];
    page.on('pageerror',error=>errors.push(error.message));
    page.on('response',r=>{if(r.status()>=400)failed.push({status:r.status(),url:r.url()});});
    for(const path of ['/','/privacy','/terms?lang=cs','/support']){
      await page.goto(origin+path,{waitUntil:'networkidle'});
      const layout=await page.evaluate(()=>({viewport:innerWidth,scroll:document.documentElement.scrollWidth,body:document.body.scrollWidth,title:document.title}));
      let waitlist=null;
      if(path==='/'){
        const form=page.locator('.hero form.wl');
        await form.locator('.open').click();
        await form.locator('input').fill('audit@example.invalid');
        await form.locator('button[type=submit]').click();
        await form.locator('.done').waitFor({state:'visible'});
        waitlist={localFixture:true,successVisible:await form.locator('.done').isVisible()};
        await page.screenshot({path:out+'/website-'+width+'.png',fullPage:false,animations:'disabled'});
      }
      results.push({width,path,layout,waitlist,errors:[...errors],failed:[...failed]});
    }
    await context.close();
  }
  await writeFile(out+'/website-check.json',JSON.stringify({implementation:'Original page functions/assets; Chromium; local in-memory waitlist response; outbound requests blocked',results},null,2));
  console.log(JSON.stringify(results));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
