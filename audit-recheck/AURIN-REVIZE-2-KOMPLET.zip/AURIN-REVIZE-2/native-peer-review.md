# Nezávislá kontrola nativních nálezů identity

Revidovaný commit: `74a459d0f99fa6503e4e37035777915921427a06`.

Kontrola konfrontovala nálezy `native-identity.json/md` s implementací a konkrétními cestami vzniku. Nevytváří další ID za stejné chyby. Swift/Xcode není dostupný; souběhové nativní scénáře níže jsou staticky dosažitelné cesty, nikoli spuštěný iOS test.

## A02 — potvrzuji částečnou opravu, P1

**Důkaz dosažitelnosti:** `AppModel.sendOutbox` kontroluje phase a accountUnconfirmed jen při vstupu (834). Samostatná smyčka `sendWaiting` (862–893) po každém await pokračuje k dalšímu prvku bez opětovného ověření těchto stavů či generace. Ochrana `Outbox.isOthers` srovnává položku s ID ze sdílených UserDefaults, nikoli s účtem aktuální cookie. Při `clearLocal(expired:true)` zůstane fronta i identita A; `signedIn` nastaví accountUnchecked a čeká na `/me` (374–375), ale starou smyčku tím nezastaví. APIClient používá sdílené cookie storage (54–61) a pro další položku vytváří nový request (642–647).

**Potřebné pořadí:** A1 už byl serverem pod A přijat a jeho úspěšná odpověď je zpožděná. Jiný požadavek už přišel po expiraci a vyvolal odhlášení. B dokončí autentizaci; B `/me` se zadrží. Zpožděná A1 pak doběhne a smyčka odešle A2. A2 owner=A se stále shoduje s uloženým A, přesto cookie již patří B. Nejde o obcházení backendového filtrování; klient posílá staré údaje pod novou platnou session.

**Zkontrolované obrany:** vstupní guard i owner guard opravují běžný nový běh, ale nepokrývají popsanou běžící smyčku. Přepnutí serveru frontu explicitně maže; samo o sobě proto není vydáváno za prokázaný druhý scénář. Doporučuji zachovat status partial a P1, bez tvrzení, že původní oprava vůbec neexistuje.

## A10 — potvrzuji částečnou opravu, P1

`forgetAccountData` nyní skutečně vymaže cyklus a pill nastavení (AppModel415–419) a běžný logout ho volá (1447). `AppModel+Cycle.loadCycle` však kontroluje phase jen před požadavkem a po await odpověď bez podmínky zapíše do `cycle` a `Reminders.storePill` (7–14). Volající `refresh(announce:true)` vytváří unstructured Task na AppModel456, jehož handle clearLocal neruší. Tento Task může běžet přes odstranění původní SwiftUI obrazovky a čekat na child loadCycle (494–498).

A tedy může mít požadavek již přijatý pod A, poté proběhne běžný logout a B login a až následně dorazí odpověď A. Vyčištění proběhlo, ale pozdní odpověď ho znovu naplní. Nelze se opřít o automatickou cancellation view tasku: zde existuje konkrétní nezrušený samostatný Task. Nastavení pill se znovu uloží; automatický vznik nové notifikace závisí na dalším reschedule, proto report nemá tvrdit, že každé takové dokončení samo bez dalšího kroku okamžitě naplánuje alarm.

## A11 — potvrzuji částečnou opravu, P2

Běžný logout a potvrzená změna účtu export nově resetují. Expired logout ho úmyslně ponechá. Při selhání prvního `/me` má `signedIn` account=nil, přesto zveřejní phase.signedIn (377) a potom čeká na další načtení identity (378, loadAccountInitial289–294). RootView se může mezitím zobrazit a samostatně načítat účet (227); pokud jsou tato `/me` zpožděná či nedostupná, nezaručují reset před otevřením Jídla. `refreshFood` vyžaduje pouze signedIn (703) a na713 spustí saveFoodDay. Export215–217 kontroluje lokální globální prefs a systémové oprávnění, nikoli potvrzeného vlastníka nebo B serverové preference.

Nutné předpoklady jsou v nálezu správně: A dříve povolil export a iOS zápis; A skončil expirací; B má platnou session a přístup k food endpointu; jeho `/me` selže/zůstane pomalé, zatímco food uspěje. To může nastat při izolovaném selhání endpointu a nevyžaduje současně nefunkční celou síť. Po úspěšném `/me` jiného účtu by checkAccount reset provedl, takže běžnou úspěšnou přihlašovací cestu nelze označit za stále rozbitou.

## N-NATIVE-CYCLE — potvrzuji samostatný nález, P1

`CycleHealth` není chráněn novou `AppleHealth.generation`. AppModel+Cycle12–14/23–25 ho spouští samostatně. `CycleHealth.sync` čeká na více HealthKit queries (`flowDays`47,72–103) a pak na54 volá import bez kontroly vlastníka/serveru/generace. Pokud B autentizace skončí před tímto novým POST, APIClient.makeRequest používá aktuální base URL a shared cookie B. Origin se generuje správně pro aktuální server (APIClient729–741), tedy tato obrana smíchání nezastaví.

Přijímač `routes-cycle.js:45–47` nekontroluje zapnutí cyklu. Nezávisle jsem znovu spustil existující `repro-native-cycle-receiver.mjs`: původní current route/store s reálným SQLite a syntetickým přihlášeným B vrátil HTTP200/saved1, uložil apple_flow3 pod user_id22 a settings.enabled zůstalo false. Toto potvrzuje příjem dat s cyklem OFF; nesimuluje původní HealthKit ani nedokazuje fyzické iOS načasování. Od A01 jde o oddělený importér a od A10 o upload místo pozdního zobrazení staré odpovědi, takže samostatné ID je obhajitelné.

## N-NATIVE-MUSCLES — potvrzuji běžnou cestu, P2

`muscleFatigue` (AppModel58) není resetován ani v kompletním clearLocal1434–1479, ani forgetAccountData415–419. Po běžném logoutu B tedy zdědí nenil model. `model.muscles` ho pro nedemo režim vrací bez kontroly identity (MuscleViews12); widget122 i builder GymTools284 nové načtení přeskočí, protože kontrolují nil. Builder navíc na286–288 z A modelu skutečně nastaví výchozí focus. Nevyžaduje se zpoždění sítě ani chybný server. Nález není jen domněnka odvozená z chybějícího resetu: existují přímí konzumenti staré hodnoty.

## MinimizedGym / LiveWorkout — skutečná návaznost stejné chyby resetu, doporučuji sloučit

Normální cesta A zahájí trénink → minimalizuje šipkou → odhlásí se → přihlásí B ponechá `model.minimizedGym` i `LiveWorkout.shared`: clearLocal je nečistí ani nezastavuje. RootView157–158 pak v B bez dalšího načítání vykreslí starý MinimizedGymBar; ten zobrazuje A title, další cvik a čas (TrainingModeParts459–491). Jde o konkrétní další per-account stav, který zůstává po běžném logoutu.

**Důležitá korekce možného přehánění:** kliknutí na bar samo nekopíruje A kompletní GymDay do B. TrainingMode.load910 nejdřív načte B den a restoreMinimized1042–1051 obnoví jen index, startTapped, odpočinek a pending lock-screen akce. `gym.day` se do `day` nepřiřazuje. Přímý přepis celého A plánu do B tedy tímto kódem není doložen a nemá být uveden jako potvrzený dopad.

Otevřený B trénink nicméně sdílí stále běžící LiveWorkout A (started: live.running || startTapped, continueWorkout83–84 nepřepíše existující start). Při Dokončit může finish1126–1152 použít jeho starý čas/naměřený průběh; pending lock-screen complete se aplikuje na B řádek, pokud má odpovídající index. Tyto širší dopady vyžadují nativní regresi, ale zobrazení A názvu/cviku a neoddělený aktivní záznam jsou přímo doložené.

Doporučuji tuto věc uvést jako další konkrétní příklad nálezu neúplného resetu per-account stavu (společně s muscles), bez automatického přidávání dalšího počtu kvůli každému zapomenutému poli. Oprava musí vedle vymazání DTO řešit ukončení/oddělení aktivního workoutu, handlerů Live Activity a čekajících akcí.

## Výsledek peer review

Tři původní částečné stavy a dva nové nálezy mají konkrétní dosažitelné cesty a odpovídající omezení. Prioritám P1/P1/P2 a P1/P2 neodporuji. Report musí zachovat rozdíl mezi opravenou běžnou cestou, zbytkovým souběhem a lokálním backendovým důkazem. Žádný z nativních race scénářů nebyl spuštěn na iOS.
