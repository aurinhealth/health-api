# Aurin — druhá revize a ověření oprav

**Dokončeno:** 21. října 2026. **Revidovaný commit:** `775c79b1432d743a1d503f803214dda348f555ed`. **Původní audit:** `02d575e570a179a5c156bcc9708877a2c18f3de8`.

**Výsledek původních 33 bodů: 24 opravených, 9 částečně opravených.** K tomu **13 nových nálezů** (1× P1, 12× P2). Celkem zbývá 22 úkolů: 3× P1 a 19× P2.

Všechny původní body mají cílenou změnu nebo odstraněný původní scénář. U devíti oprav ale zůstává konkrétní nedořešená větev. Nový nález znamená nově odhalenou chybu: část z nich existovala už před první revizí. Nejde o tvrzení, že všechny vznikly během oprav.

**Před dalším širším vydáním:** uzavřít A02, A10 a N01. Stále dovolují přenos či zobrazení citlivého stavu mezi účty na stejném telefonu. Následně řešit ztracené zápisy A03/N03 a souběžné změny cyklu N13. Pro tyto případy nestačí reset při odhlášení; je potřeba kontrolovat vlastníka i po asynchronních operacích.

## Rozsah a význam výsledků

Kontrola navazuje na první inventář aplikace a znovu ověřuje všech 33 nálezů, jejich opravy, související toky a změny mezi oběma commity. Rozdíl obsahuje 165 změněných cest. První část druhé revize vznikla nad `74a459d`; po přerušení bylo zkontrolováno i dalších 8 commitů do `775c79b` a hlavní lokální reprodukce byly zopakovány nad touto novější verzí.

Stav **Opraveno** znamená odstranění původního doloženého scénáře v dostupné implementaci. U nativních oprav jde o statickou kontrolu Swiftu a volajících, nikoli test na iPhonu. Stav **Částečně** znamená funkční opravu běžného průchodu se zde popsanou zbývající chybou. Žádný bod není prezentován jako potvrzený produkční incident.

P1 = citlivá data či oddělení účtů, opravit před širším vydáním. P2 = konkrétní datová nebo funkční chyba. Priorita není odhad pravděpodobnosti. Izolované reprodukce používají původní veřejné funkce a skutečné lokální SQLite, ale nahrazují okolní služby; neověřují živé D1, HealthKit, APNs, Apple ani Google.

Přesná hloubka zdrojové kontroly je v POKRYTI.csv. Řádek inventory znamená inventarizaci, nikoli kontrolu každé větve; binární screenshoty nejsou vydávány za automatickou validaci celé nativní aplikace. Zdrojové odkazy v tomto dokumentu míří na přesný novější commit. Dílčí podklady zachovávají původní kontext `74a459d` a mají samostatný doplněk delta-21-10.

## Stav všech původních bodů

| ID | Stav | Původní problém | Výsledek |
|---|---|---|---|
| A01 | Opraveno | HealthKit po expiraci přihlášení pokračuje do dalšího účtu | Původní AppleHealth.perform nyní před každým uploadem kontroluje generaci, enabled a accountUnconfirmed (338). signedIn nejprve získá /me (AppModel375–377); při neznámé identitě zůstává accountUnchecked… |
| A02 | Částečně | Nový účet může odeslat čekající zápisy předchozího účtu | Zadržet úspěšnou odpověď A1. Souběžný jiný požadavek dostane401, clearLocal(expired:true) zachová A2 i identitu A. Přihlášení B nastaví cookie B a accountUnchecked=true, /me B je zadržené. Uvolněná A1 nechá starou… |
| A03 | Částečně | Server potvrzuje zápis ještě před jeho skutečným dokončením | Při stále probíhajícím prvním zápisu může pět opakovaných refreshů/odeslání během dvouminutového pending okna vyčerpat limit. Pokud původní požadavek následně selže, už není co odeslat. Samotné iOS pořadí nebylo… |
| A04 | Opraveno | OAuth callback nepřipíná propojení k původnímu účtu | oauthStateValue v connect-return.js:13 přidává USER_ID do state cookie a startedBy:18 ho porovnává s aktuálním účtem. Kontrola proběhne před výměnou kódu a uložením credentials. Stejná kontrola je v Intervals:44,… |
| A05 | Částečně | Použitý Google ticket obnoví odvolané přihlášení | Runtime reprodukce pozastavila skutečnou claim batch po kontrole epochy0, zvýšila users.session_epoch na1 a dokončila claim. Odpověď byla200 a skutečně podepsaná cookie nesla epochu1; sessionMatchesUser ji vůči… |
| A06 | Opraveno | Starší úprava cviku přepíše později dokončenou sérii | saveEdited ukládá edited přes model.saveGym na ř.986 před prvním loadMuscles na ř.991; add totéž na ř.1009 před metadata na ř.1014. AppModel.saveGym ř.1061–1076 řadí přijaté snapshoty stejného dne. Původní zadržení… |
| A07 | Opraveno | Běžecký limit přidává běhy i při vyčerpaném rozpočtu | capRunVolume nyní vyřazuje běhy pod minimem 20 min a po zaokrouhlení nepřekročí zbývající prostor. Původní 4 běžecké dny dávají celkem 60 min místo 80. Po již hotových 60 min nevznikne další běh. Prošlo 308 kombinací… |
| A08 | Částečně | Dnešní plánovaný běh se neodečte z týdenního rozpočtu | Dva různé dnešní běhy jsou považovány za jeden: skutečně obsazeno 60, započteno 30, nový návrh 30, celkem 90 při limitu 60. Stejný helper používá entrypoint.js:741. |
| A09 | Opraveno | Push kouče se neplánuje pro účty bez Google nebo Intervals | Samostatný coach-push job má push:true a nevyžaduje providera; fan-out sjednocuje usersWithProviders a usersWithPushTokens, runUserJobs přijímá push job i s prázdným CONNECTED_PROVIDERS. Push tokeny zůstávají v… |
| A10 | Částečně | Cyklus předchozího účtu zůstává viditelný po odhlášení | A spustí obnovení Dnes; refresh(announce:true) vytváří samostatný Task (AppModel456), který může čekat na loadCycle (494–498). A se odhlásí a B přihlásí. clearLocal běžící announcedRefresh neruší a loadCycle pozdní… |
| A11 | Částečně | Apple Health export přenáší preference mezi účty | A má povolený export výživy/vody, jeho session vyprší. B se přihlásí; první /me selže a druhé je pomalé. B otevře Jídlo a jeho /food-today uspěje dřív než ověření identity. Export použije A preference, i když B má… |
| A12 | Opraveno | Vypnutí všech kategorií Apple Health nezastaví čtení | Původní prázdný onChange guard je nahrazen health.disconnect (120–122). disconnect nastaví enabled=false, uloží ho, odstraní resume key, zastaví observers a zvýší generation (AppleHealth204–209); pending collect je… |
| A13 | Opraveno | Chyba potvrzení návrhu odstraní možnost opakování | Bubble má oddělené failed a decided; catch decide ukládá do failed na ř.316. Jen úspěch plní decided na ř.311. ActionCard ř.471–495 nadále zobrazuje tlačítka, pokud result chybí, a chybovou zprávu zvlášť. Opakování… |
| A14 | Opraveno | Přepnutí dne dovoluje zapisovat podle starých odpovědí | Sekce odpovědí se při day.date != date nevykreslují (ř.345–355). load ř.491–500 zachytí asked a odmítá odpověď i chybu jiného dne. Výsledek fixed/save se aplikuje jen při saved.date == date (ř.539,564). |
| A15 | Opraveno | Selhání načtení gymu může automaticky přepsat uložený trénink | LiveGym.load při gymDay chybě nastaví error a vrátí se před ensureHeader/markStarted/day/persist (ř.337–343). AppModel.gymDay ř.1088 odmítá status partial; DTO GymDay status nyní dekóduje. Chybové UI ř.57–70 nabízí… |
| A16 | Opraveno | Wahoo synchronizace vrací ručně opravený typ a kalorie | Wahoo upsert používá KEEP_TYPE_SQL. Změna typu zapisuje loadwiseType a SQL zachová top-level type i loadwiseKcal/loadwiseKcalDevice. Reálná lokální posloupnost import Run/600 → edit Walk/250 → stejný Wahoo import… |
| A17 | Opraveno | Desetinné intenzity se v mezerách zón označí jako sprint | zoneOf nyní vybírá poslední zónu podle její dolní hranice, takže nejsou mezery mezi celými procenty. Původní reálný převod vlastního workoutu dává při 75,5 % na kole endurance a při 77,5 % běhu recovery, nikoli sprint. |
| A18 | Částečně | Upravená vlastní šablona mění detail starších plánů | Oprava chrání nová plánování, nikoli všechny existující plány vzniklé před upgradem. Jejich název/sport/detail a odkazy pro následné operace závisejí na měnitelné šabloně. Staré již přepsané struktury nelze bez… |
| A19 | Opraveno | Wahoo aktivita chybí ve svalové únavě a regeneraci | SQL výběr nyní zahrnuje source_family=wahoo pro activity. Původní syntetická 3h aktivita s TSS 180 se načte: 1 Wahoo aktivita, TSS 180. Zachován filtr record_role!=duplicate a společné zpracování storedActivities. |
| A20 | Opraveno | Dnes a Zdraví počítají jiný spánkový dluh | Health i Today nyní volají stejnou weekSleepDebt nad všemi sessions. Původní scénář noc 420 min + zdřímnutí 60 min při potřebě 480 vrací na obou obrazovkách dluh 0. |
| A21 | Opraveno | Vážení se při UTC půlnoci přiřadí špatnému dni | Health i Today používají localDate místo UTC slice. V America/New_York se vzorek 2026-10-20T01:00:00Z správně zobrazí v 2026-10-19 s hodnotou 80 na obou obrazovkách. |
| A22 | Částečně | Rozpracovaná Google operace je označená jako odeslaná aktivita | Po úvodním odeslání a dvou cron kontrolách zůstává status=pending, remote_id=operations/slow a attempts=3. I když se operace poté dokončí, další cron už neudělá žádný GET. Totéž vyvolají dočasně nedostupné odpovědi… |
| A23 | Částečně | Smazaná aktivita Intervals zůstává v aplikaci | Původní scénář poslední smazané aktivity při úplném, ale prázdném refreshi stále selhává. Podmínka activities.length zcela přeskočí reconciliation. Týká se zejména spojení osobním API klíčem bez OAuth webhooků nebo… |
| A24 | Opraveno | Prázdné HealthKit čtení smaže importované jídlo a pití | Prázdné pole jídel/pití ze zdroje apple-health se už nepovažuje za důkaz smazání. Lokálně importováno jedno jídlo a jeden nápoj, následné meals:[]/drinks:[] vrátilo saved:0,removed:0,changed:0 a oba záznamy zůstaly. |
| A25 | Opraveno | Jeden účet vyčerpá společný rozpočet přihlašovacích e-mailů | Před dotazem na cílovou adresu se kontroluje per-user limit2/min,5/h,10/den a per-client5/min,20/h,30/den. claimAndSend dostává change:true a používá vlastní email-codes:change:day, nikoli email-codes:day. Ve100… |
| A26 | Opraveno | Dvě registrace získají poslední volné místo | createAccount dává ACCOUNT_LIMIT i OPEN_PLACES > UNPLACED_USERS do podmínky téhož INSERT...SELECT. E-mail, Google i Apple sign-in jej volají před vrácením nového účtu. Pro každý ze tří způsobů tři souběžná přihlášení… |
| A27 | Opraveno | Google export nahradí zadaný čas jídla polednem UTC | Lokální consumed_at bez offsetu nyní používá zonedTime v kontextu uživatele. Původní veřejná funkce vrátila z 07:30 v Praze 05:30Z, v New Yorku 11:30Z; po konci letního času v Praze 06:30Z. Čas se již nemění na 12:00Z. |
| A28 | Opraveno | Hromadná změna jídel selže po částečném uložení | Původní kopírování ids:[1,999] už nevrací chybu po úspěšném zapsání prvního jídla. Funkce vrátí status:ok, done:[nové id], skipped:[999]; route připravuje export pro úspěšné položky. Reprodukce vytvořila právě jednu… |
| A29 | Opraveno | Workflow mikroživin selže před sestavením katalogu | Před Run tests je nově checkout shaarkyn/aurin-prompts do src/private s PROMPTS_REPO_TOKEN (ř.50–55); testovací příkaz na ř.63 zůstává zachován. Původní chybějící krok je doplněný. |
| A30 | Opraveno | Návod slibuje nedostupné odpojení přihlášení Apple | EN privacy odkazuje pouze na Apple ID settings (ř.887), CS pouze na nastavení Apple ID (ř.989). Příslib odpojení v Nastavení → Účet byl odstraněn. Aktuální funkce privacyPage/supportPage/termsPage byly přímo… |
| A31 | Opraveno | Neúspěšné smazání receptu vypadá jako úspěšné | Odstranění položky recipes.removeAll ř.276 je uvnitř do až za úspěšným await deleteRecipe ř.275. Catch ř.277–278 pouze nastaví notice; recept zůstane v seznamu. |
| A32 | Opraveno | Osobní adresa majitele zůstává v historické migraci | Aktuální migrace používá owner@example.com namísto osobní adresy; OWNER_EMAIL v deploy nadále pochází ze secretu. Reálný lokální SQLite úspěšně provedl staging/schema.sql a upravenou migraci. |
| A33 | Opraveno | Záznam užité pilulky v minulém dni se po uložení nezobrazí | Původní nativní scénář je opraven: normalizeCycleDay nyní přijímá vlastní řetězec taken (cycle-model.js:79). Reálné save(true) → list → calendar vrací taken; HH:MM i null fungují; opakovaná normalizace je… |

## Co z původních oprav ještě chybí

### A02 · P1 · Nový vstup do outboxu je chráněný, již běžící smyčka může přejít na nový účet

**Místo:** [ios-native/Loadwise/App/AppModel.swift:862](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/App/AppModel.swift#L862).

**Co oprava řeší a co bylo ověřeno:** Nový sendOutbox vstup hlídá accountUnconfirmed (834) a signedIn ověřuje /me před prvním zveřejněním phase (375–377). Položky mají owner ID a smyčka kontroluje isOthers (863). Již běžící sendWaiting ale po await api.sendQueued znovu nekontroluje phase/accountUnconfirmed/generaci; porovnává jen staré uložené ID, které se mění až po novém /me.

**Zbývající scénář a dopad:** Zadržet úspěšnou odpověď A1. Souběžný jiný požadavek dostane401, clearLocal(expired:true) zachová A2 i identitu A. Přihlášení B nastaví cookie B a accountUnchecked=true, /me B je zadržené. Uvolněná A1 nechá starou smyčku přejít k A2; owner A souhlasí se stále uloženým ID A, takže api.sendQueued odešle A2 s cookie B. APIClient používá sdílené aktuální cookies (54–61,642–647).

**Co doplnit:** Každému odesílacímu běhu přidělit snapshot account+server+session generation; při změně identity běh zastavit a před KAŽDÝM dalším odesláním ověřit aktuální generaci i potvrzenou identitu. Nestačí hlídat jen vstup sendOutbox.

**Hotovo až když:** Zadržet A1 odpověď a B /me, vyvolat expiraci A a B login; A2 nesmí být odeslána pod B. Ověřit i přepnutí serveru a legacy položky bez owner.

**Síla ověření:** Staticky dosažitelný asynchronní tok; skutečný iOS běh nebyl proveden. Přepnutí serveru samo frontu explicitně maže (1426–1427), takže pouhá shoda číselných UID nebyla vydávána za samostatný důkaz odeslání fronty.

### A03 · P2 · Rozpracovaný idempotentní zápis už není falešně potvrzen, klient jej ale po pěti odpovědích pending zahodí

**Místo:** [src/idempotency.js:60](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/idempotency.js#L60).

**Co oprava řeší a co bylo ověřeno:** Server nyní vrací 503 + Retry-After:5 místo duplicate:true/200. Lokální původní handler se skutečným SQLite vrátil pětkrát 503; první zápis poté selhal 500, další pokus uložil právě jeden záznam a úspěšný replay už handler nespustil. APIClient.swift:650–660 však pending nerozlišuje od jiné 5xx; AppModel.swift:878–886 pro každou odpověď přičte failures a při pěti položku odstraní.

**Zbývající scénář a dopad:** Při stále probíhajícím prvním zápisu může pět opakovaných refreshů/odeslání během dvouminutového pending okna vyčerpat limit. Pokud původní požadavek následně selže, už není co odeslat. Samotné iOS pořadí nebylo spuštěno na telefonu; backend pět pending odpovědí skutečně poskytl.

**Co doplnit:** Zavést explicitní pending stav rozpoznaný klientem, respektovat Retry-After a takové odpovědi nezapočítávat jako skutečná selhání vedoucí ke smazání outboxu.

**Hotovo až když:** Zadržet první zápis, odpovědět nejméně pětkrát pending, první pokus ukončit 500. Položka zůstane a další retry ji uloží právě jednou. Po úspěchu další replay zápis neduplikuje.

**Síla ověření:** Backend runtime s původním veřejným modulem a SQLite; klient staticky. Reprodukce recheck-auth-storage.mjs, výsledek auth-storage-reproductions.json.

### A05 · P2 · Jednorázový Google handoff je opravený, souběžné odvolání session ale stále může být překročeno

**Místo:** [src/google-login.js:143](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/google-login.js#L143).

**Co oprava řeší a co bylo ověřeno:** Token nově obsahuje se a jednorázové id. Opakované použití vrací 401 a nepoužitý token po předchozím zvýšení epochy také 401. Mezi kontrolou epochy na řádku143 a vydáním cookie je však await useHandoff na144; userSessionCookie na146 znovu čte aktuální epochu přes dashboard-auth.js:152.

**Zbývající scénář a dopad:** Runtime reprodukce pozastavila skutečnou claim batch po kontrole epochy0, zvýšila users.session_epoch na1 a dokončila claim. Odpověď byla200 a skutečně podepsaná cookie nesla epochu1; sessionMatchesUser ji vůči aktuální epoše1 přijal. Jde o úzký souběh s odhlášením všech zařízení, nikoli libovolné opakování již použitého ticketu nebo nový způsob jeho získání.

**Co doplnit:** Cookie pro handoff podepsat epochou uloženou v ověřeném ticketu, nikoli nově načtenou epochou účtu. Při souběžné revokaci pak zůstane neplatná; samotná další kontrola před následným opětovným čtením epochy problém neřeší.

**Hotovo až když:** Zadržet claim mezi ověřením tokenu a mintem session, zvýšit epochu a dokončit výměnu. Nesmí vzniknout session platná pod novou epochou; běžný nový token po revokaci funguje jednou.

**Síla ověření:** Runtime: původní google-login.js a dashboard-auth.js, skutečné SQLite, WebCrypto HMAC a ověření cookie; pouze nepotřebné tenancy/OIDC importy nahrazeny lokálním okolím.

### A08 · P2 · Dnešní plánovaný běh se neodečte z týdenního rozpočtu

**Místo:** [src/week-planner.js:353](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/week-planner.js#L353).

**Co oprava řeší a co bylo ověřeno:** Dnešní samotný plánovaný běh se již započítává. committedRunMinutes však počítá dnešek jako Math.max(planned,done), bez párování konkrétních aktivit. Skutečný weekProposal s ranním hotovým 30min během a jiným večerním plánovaným 30min během započte jen 30 min a navrhne dalších 30 min při cap=60.

**Zbývající scénář a dopad:** Dva různé dnešní běhy jsou považovány za jeden: skutečně obsazeno 60, započteno 30, nový návrh 30, celkem 90 při limitu 60. Stejný helper používá entrypoint.js:741.

**Co doplnit:** Párovat plán a dokončení podle identifikátoru/vazby či překryvu; sečíst nesplněné plány a dokončené odlišné běhy. Souhrnné max bez identity nestačí.

**Hotovo až když:** Ranní hotový a večerní jiný plán se započítají oba; plán se svým skutečným dokončením se započítá právě jednou.

**Síla ověření:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

### A10 · P1 · Odhlášení cyklus vyčistí, ale pozdní odpověď ho může obnovit pod dalším účtem

**Místo:** [ios-native/Loadwise/App/AppModel+Cycle.swift:9](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/App/AppModel+Cycle.swift#L9).

**Co oprava řeší a co bylo ověřeno:** Nový forgetAccountData nastaví cycle=nil, cycleHealthSynced=false, odstraní pill a export (AppModel415–419), volá se při běžném logoutu (1447) i zjištěném jiném účtu (411). loadCycle však po await api.cycle bez kontroly vlastníka/generace přiřadí cycle a uloží pill nastavení (9–14).

**Zbývající scénář a dopad:** A spustí obnovení Dnes; refresh(announce:true) vytváří samostatný Task (AppModel456), který může čekat na loadCycle (494–498). A se odhlásí a B přihlásí. clearLocal běžící announcedRefresh neruší a loadCycle pozdní odpověď A přijme, takže B znovu vidí A cyklus a ukládají se A pill preference. HealthView při nenil cycle počáteční načtení přeskočí (93). Další cesta bez závodu, omezená na interní testery: live A a staging B mají stejné číselné UID, ale jiný e-mail. switchServer použije clearLocal(expired:true), a anotherAccount426–429 shodu ID přijme jako stejný účet bez serverového namespace; cycle ani pill se nevymažou.

**Co doplnit:** Zavést account+server/session generation na čtení i zápis cyklu a zkontrolovat ho po každém await před změnou modelu, lokálních nastavení nebo voláním CycleHealth. Při změně identity rušit staré obnovení.

**Hotovo až když:** Zadržet A /cycle v obnovení Dnes, logout A, login B, uvolnit odpověď: B nevidí A cycle, nevzniknou A připomínky a pozdní odpověď nezahájí import.

**Síla ověření:** Statická analýza celého volajícího toku včetně samostatného announcedRefresh Task; iOS runtime nebyl dostupný.

### A11 · P2 · Export se při potvrzené změně účtu resetuje, ale během nepotvrzené identity může použít staré preference

**Místo:** [ios-native/Loadwise/App/AppModel.swift:713](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/App/AppModel.swift#L713).

**Co oprava řeší a co bylo ověřeno:** AppleHealthExport.reset nově odstraní prefs i written ledger (47–50) a forgetAccountData ho při běžném logoutu/jiném účtu volá. Při expired:true se export zachovává. Pokud B /me selže, signedIn přesto nastaví phase.signedIn (377) a retry loadAccountInitial čeká; accountUnconfirmed hlídá import/outbox, nikoli refreshFood nebo saveFoodDay. refreshFood spustí export snapshotu B na713 se stále platnými globálními prefs A.

**Zbývající scénář a dopad:** A má povolený export výživy/vody, jeho session vyprší. B se přihlásí; první /me selže a druhé je pomalé. B otevře Jídlo a jeho /food-today uspěje dřív než ověření identity. Export použije A preference, i když B má export vypnutý. Samostatný export neobsahuje účet ani accountUnconfirmed guard (AppleHealthExport215–217). Další cesta bez selhání /me, omezená na interní testery: live A a staging B mají stejné numerické UID a odlišný e-mail. switchServer uchová export a anotherAccount kvůli shodě ID reset přeskočí; následný Food export B použije A prefs. Account ID je unikátní jen v rámci serveru.

**Co doplnit:** Do potvrzení identity blokovat veškeré automatické HealthKit exporty, ne jen import/outbox. Preference i ledger navázat na account+server a po await ověřovat generaci; serverové prefs B přijmout až pro potvrzeného vlastníka.

**Hotovo až když:** A export ON→expired→B, B /me selže/zůstane zadržený, B food uspěje: žádný export bez potvrzených B preferencí. Po B /me se musí použít B nastavení.

**Síla ověření:** Statický dosažitelný tok a původní kód exportu; nebylo prováděno skutečné HealthKit zapisování.

### A18 · P2 · Upravená vlastní šablona mění detail starších plánů

**Místo:** [src/workout-library.js:70](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/workout-library.js#L70).

**Co oprava řeší a co bylo ověřeno:** Nově plánované vlastní tréninky čtou neměnné planned_own_workouts kopie; pozdější úprava a smazání šablony je neovlivní. Pro staré own-<id> však zůstává fallback do saved_workouts a není přítomna migrace starých schedule odkazů. Runtime: starý plán Legacy ride/sport ride se po editaci šablony jmenuje Edited run/sport run; po smazání šablony scheduledLink vrací null.

**Zbývající scénář a dopad:** Oprava chrání nová plánování, nikoli všechny existující plány vzniklé před upgradem. Jejich název/sport/detail a odkazy pro následné operace závisejí na měnitelné šabloně. Staré již přepsané struktury nelze bez důvěryhodného uloženého eventu automaticky obnovit. Po smazání šablony může některé údaje detailu zachránit uložený event; nejde o tvrzení, že zmizí všechny kalendářové údaje.

**Co doplnit:** Zpětně převést staré schedule odkazy na neměnné kopie, ideálně z uloženého lokálního/provider eventu; zachovat použitelný detail a vazbu i po smazání šablony.

**Hotovo až když:** Vytvořit databázi s plánem před upgradem, provést upgrade, editovat/smazat šablonu a ověřit původní název, sport, strukturu a scheduledLink. Nové plány nadále zůstávají stabilní.

**Síla ověření:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

### A22 · P2 · Rozpracovaná Google operace je označená jako odeslaná aktivita

**Místo:** [src/sync-destinations.js:414](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/sync-destinations.js#L414).

**Co oprava řeší a co bylo ověřeno:** Nová větev done:false ukládá operations/... jako pending a při retry nejprve GET, pak PATCH výsledného záznamu. To lokálně prošlo bez druhého POST. Každý pending však stále volá setStatus s attempts=attempts+1; retrySyncSends vybírá jen attempts<3.

**Zbývající scénář a dopad:** Po úvodním odeslání a dvou cron kontrolách zůstává status=pending, remote_id=operations/slow a attempts=3. I když se operace poté dokončí, další cron už neudělá žádný GET. Totéž vyvolají dočasně nedostupné odpovědi kontrol operace. UI pending ukazuje jen „odešle se“, tlačítko retry nabízí pouze pro error. Ruční serverové retry může záznam opravit, automatický tok se ale zastaví.

**Co doplnit:** Oddělit počet skutečných selhání od čekání na přijatou operaci; pending průběžně kontrolovat s omezeným backoffem/TTL. Po překročení TTL přejít do srozumitelného obnovitelného stavu a nabídnout bezpečné retry. Vždy zachovat identitu operace nebo výsledného resource.

**Hotovo až když:** Operace pending přes tři kontroly a později done přejde automaticky do sent bez druhého POST. Ověřit i dočasné 503/timeouts a UI stavu pending/error.

**Síla ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Pro případ done:false byly původní funkce skutečně provedeny; reálné Google Health nebylo použito.

### A23 · P2 · Smazaná aktivita Intervals zůstává v aplikaci

**Místo:** [src/index.js:1227](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/index.js#L1227).

**Co oprava řeší a co bylo ověřeno:** ACTIVITY_DELETED nyní předává konkrétní ID až do importeru a maže je i mimo recent okno. Neprázdná odpověď také reconciliuje chybějící aktivity a vrací watch duplicitu na primary. Lokálně ověřeno: chybějící i2 odstraněno, watch2 znovu primary; pojmenované i1 odstraněno i při prázdné odpovědi.

**Zbývající scénář a dopad:** Původní scénář poslední smazané aktivity při úplném, ale prázdném refreshi stále selhává. Podmínka activities.length zcela přeskočí reconciliation. Týká se zejména spojení osobním API klíčem bez OAuth webhooků nebo ztraceného webhooku; stale aktivita dál ovlivňuje historii a výpočty.

**Co doplnit:** Doplnit bezpečný způsob potvrzení smazání i při nulovém seznamu: autoritativní úplný interval či konkrétní delete události s obnovou po výpadku. Nepřevést každou neověřenou prázdnou/selhanou odpověď na plošné smazání.

**Hotovo až když:** Po odstranění jediné aktivity u API-key spojení se po úspěšném úplném refreshi odstraní i místní kopie; odpověď 503/neúplný seznam historii nemaže. Ověřit i obnovení po ztraceném webhooku a párování watch kopie.

**Síla ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Skutečný syncIntervalsActivities, pointStatement a removeIntervalsActivities, poskytovatel pouze lokálně nahrazen kompletními testovacími odpověďmi.

## Nové nálezy

| ID | Priorita | Problém |
|---|---|---|
| N01 | P1 | Samostatný import cyklu z HealthKitu může po změně účtu odeslat data pod novou session |
| N02 | P2 | Svalová únava předchozího účtu přetrvává po běžném odhlášení a ovlivní sestavení tréninku |
| N03 | P2 | Chyba staršího gym zápisu opustí novější snapshot, který už volajícímu oznámil úspěch |
| N04 | P2 | Pozdní AI návrh původních filtrů přepíše nový výběr knihovny |
| N05 | P2 | Dvě souběžná schválení překročí vlastní limit testerů |
| N06 | P2 | Starší čekající zájemci zmizí ze správy po překročení300 položek |
| N07 | P2 | Dvě souběžná plánování stejné vlastní šablony vytvoří duplicitní kalendářové události |
| N08 | P2 | AI workout může překročit denní časový limit po úpravě pro venkovní prostředí |
| N09 | P2 | Ranní připravenost se neodesílá uživatelům pouze s WHOOP nebo Ultrahuman |
| N10 | P2 | Smazání posledního jídla nebo nápoje ve Zdraví se po opravě nepromítne do Aurinu |
| N11 | P2 | Přesun importovaného jídla může při selhání vytvořit kopii a po opakování další |
| N12 | P2 | Přepnutí měsíce v cyklu zkreslí dnešní stav a starší záznamy |
| N13 | P2 | Souběžné změny cyklu přepisují jiné zápisy a mohou obnovit odvolané sdílení |

### N01 · P1 · Samostatný import cyklu z HealthKitu může po změně účtu odeslat data pod novou session

**Místo:** [ios-native/Loadwise/App/CycleHealth.swift:45](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/App/CycleHealth.swift#L45).

**Původ:** Nově nalezený starší tok; netvrdíme, že vznikl opravami od prvního auditu.

**Příčina:** CycleHealth.sync vezme sdílený APIClient, awaituje flowDays (několik HK queries) a následně volá importAppleCycle bez session/account/server generation guard. Nový AppleHealth.generation tento oddělený importér nechrání. clearLocal jen přepne cycleHealthSynced a zresetuje model, HealthKit queries ani pokračující sync neinvaliduje.

**Scénář a dopad:** A s povoleným cyklem zahájí import 400 dní citlivých údajů. B se přihlásí během HealthKit čtení. Po jeho dokončení používá APIClient aktuální cookie B a do B se odešlou data telefonu, jejichž import zahájil A; přijímací route neověřuje zapnutí cyklu a přijme je i při B cycle disabled.

**Co opravit:** Importér cyklu musí mít stejný account+server+generation kontext jako hlavní import; ověřit ho po každém čtení a před uploadem. Přijímací route má dodatečně vyžadovat odpovídající aktivní nastavení/volbu.

**Hotovo až když:** Zadržet flowDays A, odhlásit nebo nechat vypršet A, přihlásit B s cyklem OFF, uvolnit HealthKit výsledek: žádný POST ani zápis do B. Totéž při přepnutí serveru.

**Síla ověření:** Nativní race staticky doložený: AppModel+Cycle12–14 zahajuje samostatný sync; CycleHealth45–54 nemá kontrolu. Lokálně spuštěná původní current route/store a skutečné SQLite: B user_id22, cycleEnabled=false, POST /cycle/apple vrátil200 saved1 a uložil řádek B. Jazyk, datum a přihlášený kontext izolované; žádné reálné HealthKit ani síťové volání.

### N02 · P2 · Svalová únava předchozího účtu přetrvává po běžném odhlášení a ovlivní sestavení tréninku

**Místo:** [ios-native/Loadwise/Screens/MuscleViews.swift:122](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/MuscleViews.swift#L122).

**Původ:** Nově nalezený starší tok; netvrdíme, že vznikl opravami od prvního auditu.

**Příčina:** AppModel.muscleFatigue je sdílené pole modelu (58), které clearLocal ani forgetAccountData nevymažou. model.muscles ho vrací pro každého nedemo uživatele. MusclesWidget a builder ho načítají jen když je nil.

**Scénář a dopad:** A otevře Svaly a odhlásí se, B se přihlásí na stejném telefonu. Widget bez jakéhokoli načítání ukáže A únavu a připravenost; sestavovač může automaticky vybrat focus podle A svalů (GymTools284–288). Nevyžaduje závod nebo chybu sítě.

**Co opravit:** Vyčistit svalový model při ztrátě/změně identity a navázat výsledky loadMuscles na generaci account+server; po přihlášení B načíst B data. Zahrnout všechny per-account objekty do společného resetu.

**Hotovo až když:** A se zřetelně unavenými svaly→běžný logout→B: widget ani předvolba builderu nikdy nepoužijí A model; zadržená A odpověď /muscles ho nesmí později obnovit.

**Síla ověření:** Statický jednoznačný běžný tok: property58, kompletní clearLocal1434–1479 a forgetAccountData415–419 neobsahují reset; MuscleViews12,112–122 a GymTools284–288 starý model použijí. iOS runtime nebyl k dispozici.

### N03 · P2 · Chyba staršího gym zápisu opustí novější snapshot, který už volajícímu oznámil úspěch

**Místo:** [ios-native/Loadwise/App/AppModel.swift:1066](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/App/AppModel.swift#L1066).

**Původ:** Starší chyba, nově odhalená při této revizi.

**Příčina:** Při souběžném saveGym druhá změna pouze nastaví gymPending a vrátí se jako úspěšná. Pokud právě probíhající deliver vyhodí OutboxRefusal.retry (např. HTTP503/429), smyčka skončí před next = gymPending. Pending zůstane jen v paměti a nikdo ho neodešle. deliver zachytává pouze síťové URLError, nikoli serverové retry.

**Scénář a dopad:** Uživatel přidá cvik a během pomalého POST dokončí sérii. Druhé uložení se tváří úspěšně, první později selže. Novější dokončená série není na serveru ani v outboxu. Při online znovuotevření gymDay načte starší serverový stav a přepíše i diskovou cache novějšího snapshotu.

**Co opravit:** Uchovávat nejnovější snapshot trvale před potvrzením volajícímu a při jakémkoli selhání fronty jej zachovat k opakování. U callers čekajících na uložení dokončit až po skutečném zápisu či durable enqueue; rozlišit retry od trvalého odmítnutí.

**Hotovo až když:** Zadržet POST A, spustit save B s dokončenou sérií, A vrátit503 i429. B musí být uložen nebo trvale čekat a přežít ukončení aplikace; online GET nesmí přepsat neodeslané B.

**Síla ověření:** Staticky doložený dosažitelný interleaving; AppModel1061–1076, deliver773–787, APIClient.sendQueued642–660, GymLive.persist510–519 a TrainingMode.complete1262–1315. Swift runtime nebyl dostupný.

### N04 · P2 · Pozdní AI návrh původních filtrů přepíše nový výběr knihovny

**Místo:** [ios-native/Loadwise/Screens/TrainingLibrary.swift:335](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/TrainingLibrary.swift#L335).

**Původ:** Zavedeno po původní revizi.

**Příčina:** Tlačítko Jiný návrh na ř.317 spouští neuložený unstructured Task. Změna filtrů zruší jen .task(id:) na ř.274, nikoli tuto úlohu. compose po await kontroluje pouze Task.isCancelled, nikoli shodu zachycených filtrů nebo generace, a bezpodmínečně přepisuje composed/composeVariant/composeMore.

**Scénář a dopad:** Pro filtry A uživatel požádá o jiný návrh, pak přepne délku/typ/prostředí na B. Načtení a AI návrh B doběhnou. Pozdější odpověď A zůstává nezrušená a nahradí B; obrazovka nadále ukazuje filtry B, ale karta i následné naplánování pracují s tréninkem A.

**Co opravit:** Používat jeden řízený compose task zrušený při každé změně klíče filtrů. Před každou změnou stavu po await ověřit zachycený úplný klíč filtrů a generaci požadavku; stejná kontrola musí chránit i catch/defer/loading.

**Hotovo až když:** Zadržet variant1 filtrů A, změnit filtry na B a dokončit search+compose B, teprve potom pustit A. Zobrazený a plánovaný workout musí stále patřit B. Zopakovat s chybou A a s B bez podpory compose.

**Síla ověření:** Statický průchod .task274, tlačítko317, compose331–350 a load446–466; APIClient+Training.composeWorkout parametrizuje request aktuálními filtry. Neproveden SwiftUI/URLSession runtime test.

### N05 · P2 · Dvě souběžná schválení překročí vlastní limit testerů

**Místo:** [src/testflight-waitlist.js:89](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/testflight-waitlist.js#L89).

**Původ:** Tok přidaný nebo změněný po původní revizi.

**Příčina:** Počet členů TestFlight skupiny se načte a porovná s TESTER_LIMIT=20 před vzdáleným přidáním, bez rezervace či serializace schvalování. Omezení tlačítek v jednom WaitlistView chrání jen jednu otevřenou obrazovku, nikoli dva požadavky majitele z různých zařízení.

**Scénář a dopad:** Při19 testerech dvě souběžná schválení obě vidí19 a obě pozvou dalšího; skupina skončí s21 členy a obě lokální položky mají invited. Funkce tak nedodrží vlastní kapacitu pilotu. Není to anonymně přístupná administrátorská akce.

**Co opravit:** Serializovat schválení pro zvolenou skupinu napříč požadavky/isolaty a rezervovat poslední místo před vzdáleným zápisem; při nejistém výsledku jej nejprve smířit s App Store Connect, nikoli slepě opakovat.

**Hotovo až když:** Dvě souběžná schválení při19/20 přijmou nejvýše jednoho nového testera. Opakovaný požadavek na tutéž adresu je bezpečný a rezervace se po skutečném odmítnutí uvolní.

**Síla ověření:** Runtime původních list/decide/invite funkcí a SQLite; generovaný jednorázový testovací ES256 klíč a deterministické lokální Apple odpovědi. Oba GET počtu byly řízeně dokončeny před oběma přidáními:19→21. Skutečná Apple API nebyla volána.

### N06 · P2 · Starší čekající zájemci zmizí ze správy po překročení300 položek

**Místo:** [src/testflight-waitlist.js:54](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/testflight-waitlist.js#L54).

**Původ:** Tok přidaný nebo změněný po původní revizi.

**Příčina:** Admin API vrací pouze300 nejnovějších řádků napříč pending i invited a teprve poté je rozdělí. Nemá cursor, total ani informaci o zkrácení. Waitlist model a obrazovka nepodporují další stránku ani hledání.

**Scénář a dopad:** Se301 čekajícími zůstává nejstarší zájemce v DB, ale není vidět ve správě a nelze jej běžně vybrat ke schválení či smazání. Další příchozí vytlačují předchozí čekající; počet pending v nastavení je zároveň jen velikost vráceného výřezu. Data nejsou fyzicky smazaná a uvolnění výřezu může položku znovu odkrýt.

**Co opravit:** Přidat stránkování a celkové počty; pending a invited načítat odděleně, ideálně s pořadím podle stáří čekání. UI musí umět dojít až k poslední položce.

**Hotovo až když:** Při více než300 smíšených i čistě pending položkách lze v UI najít, schválit i smazat nejstaršího čekajícího a badge ukazuje skutečný počet.

**Síla ověření:** Runtime původní listWaitlist se skutečným SQLite:301 pending uložených,300 vrácených, ID1 chybí a nejstarší vrácené ID2. Absence stránkování potvrzena v APIClient+Waitlist.swift:15–27 a WaitlistView.swift:82–87.

### N07 · P2 · Dvě souběžná plánování stejné vlastní šablony vytvoří duplicitní kalendářové události

**Místo:** [src/workout-templates.js:103](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/workout-templates.js#L103).

**Původ:** Tok přidaný nebo změněný po původní revizi.

**Příčina:** plannedCopy dělá SELECT na shodný obsah a poté INSERT s náhodným ID. V tabulce je unikátní jen (user_id,id), nikoli vlastník+šablona+obsah. Dva requesty mohou oba přečíst žádnou kopii a založit odlišná ID. Tato ID se promítají do external_id události, takže deduplikace plánování je už nespojí.

**Scénář a dopad:** Při souběžném opakování stejného POST /my-workouts/:id/schedule vzniknou na stejný den dva stejné plány a mohou se nezávisle exportovat poskytovatelům. Lokální reprodukce původního plannedCopy, scheduleWorkoutInIntervals a storeLocalEvent na skutečném SQLite vytvořila 2 kopie, 2 local_workouts a 2 workout_schedule_links.

**Co opravit:** Zavést deterministický identifikátor či unikátní otisk obsahu kopie a atomický INSERT ON CONFLICT se znovunačtením vítězné kopie; zajistit idempotenci stejného plánování stejného obsahu/dne.

**Hotovo až když:** Pozastavit dva SELECT stejného obsahu před INSERT, dokončit oba requesty a ověřit jednu kopii, jednu kalendářovou událost a jedno exportní zadání.

**Síla ověření:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny. Výběr výsledku SELECT byl bariérou deterministicky souběžný. Samotné původní SQL, výpočet external_id a lokální ukládání byly skutečné; pouze delivery do providerů a metadata byly izolované.

### N08 · P2 · AI workout může překročit denní časový limit po úpravě pro venkovní prostředí

**Místo:** [src/entrypoint.js:2379](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/entrypoint.js#L2379).

**Původ:** Tok přidaný nebo změněný po původní revizi.

**Příčina:** libraryDay stanoví maxDurationMinutes a běžné hledání filtruje již renderované workouty. Nová /workouts/compose tuto mez nepředá validátoru; composeFits kontroluje původní strukturu s tolerancí ±5 min a až poté se přidá venkovní rozjetí. Po renderForEnvironment už žádná kontrola limitu není.

**Scénář a dopad:** Při automatické délce 30 min a denním maximu 30 min projde validní tempo struktura 5+25+5=35 min. Venkovní render prodlouží úvodních 5 min na 15, takže uživatel obdrží 45min trénink. Dynamicky spuštěná původní routa s izolovaným validním composerem vrátila HTTP 200 a 45 min, ačkoli filters.maxDurationMinutes=30. Nativní knihovna tento fallback automaticky vyžádá po result.compose=true.

**Co opravit:** Validovat délku a příslušné limity nad konečným renderem pro požadované prostředí. Pro automatickou délku vynucovat tvrdý denní rozpočet; při delším výsledku upravit strukturu a přepočítat nebo výsledek odmítnout.

**Hotovo až když:** Pro automatický limit 30 min, outdoor a původní zahřátí 5 min nesmí compose vrátit workout nad 30 min. Přidat stejné kontraktní kontroly délky pro search a compose a ověřit cache odpovědi.

**Síla ověření:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny. composeFits, buildWorkout a renderForEnvironment byly původní. Routa byla spuštěna s izolovanými metadaty a předem daným validním výsledkem composeru; reálný AI model, prompty ani síť nebyly testovány.

### N09 · P2 · Ranní připravenost se neodesílá uživatelům pouze s WHOOP nebo Ultrahuman

**Místo:** [src/entrypoint.js:258](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/entrypoint.js#L258).

**Původ:** Nově zjištěný problém; není tím automaticky tvrzen vznik až po první revizi.

**Příčina:** morningPush zůstává pouze uvnitř jobu sync, který vyžaduje Google nebo Intervals. WHOOP/Ultrahuman job jen importuje a invaliduje cache. Oddělený Apple upload morningPush vyvolává, ale WHOOP/Ultrahuman takovou cestu nemají. Nový obecný push job volá pouze coachPush.

**Scénář a dopad:** Uživatel s telefonem, souhlasem, dostatkem nočních dat a zapnutou „Ranní připraveností“, ale pouze prstenem/WHOOP, nedostane slíbenou ranní notifikaci. Při vypnutém kouči mu nový coach job nepomůže. Chyba existovala i dříve, nově je zjištěna při kontrole sousedního toku A09.

**Co opravit:** Zavést samostatný obecný job ranní připravenosti pro zařízení s tokenem a povolenými notifikacemi, případně jej volat po každém relevantním importu a zajistit pravidelnou obnovu při pozdním příchodu dat. Zachovat existující once-per-day claim a časové okno.

**Hotovo až když:** Pouze WHOOP a pouze Ultrahuman: po příchodu dnešní noci v 5–11 lokálně, morning=true/coach=false, dorazí právě jedna ranní připravenost. Totéž pro Apple/Google/Intervals bez duplikátů.

**Síla ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Byly provedeny skutečné definice USER_JOBS s izolovanými send/import callbacks: WHOOP/Ultrahuman vyvolaly pouze coach, Google morning+coach. Reálné APNs nikoli.

### N10 · P2 · Smazání posledního jídla nebo nápoje ve Zdraví se po opravě nepromítne do Aurinu

**Místo:** [src/apple-food.js:94](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/apple-food.js#L94).

**Původ:** Tok přidaný nebo změněný po původní revizi.

**Příčina:** Ochrana A24 nerozlišuje prázdné neověřené čtení od skutečně prázdného úplného výsledku. Jakmile jsou meals nebo drinks prázdné, readMeals/readDrinks=false a žádný známý záznam daného druhu se nemaže. Klient posílá běžný full-window snapshot bez explicitních deleted IDs.

**Scénář a dopad:** Uživatel odstraní poslední importované jídlo či nápoj v Health zdroji. Aurin jej při dalších synchronizacích ponechá, a tím může dál počítat energii nebo hydrataci, dokud nepřijde další neprázdný import nebo jej uživatel nesmaže v Aurinu. Jde o regresní důsledek bezpečnějšího řešení A24.

**Co opravit:** Přenášet potvrzená smazaná HealthKit ID z anchored queries nebo jiný explicitní důkaz úplnosti. Neobnovovat nebezpečné plošné mazání na základě libovolného prázdného pole. Stav a anchor vázat na účet/server.

**Hotovo až když:** Import jednoho jídla a jednoho nápoje → smazání obou ve zdroji → sync odstraní pouze jejich kopie v Aurinu. Odebrání oprávnění a prázdná odpověď během obnovy HealthKitu historii nemažou.

**Síla ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Backend lokálně po importu jednoho jídla a nápoje a následném prázdném snapshotu zachoval oba řádky. Emitování full-window snapshotu v AppleHealthReader.foodUpload staticky ověřeno; telefon nebyl spuštěn.

### N11 · P2 · Přesun importovaného jídla může při selhání vytvořit kopii a po opakování další

**Místo:** [src/food-entry-management.js:61](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/food-entry-management.js#L61).

**Původ:** Tok přidaný nebo změněný po původní revizi.

**Příčina:** Nový takeOver provede INSERT ruční kopie samostatně a až potom hideAppleFood, který vytváří a v batchi zapisuje tombstone a maže původní import. Selhání druhého kroku nastane po již potvrzeném INSERTu. Funkci používá single PATCH i bulk move a nová kopie nemá idempotentní vazbu na originál.

**Scénář a dopad:** Při dočasném selhání D1 v druhé části dostane uživatel chybu, ale kopie už existuje a originál také. Opakování stejného původního ID vytvoří druhou kopii a teprve odstraní import. V nové cílové datum se potom započítají dvě porce. U smíšené dávky může další úspěšná položka navíc změnit chybu na tiché skipped, které klient ignoruje.

**Co opravit:** Provést vložení nové položky, tombstone a odstranění původní v jediné transakční D1 batch se sdíleným a stabilním identifikátorem přesunu; validovat vše před zápisem. Přidat idempotenci pro ztracenou odpověď a v UI nezahazovat skipped.

**Hotovo až když:** Vynutit selhání před tombstone/delete: buď se neprovede nic, nebo je přesun jednoznačně dokončen a vrácen. Opakované single PATCH i bulk move stejné originální položky nevytvoří druhou kopii. Ověřit i souběžné opakování a ztracenou odpověď.

**Síla ověření:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Do skutečného DB.batch při hideAppleFood byla vložena jednorázová simulovaná přechodná chyba. V obou skutečných veřejných helperech bulkFoodEntries(action=move,ids=[1]) a updateFoodEntry(id=1,date=...) po chybě zůstaly originál+jedna ruční kopie; po retry dvě ruční kopie a žádný originál. Nejde o pozorovaný produkční incident.

### N12 · P2 · Přepnutí měsíce v cyklu zkreslí dnešní stav a starší záznamy

**Místo:** [src/routes-cycle.js:19](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/routes-cycle.js#L19).

**Původ:** Starší chyba, nově odhalená při této revizi.

**Příčina:** cycleView používá jeden dotaz od today−200 dní do první den vybraného měsíce+45 dní pro historický kalendář i výpočet dnešního stavu. Při starém měsíci není zadaný měsíc v načteném intervalu; při nedávném předchozím měsíci v něm naopak chybí poslední dny.

**Scénář a dopad:** Na 20.10.2026 uložená dnešní pilulka21:04 je v říjnovém zobrazení taken, ale při přepnutí na září state.date zůstane20.10 a pill.taken se změní na null. Nativní kalendář pod měsícem vykresluje dnešní PillCard z tohoto stavu. Lednový uložený flow3+cramps se zároveň vykreslí jako flow0 a prázdné symptomy; úprava takového zdánlivě prázdného dne může přepsat uložené krvácení na0.

**Co opravit:** Oddělit okno vstupů pro dnešní výpočet od přesného rozsahu požadovaného kalendářního měsíce; neodvozovat dnešní stav z omezené historie zobrazeného měsíce.

**Hotovo až když:** Přepnutí mezi říjnem a zářím nemění stav dnešní již vzaté pilulky. Leden mimo today−200 zobrazí skutečně uložené hodnoty. Přidání symptomu do takového dne nepřepíše starý flow nesprávným výchozím0.

**Síla ověření:** Runtime recheck-platform-cycle.mjs: skutečné cycleView/cycle-store/cycle-model s lokálním SQLite; pouze jazykový import izolovaný. platform-cycle-reproduction.json → previousMonthCurrentState a oldCalendar. UI návaznost staticky CycleViews.swift:481,508,521–523 a443–450; AppModel+Cycle.swift:9–10.

### N13 · P2 · Souběžné změny cyklu přepisují jiné zápisy a mohou obnovit odvolané sdílení

**Místo:** [src/cycle-store.js:67](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/cycle-store.js#L67).

**Původ:** Starší chyba, nově odhalená při této revizi.

**Příčina:** saveCycleDay načte starý celý řádek a poté do UPSERT zapíše i nepředané hodnoty z tohoto snapshotu. saveCycleSettings obdobně načte a přepíše celé settings_json. Dvě nezávislé částečné změny tedy mohou obě vycházet ze stejného starého stavu a pozdější zápis vrátí jiná pole zpět.

**Scénář a dopad:** Dvě souběžné změny dne flow3 a symptoms[cramps] skončí flow0 a symptoms[cramps], přestože obě operace dokončí bez chyby. Souběh vypnutí shareWithCoach a změny času připomínky obnoví shareWithCoach:true; následující cycleForCoach pak může znovu předávat cyklus AI proti poslední volbě uživatele. Týká se např. více zařízení nebo souběžných nečekajících akcí, ne anonymního přístupu.

**Co opravit:** Provádět částečné změny atomicky nad aktuálními hodnotami (jen předaná pole / atomická JSON aktualizace), nebo zavést verzi a CAS s opakováním na čerstvém stavu. Změna jiného nastavení nesmí obnovit odvolaný souhlas.

**Hotovo až když:** Obě pořadí a zadržené souběhy dvou různých změn zachovají jejich sjednocení. Po souběhu shareWithCoach:false a nesouvisející změny zůstane sdílení vypnuté a cycleForCoach vrátí null.

**Síla ověření:** Runtime recheck-platform-cycle.mjs s původním aktuálním store a reálným SQLite, přirozené Promise.all bez umělé implementace zápisů: platform-cycle-reproduction.json → concurrentPatch a concurrentSettings. Routes-cycle.js:37,42 předává změny do těchto funkcí bez společné transakce.

## Důkazy uzavření původních bodů

### A01 · opraveno · HealthKit po expiraci přihlášení pokračuje do dalšího účtu

**Místo:** [ios-native/Loadwise/App/AppleHealth.swift:338](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/App/AppleHealth.swift#L338).

Původní AppleHealth.perform nyní před každým uploadem kontroluje generaci, enabled a accountUnconfirmed (338). signedIn nejprve získá /me (AppModel375–377); při neznámé identitě zůstává accountUnchecked (374,390–391), při jiném účtu checkAccount zavolá pause (410), které přes disconnect zvýší generation (AppleHealth206). I collect zahájený před změnou účtu tedy přes toto místo pokračovat nemůže.

**Ověření a limity:** Statická analýza změny i volajících; iOS/HealthKit runtime nebyl dostupný.

**Návazná poznámka:** Opraven je konkrétní původní tok AppleHealth.run/reader.collect. Samostatný importér CycleHealth tento mechanismus nepoužívá a je veden jako nový nález N01, nikoli jako druhé započítání A01. Přepnutí live/staging zůstává výslovně navržené jako přenos stejného device-level zapnutí do zvoleného serveru (AppModel1417–1419); status fixed se vztahuje na původní změnu účtu při přihlášení na stejném serveru, nikoli na důkaz per-server vlastnictví oprávnění.

### A04 · opraveno · OAuth callback nepřipíná propojení k původnímu účtu

**Místo:** [src/google-oauth.js:25](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/google-oauth.js#L25).

oauthStateValue v connect-return.js:13 přidává USER_ID do state cookie a startedBy:18 ho porovnává s aktuálním účtem. Kontrola proběhne před výměnou kódu a uložením credentials. Stejná kontrola je v Intervals:44, Wahoo:96, WHOOP:81 a Ultrahuman:87. Původní Google callback při startu UID11 a návratu UID22 vrátil 403, bez volání token endpointu a bez zápisu. Návrat UID11 uspěl a zapsal jen UID11.

**Ověření a limity:** Google runtime ve VM s původním callbackem/helperem a izolovaným token/storage okolím; pět providerů zdrojově ověřeno.

**Návazná poznámka:** Původní scénář změny platné browser session A→B byl odstraněn. Ostatní provideři byli ověřeni staticky; reálná autorizace s externími službami nebyla provedena.

### A06 · opraveno · Starší úprava cviku přepíše později dokončenou sérii

**Místo:** [ios-native/Loadwise/Screens/TrainingModeView.swift:976](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/TrainingModeView.swift#L976).

saveEdited ukládá edited přes model.saveGym na ř.986 před prvním loadMuscles na ř.991; add totéž na ř.1009 před metadata na ř.1014. AppModel.saveGym ř.1061–1076 řadí přijaté snapshoty stejného dne. Původní zadržení gymMuscles už neodloží starší zápis za dokončení série.

**Ověření a limity:** Statická kontrola implementace, volajících a diffu. Xcode/Swift runtime není dostupný; scénář nebyl spuštěn na telefonu.

**Návazná poznámka:** Původní metadata race odstraněn. Odděleně byl nalezen dosud neřešený případ zahazování pending snapshotu po chybě předchozího požadavku (N03).

### A07 · opraveno · Běžecký limit přidává běhy i při vyčerpaném rozpočtu

**Místo:** [src/week-planner.js:338](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/week-planner.js#L338).

capRunVolume nyní vyřazuje běhy pod minimem 20 min a po zaokrouhlení nepřekročí zbývající prostor. Původní 4 běžecké dny dávají celkem 60 min místo 80. Po již hotových 60 min nevznikne další běh. Prošlo 308 kombinací limitu, již obsazených minut a délek návrhů.

**Ověření a limity:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

**Návazná poznámka:** Původní chyba minimálních délek je opravená; vstup committed má samostatnou zbývající chybu A08.

### A09 · opraveno · Push kouče se neplánuje pro účty bez Google nebo Intervals

**Místo:** [src/entrypoint.js:263](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/entrypoint.js#L263).

Samostatný coach-push job má push:true a nevyžaduje providera; fan-out sjednocuje usersWithProviders a usersWithPushTokens, runUserJobs přijímá push job i s prázdným CONNECTED_PROVIDERS. Push tokeny zůstávají v centrální DB (user-data-routing.js). Lokální skutečný výběr fan-out poslal právě jednou uživatele Apple-only, WHOOP, Ultrahuman, Google a Intervals.

**Ověření a limity:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Selekce a definice skutečných jobů byly provedeny, APNs a generování návrhů nebyly volány.

**Návazná poznámka:** Původní chyba koučovy notifikace je odstraněna. Oddělený problém ranní připravenosti pro WHOOP/Ultrahuman je uveden jako N09; nejde o popření opravy kouče.

### A12 · opraveno · Vypnutí všech kategorií Apple Health nezastaví čtení

**Místo:** [ios-native/Loadwise/Screens/AppleHealthViews.swift:120](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/AppleHealthViews.swift#L120).

Původní prázdný onChange guard je nahrazen health.disconnect (120–122). disconnect nastaví enabled=false, uloží ho, odstraní resume key, zastaví observers a zvýší generation (AppleHealth204–209); pending collect je blokovaný kontrolou338.

**Ověření a limity:** Statická analýza onChange/disconnect/perform; neproběhl runtime test s iOS oprávněními.

**Návazná poznámka:** Neprázdný předchozí výběr categories zůstává uložený, takže po znovuotevření stránky se mohou zobrazit staré zapnuté přepínače, přestože enabled=false a čtení je vypnuté. Jde o návaznou UX nepřesnost, nikoli pokračování původního uploadu při všech OFF.

### A13 · opraveno · Chyba potvrzení návrhu odstraní možnost opakování

**Místo:** [ios-native/Loadwise/Screens/CoachView.swift:305](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/CoachView.swift#L305).

Bubble má oddělené failed a decided; catch decide ukládá do failed na ř.316. Jen úspěch plní decided na ř.311. ActionCard ř.471–495 nadále zobrazuje tlačítka, pokud result chybí, a chybovou zprávu zvlášť. Opakování používá stejné draftId.

**Ověření a limity:** Staticky potvrzená větev catch i vykreslování karty; neproveden SwiftUI runtime test.

**Návazná poznámka:** Potřeba nativně ověřit timeout, odmítnutí a následný úspěch. Současné klikání během požadavku je odlišné obecné riziko, pro tento stav neoznačeno jako potvrzená nová chyba.

### A14 · opraveno · Přepnutí dne dovoluje zapisovat podle starých odpovědí

**Místo:** [ios-native/Loadwise/Screens/JournalViews.swift:345](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/JournalViews.swift#L345).

Sekce odpovědí se při day.date != date nevykreslují (ř.345–355). load ř.491–500 zachytí asked a odmítá odpověď i chybu jiného dne. Výsledek fixed/save se aplikuje jen při saved.date == date (ř.539,564).

**Ověření a limity:** Statický průchod weekStrip→load→answer/save včetně modal JournalValueSheet; bez nativního runtime.

**Návazná poznámka:** Chyba GET nemá samostatné tlačítko retry, ale starý formulář nepovolí. Dlouhodobější pořadí změn stejného dne nebylo runtime ověřeno.

### A15 · opraveno · Selhání načtení gymu může automaticky přepsat uložený trénink

**Místo:** [ios-native/Loadwise/Screens/GymLive.swift:337](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/GymLive.swift#L337).

LiveGym.load při gymDay chybě nastaví error a vrátí se před ensureHeader/markStarted/day/persist (ř.337–343). AppModel.gymDay ř.1088 odmítá status partial; DTO GymDay status nyní dekóduje. Chybové UI ř.57–70 nabízí zkusit znovu a zpět.

**Ověření a limity:** Staticky ověřen celý tok API DTO→AppModel→LiveGym včetně místa prvního persist; runtime nedostupný.

**Návazná poznámka:** Offline je záměrně umožněn poslední existující cache; bez cache chyba nevede k prázdnému autosave. Neověřeno na iOS.

### A16 · opraveno · Wahoo synchronizace vrací ručně opravený typ a kalorie

**Místo:** [src/wahoo.js:191](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/wahoo.js#L191).

Wahoo upsert používá KEEP_TYPE_SQL. Změna typu zapisuje loadwiseType a SQL zachová top-level type i loadwiseKcal/loadwiseKcalDevice. Reálná lokální posloupnost import Run/600 → edit Walk/250 → stejný Wahoo import ponechala Walk/250, marker Walk a původních 600 kcal.

**Ověření a limity:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json.

**Návazná poznámka:** Ochrana platí pro nově označené úpravy; staré uživatelské volby typu uložené ještě před zavedením markeru nelze zpětně spolehlivě rozlišit od provider dat.

### A17 · opraveno · Desetinné intenzity se v mezerách zón označí jako sprint

**Místo:** [src/workout-model.js:40](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/workout-model.js#L40).

zoneOf nyní vybírá poslední zónu podle její dolní hranice, takže nejsou mezery mezi celými procenty. Původní reálný převod vlastního workoutu dává při 75,5 % na kole endurance a při 77,5 % běhu recovery, nikoli sprint.

**Ověření a limity:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

**Návazná poznámka:** Původní desetinná mezera opravena. Ověření není fyziologická validace hranic zón.

### A19 · opraveno · Wahoo aktivita chybí ve svalové únavě a regeneraci

**Místo:** [src/muscle-fatigue.js:337](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/muscle-fatigue.js#L337).

SQL výběr nyní zahrnuje source_family=wahoo pro activity. Původní syntetická 3h aktivita s TSS 180 se načte: 1 Wahoo aktivita, TSS 180. Zachován filtr record_role!=duplicate a společné zpracování storedActivities.

**Ověření a limity:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

**Návazná poznámka:** Původní vyloučení Wahoo odstraněno. Nebyla spuštěna skutečná Wahoo synchronizace.

### A20 · opraveno · Dnes a Zdraví počítají jiný spánkový dluh

**Místo:** [src/app-health.js:86](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/app-health.js#L86).

Health i Today nyní volají stejnou weekSleepDebt nad všemi sessions. Původní scénář noc 420 min + zdřímnutí 60 min při potřebě 480 vrací na obou obrazovkách dluh 0.

**Ověření a limity:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

**Návazná poznámka:** Původní rozdíl odstraněn. Správnost samotného klinického modelu není tímto ověřena.

### A21 · opraveno · Vážení se při UTC půlnoci přiřadí špatnému dni

**Místo:** [src/app-health.js:122](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/app-health.js#L122).

Health i Today používají localDate místo UTC slice. V America/New_York se vzorek 2026-10-20T01:00:00Z správně zobrazí v 2026-10-19 s hodnotou 80 na obou obrazovkách.

**Ověření a limity:** Runtime izolovaných původních veřejných funkcí; training-metrics-repro.mjs a training-metrics-repro-results.json. Žádná soukromá AI instrukce ani externí API nebyly spuštěny.

**Návazná poznámka:** Původní přiřazení UTC dnu odstraněno. Ověření lokálního převodu není runtime telefonu.

### A24 · opraveno · Prázdné HealthKit čtení smaže importované jídlo a pití

**Místo:** [src/apple-food.js:94](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/apple-food.js#L94).

Prázdné pole jídel/pití ze zdroje apple-health se už nepovažuje za důkaz smazání. Lokálně importováno jedno jídlo a jeden nápoj, následné meals:[]/drinks:[] vrátilo saved:0,removed:0,changed:0 a oba záznamy zůstaly.

**Ověření a limity:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. Samotné chování HealthKitu na fyzickém iPhonu nebylo provedeno.

**Návazná poznámka:** Původní hromadné mazání při odepřeném/prázdném čtení je opravené. Opačný regresní důsledek pro skutečné smazání posledního záznamu je samostatně N10.

### A25 · opraveno · Jeden účet vyčerpá společný rozpočet přihlašovacích e-mailů

**Místo:** [src/email-login.js:234](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/email-login.js#L234).

Před dotazem na cílovou adresu se kontroluje per-user limit2/min,5/h,10/den a per-client5/min,20/h,30/den. claimAndSend dostává change:true a používá vlastní email-codes:change:day, nikoli email-codes:day. Ve100 požadavcích téhož účtu na100 adres uspěly2 a98 vrátilo429. Přihlašovací budget nebyl vytvořen/čerpán a normální přihlašovací kód se potom poslal.

**Ověření a limity:** Runtime původního email handleru a skutečného SQLite rate limiteru; nahrazeno jen doručení a nesouvisející importy.

**Návazná poznámka:** Původní útok jedním účtem na společný přihlašovací rozpočet se nepotvrdil. Doručení bylo pouze lokální náhradou; produkční e-mail služba nebyla použita.

### A26 · opraveno · Dvě registrace získají poslední volné místo

**Místo:** [src/tenancy.js:430](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/tenancy.js#L430).

createAccount dává ACCOUNT_LIMIT i OPEN_PLACES > UNPLACED_USERS do podmínky téhož INSERT...SELECT. E-mail, Google i Apple sign-in jej volají před vrácením nového účtu. Pro každý ze tří způsobů tři souběžná přihlášení na poslední místo vytvořila právě jeden účet, dvě adresy čekají; nepřekročil se limit účtů ani počet míst.

**Ověření a limity:** Runtime původní tenancy a Apple sign-in implementace nad SQLite, tři typy paralelní registrace; nepoužité routingové okolí izolováno.

**Návazná poznámka:** Původní závod SELECT-kapacita→INSERT byl odstraněn. Ověření používá skutečný SQLite, nikoli živou D1 či provozní kapacitu Cloudflare.

### A27 · opraveno · Google export nahradí zadaný čas jídla polednem UTC

**Místo:** [src/food-google-sync.js:22](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/food-google-sync.js#L22).

Lokální consumed_at bez offsetu nyní používá zonedTime v kontextu uživatele. Původní veřejná funkce vrátila z 07:30 v Praze 05:30Z, v New Yorku 11:30Z; po konci letního času v Praze 06:30Z. Čas se již nemění na 12:00Z.

**Ověření a limity:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json. zonedTime/withTimeZone importované přímo z aktuálního user-time.js.

**Návazná poznámka:** Neplatný/chybějící timestamp zůstává na zdokumentovaném poledním fallbacku. Historické neoznačené časové hodnoty samy neumožňují obnovit původní časové pásmo při cestování; to není nová prokázaná vada této opravy.

### A28 · opraveno · Hromadná změna jídel selže po částečném uložení

**Místo:** [src/food-entry-management.js:123](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/food-entry-management.js#L123).

Původní kopírování ids:[1,999] už nevrací chybu po úspěšném zapsání prvního jídla. Funkce vrátí status:ok, done:[nové id], skipped:[999]; route připravuje export pro úspěšné položky. Reprodukce vytvořila právě jednu kopii.

**Ověření a limity:** Lokální provedení původních veřejných funkcí s reálným SQLite; izolované pouze související importy, čas a vnější API. Skript recheck-connectors-food.mjs a uložené výsledky connectors-food-reproductions.json.

**Návazná poznámka:** Oprava řeší původní chybějící ID uprostřed dávky. Nový takeOver uvnitř move/PATCH má vlastní neatomický zápis (N11). Native MealDetailView navíc ignoruje skipped; je vhodné zobrazit částečný výsledek, zvlášť při skutečné chybě DB a nikoli už smazaném ID.

### A29 · opraveno · Workflow mikroživin selže před sestavením katalogu

**Místo:** [.github/workflows/food-micros.yml:50](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/.github/workflows/food-micros.yml#L50).

Před Run tests je nově checkout shaarkyn/aurin-prompts do src/private s PROMPTS_REPO_TOKEN (ř.50–55); testovací příkaz na ř.63 zůstává zachován. Původní chybějící krok je doplněný.

**Ověření a limity:** Statická kontrola přesného pořadí a parametrů workflow; bez vzdáleného CI běhu.

**Návazná poznámka:** V tomto prostředí nejsou soukromé prompty ani token: skutečný GitHub dry-run a vytvoření artefaktu nebyly spuštěny. Dostupnost a rozsah secretu je provozní ověření.

### A30 · opraveno · Návod slibuje nedostupné odpojení přihlášení Apple

**Místo:** [src/site-pages.js:909](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/site-pages.js#L909).

EN privacy odkazuje pouze na Apple ID settings (ř.887), CS pouze na nastavení Apple ID (ř.989). Příslib odpojení v Nastavení → Účet byl odstraněn. Aktuální funkce privacyPage/supportPage/termsPage byly přímo vyrenderované; obě jazykové privacy odpovědi prošly ověřením obsahu.

**Ověření a limity:** Runtime render skutečných funkcí site-pages.js, bez sítě; statické porovnání změny EN/CS.

**Návazná poznámka:** Skutečné odebrání přihlášení v Apple ID nebylo provedeno. Support je podle projektu pouze anglický; české jsou privacy a terms.

### A31 · opraveno · Neúspěšné smazání receptu vypadá jako úspěšné

**Místo:** [ios-native/Loadwise/Screens/AddFoodSheet.swift:273](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/ios-native/Loadwise/Screens/AddFoodSheet.swift#L273).

Odstranění položky recipes.removeAll ř.276 je uvnitř do až za úspěšným await deleteRecipe ř.275. Catch ř.277–278 pouze nastaví notice; recept zůstane v seznamu.

**Ověření a limity:** Statická kontrola akce contextMenu a success/catch větví; bez nativního runtime.

**Návazná poznámka:** Nativní viditelnost globálního notice a chování při ztracené odpovědi nebyly fyzicky ověřeny.

### A32 · opraveno · Osobní adresa majitele zůstává v historické migraci

**Místo:** [migrations/0004_backfill_completed_strength_20261002.sql:16](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/migrations/0004_backfill_completed_strength_20261002.sql#L16).

Aktuální migrace používá owner@example.com namísto osobní adresy; OWNER_EMAIL v deploy nadále pochází ze secretu. Reálný lokální SQLite úspěšně provedl staging/schema.sql a upravenou migraci.

**Ověření a limity:** Kontrola aktuálního SQL a skutečné SQLite 3.53.1; platform-bootstrap.json.

**Návazná poznámka:** Starší Git historie a metadata commitů nebyla přepsána. Původní doporučení i akceptace mířily na aktuální publikovaný strom, nikoli na odstranění historie.

### A33 · opraveno · Záznam užité pilulky v minulém dni se po uložení nezobrazí

**Místo:** [src/cycle-model.js:79](https://github.com/aurinhealth/health-api/blob/775c79b1432d743a1d503f803214dda348f555ed/src/cycle-model.js#L79).

Původní nativní scénář je opraven: normalizeCycleDay nyní přijímá vlastní řetězec taken (cycle-model.js:79). Reálné save(true) → list → calendar vrací taken; HH:MM i null fungují; opakovaná normalizace je idempotentní. Avšak saveCycleDay({pill:"taken"}) nadále uloží null, protože store přijímá pouze boolean true nebo čas.

**Ověření a limity:** recheck-platform-cycle.mjs, původní aktuální model/store a skutečné SQLite; platform-cycle-reproduction.json → A33. Nativní caller ověřen staticky na CycleViews.swift:449–450.

**Návazná poznámka:** Původní nativní chyba se v reprodukci neopakuje. Doplňková poznámka ke kontraktu: přímý API vstup pill:"taken" store nepřijímá, zatímco true a HH:MM ano. Aktuální nativní klient takový řetězec neposílá, proto tato poznámka není započítaná jako pokračující chyba ani nový nález.

## Spuštěné kontroly a omezení

| Kontrola | Výsledek a význam |
|---|---|
| Lint | Prošel nad novějším commitem; konfigurace vynucuje hlavně no-undef, nejde o úplnou statickou analýzu. |
| Veřejný JS a skripty | Kontrola syntaxe veřejných modulů a skriptů; podrobný výstup syntax-current.json. |
| Standardní npm test/check | Chybí soukromé src/private; standardní preflight a check proto nelze prohlásit za úspěšné. Soukromé soubory nebyly nahrazeny falešnými prompty. |
| Přímá plná sada | 241 testových souborů: 26 úspěšných, 215 neúspěšných; dominantní příčina je chybějící private/lang.js při importu. Žádný ERR_ASSERTION v tomto běhu. Tento počet není počet potvrzených chyb produktu. Výstup tests-current.tap. |
| Cílené reprodukce | Šest hlavních skriptů znovu spuštěno nad 775c79b; výsledky a návratové kódy ve final-reproduction-verification.json. Zahrnují 308 hraničních kombinací běžeckého capu, skutečné SQLite a ověření podpisu session. |
| Nezávislá kontrola | Cyklové chyby potvrzené i přes původní HTTP routy a scopedDb bez umělé serializace; nativní a konektorové nálezy mají samostatné peer-review podklady. |
| Novější delta a OIDC | 4 skutečné OIDC testy prošly; izolovaná původní GET/HEAD větev a veřejné page funkce prošly pro 6 cest × 2 metody, JSON-LD a Twitter metadata. Pět shellových bloků releasu prošlo bash -n. |
| SQL bootstrap | Lokální bootstrap a upravená migrace prošly; výstup platform-bootstrap.json. Nejde o migraci produkční D1. |
| Web v Chromiu | Původní HTML funkce a assety, 320/390/1280 px, přehled/soukromí/podmínky/podpora: bez runtime JS chyby či vodorovného přetékání. Formulář používá lokální odpověď, nikoli skutečné přidání do waitlistu. Worker HEAD je kontrolován zvlášť v deltě. |
| Nativní aplikace a poskytovatelé | Xcode/iOS runtime, fyzická oprávnění HealthKit, skutečné AI odpovědi a externí sync/doručení nebyly k dispozici. Neproběhl nákup ani obnova předplatného. |

Původních 15 samostatných webových testů prošlo nad 74a459d. Novější testový soubor navíc importuje celý Worker a bez soukromých modulů se nespustí; starší úspěch není vydáván za úspěch novější standardní sady. Aktuální web byl znovu vykreslen samostatným lokálním browserovým průchodem.

Další provozní témata z první revize nejsou automaticky uzavřena: přesná verze soukromých promptů při testu/deploy, obnova core/shards/FOODS ze záloh, skutečné nastavení oprávnění a branch protection, fyzický telefon, přístupnost a úplný StoreKit cyklus. Tato revize nepřidává neověřené provozní domněnky k počtu potvrzených vad.

## Doporučené pořadí dokončení

1. **Oddělení účtů:** A02, A10, A11, N01, N02. Společná generace účtu+serveru musí chránit načítání, čekající zápisy, importy i exporty po každém await. Vyčistit i další lokální stav, včetně minimalizovaného tréninku.
2. **Spolehlivé zápisy:** A03, N03, N11, N13. Potvrzovat až uložený nebo trvale čekající zápis, zachovat poslední snapshot a atomicky provádět přesuny a částečné změny.
3. **Přihlášení a synchronizace:** A05, A22, A23, N09, N10. Vázat session na epochu ticketu, oddělit polling od retry rozpočtu a rozlišovat neověřené prázdno od skutečného smazání.
4. **Historie, plán a rozhraní:** A08, A18, N04, N07, N08, N12. Ověřit párování plán/dokončení, upgrade starých plánů, zrušení starých AI návrhů a konečné časové limity.
5. **Správa testerů:** N05, N06. Atomická kapacita a dostupnost celé čekací listiny.
6. **Před vydáním:** plná sada se skutečnými soukromými moduly, nativní souběhové scénáře na telefonu, stagingové import/edit/resync/delete/export a obnova ze záloh.

## Soubory a podklady

- STAV-OPRAV.csv: všech 33 původních bodů a zdůvodnění aktuálního stavu.
- ZBYVAJICI-OPRAVY.csv: pouze nedokončené a nové úkoly s doporučením a kritériem dokončení.
- nalezy-sloucene.json: strukturovaný report s mapováním původních pracovních identifikátorů na N01–N13.
- Šest dílčích reportů, jejich reprodukce, výsledky, aktuální kontroly a peer-review jsou v kompletním ZIPu.

**Aplikační zdroje ani produkční data nebyly touto revizí změněny.** GitHubová větev pro předání obsahuje dokumenty auditu; neslouží k nasazení změn aplikace.
