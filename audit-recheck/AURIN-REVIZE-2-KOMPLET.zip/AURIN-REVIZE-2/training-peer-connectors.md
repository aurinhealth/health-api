# Nezávislá kontrola konektorových nálezů

Revidovaný commit: `74a459d0f99fa6503e4e37035777915921427a06`. Podklad: `recheck-connectors-food.mjs`, `connectors-food-reproductions.json/log` a přímé čtení implementací i volajících rout/jobů. Tato kontrola nepoužila síť, skutečné providery ani iOS runtime.

## A22 — zbývající LRO stav: potvrzuji, P2, částečně opraveno

- `src/sync-destinations.js:323` navyšuje attempts při každém `setStatus`, tedy i při stále rozpracované operaci (`:347–350`).
- `retrySyncSends` (`:411–420`) vybírá i pending, ale jen `attempts < 3`. Po úvodním pokusu a dvou cron kolech se pending dál nevybírá. Totéž nastane při dočasné nedostupnosti GET operace: `googleOperation` chyby čtení převede na žádný výsledek, nikoli na zvláštní stav nezávislý na počtu selhání zápisu.
- Volající job `src/entrypoint.js:267` nemá další opravný mechanismus. `retrySend` sice limit obejde, ale nativní `SyncViews.swift:506–512` pro pending ukazuje pouze „odešle se“; opakovací tlačítko je jen pro error. `SyncModels.swift:185` pending zachovává.
- Reprodukce je s těmito volajícími konzistentní. Není vyvrácena možností ručně zavolat API.

**Přesný dopad:** automatické sledování operace a místní potvrzení se zastaví. Pokud Google operaci mezitím dokončí, data mohou v Google být, ale Aurin dál hlásí pending. Pokud operace skončí chybou, Aurin ji nezjistí ani automaticky nezopakuje. Netvrdit obecně, že žádná taková aktivita na Google nikdy nevznikne.

Původní falešné dokončení pro explicitní `{done:false}` je opravené. Nepočítat tento zbytek jako další nový ID. Náprava: oddělit čekání/polling od neúspěšného zápisu, stanovit expiraci a zobrazit skutečný konečný stav i dosažitelnou obnovu.

## A23 — poslední smazaná Intervals aktivita: potvrzuji, P2, částečně opraveno

- `src/index.js:1152–1178` přijímá úspěšné pole aktivit včetně `[]` a standardně má import povolený.
- Rekonciliace `:1227` se spouští výhradně při `activities.length > 0`. Úplný prázdný výsledek proto nemůže odstranit poslední uloženou aktivitu v období.
- Konkrétně pojmenované smazání webhookem je naopak opravené (`intervals-webhook.js:51–52`, `index.js:1153–1154`, předání `entrypoint.js:232–236`). To nesmí report zobecnit jako nefunkční všechny deletion webhooky.
- Běžná cesta bez pojmenovaného webhooku existuje: osobní API klíč se opakovaně synchronizuje (`entrypoint.js:279–282`); osobní klíče nejsou OAuth webhookové spojení (`intervals-reads.js:1–10`). Stejný zbytek zasáhne i ztracený webhook. Následné `matchActivities` duplicity páruje, ale tento chybějící Intervals řádek nemaže.

**Nutná podmínka scénáře:** skutečně úplná úspěšná odpověď bez aktivit v daném okně, nikoli chyba, neúplná stránka nebo odvolané oprávnění. Oprava nesmí slepě mazat historii po libovolném prázdném čtení; lze potvrdit autoritativnost výpisu nebo ověřit zaniklé kandidáty jednotlivě. Jde o zbytek A23, nikoli nové ID.

## A28 versus nová takeOver cesta — původní bod uzavřít, nový počítat samostatně

- Původní případ copy `[platné ID, chybějící ID]` je opraven: `bulkFoodEntries` (`food-entry-management.js:123–137`) vrací done/skipped a neodpoví chybou po úspěšné položce.
- Nová chyba je uvnitř jedné operace převzetí importovaného jídla: `takeOver` (`:61–63`) nejdřív samostatně commitne INSERT a až potom volá `hideAppleFood`.
- `hideAppleFood` (`apple-food.js:32–42`) má vlastní další CREATE/SELECT/batch. Jeho batch nemůže vrátit zpět předchozí INSERT. Náhrada DB.batch v reprodukci simuluje skutečný bod selhání další databázové operace, nikoli nedosažitelnou výjimku po hypotetickém vnějším commitu.
- Volající `routes-food.js:37–45` nemá transakci a při chybě jednotlivé PATCH odpoví 400. Hromadná cesta `:49–55` také nemá vnější transakci. U jediného vybraného jídla je done prázdné a bulk chybu znovu vyhodí; s více položkami neúspěšné ID skončí ve skipped, ačkoli již vznikla kopie.

**Verdikt:** potvrzená nová P2. Původní A28 označit fixed, tuto novou cestu uvést jednou pod novým ID, společnou pro PATCH i bulk move. Důsledek je ponechaný originál i nová kopie po chybě a další duplicitní kopie při retry. Doporučené řešení: jednu atomickou dávku pro vložení náhrady, ukrytí external ID a odstranění originálu nebo jinou skutečně idempotentní operaci.

## Ranní připravenost pro WHOOP / Ultrahuman — potvrzuji, P2, oddělený nový nález

- A09 se týkal push kouče. Ten je nyní samostatný job `coach-push` s `push:true` pro zařízení všech providerů (`entrypoint.js:263`, výběr `:300`, `:333–335`): původní A09 je opravený.
- Ranní readiness je jiný typ notifikace s vlastní volbou (`morningPush`, `:607–612`) a jiným push logem. Jeho jediná spuštění jsou Google/Intervals job `sync` (`:253–258`) a přijetí Apple Health noci (`:2105`).
- WHOOP a Ultrahuman joby (`:269`, `:274`) importují data a obnovují cache; `morningPush` nevolají. `coachPush` je také nevolá a může být samostatně vypnutý (`:631`). WHOOP/UH sleep a wellness jsou přitom podporované vstupy zdravotních výpočtů (`index.js:2611`, `todayReadiness` `entrypoint.js:572–585`).

**Přesný scénář:** účet s push tokenem, potřebnými zdravotními souhlasy a nočními daty jen z WHOOP či UH, ranní readiness zapnutá, žádné Google/Intervals spojení ani Apple Health upload. Ranní notifikace se vůbec nevyhodnotí. Zapnutí/vypnutí kouče ji nenahrazuje. Nejde o další nezávislý případ A09; lze jej uvést jako nový nález o jiném typu notifikace, bez opakování původního tvrzení o kouči.

Reprodukce výběru jobů neprokazuje skutečné doručení APNs ani produkční konfiguraci. Přesný text výsledku má být „job nespouští ranní notifikaci“, nikoli domněnka o chybě Apple push služby.

## Shrnutí pro slučování

- A22 partial, A23 partial, A28 fixed.
- Dva nové samostatné P2: neatomické převzetí importovaného jídla a chybějící spuštění ranní readiness pro WHOOP/UH.
- Nezdvojovat LRO zbytek, Intervals prázdnou odpověď ani jednotlivé PATCH/bulk varianty stejného takeOver problému.
- Nezjistil jsem volající kontrolu, transakci ani plánovanou opravnou úlohu, která by uvedené zbývající případy vyvracela.
