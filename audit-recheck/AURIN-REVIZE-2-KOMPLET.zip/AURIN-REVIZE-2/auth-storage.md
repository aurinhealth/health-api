# Druhá revize — autentizace, spolehlivé zápisy a waitlist

Commit: `74a459d0f99fa6503e4e37035777915921427a06`; původní audit: `02d575e570a179a5c156bcc9708877a2c18f3de8`.

**Původní nálezy:3 opravené (A04,A25,A26),2 částečně opravené (A03,A05). Nové:2×P2.**

Lokální reprodukce:10 záznamů, skript dokončen s návratovým kódem0. A05 závod i obě waitlist vady byly reprodukovány; klientská část A03 je statická.

## A03 · partial · Rozpracovaný idempotentní zápis už není falešně potvrzen, klient jej ale po pěti odpovědích pending zahodí

Místo: `src/idempotency.js:60`.

**Důkaz opravy / současný stav:** Server nyní vrací 503 + Retry-After:5 místo duplicate:true/200. Lokální původní handler se skutečným SQLite vrátil pětkrát 503; první zápis poté selhal 500, další pokus uložil právě jeden záznam a úspěšný replay už handler nespustil. APIClient.swift:650–660 však pending nerozlišuje od jiné 5xx; AppModel.swift:878–886 pro každou odpověď přičte failures a při pěti položku odstraní.

**Co zbývá:** Při stále probíhajícím prvním zápisu může pět opakovaných refreshů/odeslání během dvouminutového pending okna vyčerpat limit. Pokud původní požadavek následně selže, už není co odeslat. Samotné iOS pořadí nebylo spuštěno na telefonu; backend pět pending odpovědí skutečně poskytl.

**Doporučení:** Zavést explicitní pending stav rozpoznaný klientem, respektovat Retry-After a takové odpovědi nezapočítávat jako skutečná selhání vedoucí ke smazání outboxu.

**Hotovo až když:** Zadržet první zápis, odpovědět nejméně pětkrát pending, první pokus ukončit 500. Položka zůstane a další retry ji uloží právě jednou. Po úspěchu další replay zápis neduplikuje.

**Ověření:** Backend runtime s původním veřejným modulem a SQLite; klient staticky. Reprodukce recheck-auth-storage.mjs, výsledek auth-storage-reproductions.json.

## A04 · fixed · OAuth callback je připnutý k účtu, který propojení zahájil

Místo: `src/google-oauth.js:25`.

**Důkaz opravy / současný stav:** oauthStateValue v connect-return.js:13 přidává USER_ID do state cookie a startedBy:18 ho porovnává s aktuálním účtem. Kontrola proběhne před výměnou kódu a uložením credentials. Stejná kontrola je v Intervals:44, Wahoo:96, WHOOP:81 a Ultrahuman:87. Původní Google callback při startu UID11 a návratu UID22 vrátil 403, bez volání token endpointu a bez zápisu. Návrat UID11 uspěl a zapsal jen UID11.

**Co zbývá:** Původní scénář změny platné browser session A→B byl odstraněn. Ostatní provideři byli ověřeni staticky; reálná autorizace s externími službami nebyla provedena.

**Doporučení:** Původní oprava je implementovaná; zachovat regresi pro každý podporovaný provider a neshodnou identitu.

**Hotovo až když:** Start A→callback B nezapisuje žádné credentials a nevolá token exchange; start A→callback A nadále funguje.

**Ověření:** Google runtime ve VM s původním callbackem/helperem a izolovaným token/storage okolím; pět providerů zdrojově ověřeno.

## A05 · partial · Jednorázový Google handoff je opravený, souběžné odvolání session ale stále může být překročeno

Místo: `src/google-login.js:143`.

**Důkaz opravy / současný stav:** Token nově obsahuje se a jednorázové id. Opakované použití vrací 401 a nepoužitý token po předchozím zvýšení epochy také 401. Mezi kontrolou epochy na řádku143 a vydáním cookie je však await useHandoff na144; userSessionCookie na146 znovu čte aktuální epochu přes dashboard-auth.js:152.

**Co zbývá:** Runtime reprodukce pozastavila skutečnou claim batch po kontrole epochy0, zvýšila users.session_epoch na1 a dokončila claim. Odpověď byla200 a skutečně podepsaná cookie nesla epochu1; sessionMatchesUser ji vůči aktuální epoše1 přijal. Jde o úzký souběh s odhlášením všech zařízení, nikoli libovolné opakování již použitého ticketu nebo nový způsob jeho získání.

**Doporučení:** Cookie pro handoff podepsat epochou uloženou v ověřeném ticketu, nikoli nově načtenou epochou účtu. Při souběžné revokaci pak zůstane neplatná; samotná další kontrola před následným opětovným čtením epochy problém neřeší.

**Hotovo až když:** Zadržet claim mezi ověřením tokenu a mintem session, zvýšit epochu a dokončit výměnu. Nesmí vzniknout session platná pod novou epochou; běžný nový token po revokaci funguje jednou.

**Ověření:** Runtime: původní google-login.js a dashboard-auth.js, skutečné SQLite, WebCrypto HMAC a ověření cookie; pouze nepotřebné tenancy/OIDC importy nahrazeny lokálním okolím.

## A25 · fixed · Změna e-mailu má vlastní limity a nečerpá rozpočet přihlašování

Místo: `src/email-login.js:234`.

**Důkaz opravy / současný stav:** Před dotazem na cílovou adresu se kontroluje per-user limit2/min,5/h,10/den a per-client5/min,20/h,30/den. claimAndSend dostává change:true a používá vlastní email-codes:change:day, nikoli email-codes:day. Ve100 požadavcích téhož účtu na100 adres uspěly2 a98 vrátilo429. Přihlašovací budget nebyl vytvořen/čerpán a normální přihlašovací kód se potom poslal.

**Co zbývá:** Původní útok jedním účtem na společný přihlašovací rozpočet se nepotvrdil. Doručení bylo pouze lokální náhradou; produkční e-mail služba nebyla použita.

**Doporučení:** Implementovanou oddělenou kapacitu a oba limity zachovat; v regresi nadále měnit cílové adresy.

**Hotovo až když:** Rotace cílových adres neobchází limit účtu ani sítě a neovlivní email-codes:day. Běžný login zůstane dostupný.

**Ověření:** Runtime původního email handleru a skutečného SQLite rate limiteru; nahrazeno jen doručení a nesouvisející importy.

## A26 · fixed · Poslední místo je při vytvoření účtu ověřeno atomicky

Místo: `src/tenancy.js:430`.

**Důkaz opravy / současný stav:** createAccount dává ACCOUNT_LIMIT i OPEN_PLACES > UNPLACED_USERS do podmínky téhož INSERT...SELECT. E-mail, Google i Apple sign-in jej volají před vrácením nového účtu. Pro každý ze tří způsobů tři souběžná přihlášení na poslední místo vytvořila právě jeden účet, dvě adresy čekají; nepřekročil se limit účtů ani počet míst.

**Co zbývá:** Původní závod SELECT-kapacita→INSERT byl odstraněn. Ověření používá skutečný SQLite, nikoli živou D1 či provozní kapacitu Cloudflare.

**Doporučení:** Atomickou podmínku zachovat ve všech budoucích cestách tvorby účtu; počet míst ověřovat i při změnách routingu.

**Hotovo až když:** Současné e-mailové/Google/Apple registrace na poslední místo nikdy nevytvoří dva účty vyžadující jedno místo; pozdější adresy skončí na čekací listině.

**Ověření:** Runtime původní tenancy a Apple sign-in implementace nad SQLite, tři typy paralelní registrace; nepoužité routingové okolí izolováno.

## NEW-WAITLIST-CAPACITY · P2 · Dvě souběžná schválení překročí vlastní limit testerů

Místo: `src/testflight-waitlist.js:89`.

**Příčina:** Počet členů TestFlight skupiny se načte a porovná s TESTER_LIMIT=20 před vzdáleným přidáním, bez rezervace či serializace schvalování. Omezení tlačítek v jednom WaitlistView chrání jen jednu otevřenou obrazovku, nikoli dva požadavky majitele z různých zařízení.

**Dopad:** Při19 testerech dvě souběžná schválení obě vidí19 a obě pozvou dalšího; skupina skončí s21 členy a obě lokální položky mají invited. Funkce tak nedodrží vlastní kapacitu pilotu. Není to anonymně přístupná administrátorská akce.

**Oprava:** Serializovat schválení pro zvolenou skupinu napříč požadavky/isolaty a rezervovat poslední místo před vzdáleným zápisem; při nejistém výsledku jej nejprve smířit s App Store Connect, nikoli slepě opakovat.

**Hotovo až když:** Dvě souběžná schválení při19/20 přijmou nejvýše jednoho nového testera. Opakovaný požadavek na tutéž adresu je bezpečný a rezervace se po skutečném odmítnutí uvolní.

**Ověření:** Runtime původních list/decide/invite funkcí a SQLite; generovaný jednorázový testovací ES256 klíč a deterministické lokální Apple odpovědi. Oba GET počtu byly řízeně dokončeny před oběma přidáními:19→21. Skutečná Apple API nebyla volána.

## NEW-WAITLIST-TRUNCATION · P2 · Starší čekající zájemci zmizí ze správy po překročení300 položek

Místo: `src/testflight-waitlist.js:54`.

**Příčina:** Admin API vrací pouze300 nejnovějších řádků napříč pending i invited a teprve poté je rozdělí. Nemá cursor, total ani informaci o zkrácení. Waitlist model a obrazovka nepodporují další stránku ani hledání.

**Dopad:** Se301 čekajícími zůstává nejstarší zájemce v DB, ale není vidět ve správě a nelze jej běžně vybrat ke schválení či smazání. Další příchozí vytlačují předchozí čekající; počet pending v nastavení je zároveň jen velikost vráceného výřezu. Data nejsou fyzicky smazaná a uvolnění výřezu může položku znovu odkrýt.

**Oprava:** Přidat stránkování a celkové počty; pending a invited načítat odděleně, ideálně s pořadím podle stáří čekání. UI musí umět dojít až k poslední položce.

**Hotovo až když:** Při více než300 smíšených i čistě pending položkách lze v UI najít, schválit i smazat nejstaršího čekajícího a badge ukazuje skutečný počet.

**Ověření:** Runtime původní listWaitlist se skutečným SQLite:301 pending uložených,300 vrácených, ID1 chybí a nejstarší vrácené ID2. Absence stránkování potvrzena v APIClient+Waitlist.swift:15–27 a WaitlistView.swift:82–87.

## Ověření a omezení

- Nebyly provedeny produkční ani externí OAuth/e-mail/App Store Connect operace.
- Nebyl spuštěn iOS klient ani jeho UI testy; klientské důkazy jsou statické.
- Soukromé AI prompty nebyly přidány ani nahrazeny falešnými soubory. VM izoluje pouze nesouvisející importy a síť, relevantní veřejné funkce/SQL/HMAC jsou původní.
- SQLite reprodukce nejsou zátěžový či distribuovaný test živé Cloudflare D1.
- Nové nálezy popisují aktuální commit, nikoli doložené produkční incidenty.

Spuštěno: `node --experimental-vm-modules /workspace/aurin-reaudit-2026-10-20/recheck-auth-storage.mjs`. Výsledky jsou v `auth-storage-reproductions.json`; původní implementace nebyla editovaná.

## Pokrytí

- `src/idempotency.js` — detail+runtime: pending, failed write, stored replay, stale/cleanup source.
- `src/google-login.js` — detail+runtime: handoff issuance, exchange, epoch and one-time claims.
- `src/dashboard-auth.js` — detail+runtime: epoch binding, actual cookie HMAC verification, revocation and sliding sessions.
- `src/google-oauth.js` — detail+runtime: state, bound UID, token exchange/storage ordering.
- `src/connect-return.js` — detail+runtime: state cookie UID helpers.
- `src/email-login.js` — detail+runtime: change-email request limits, code claims/budgets and login send.
- `src/ip-rate-limit.js` — detail+runtime: SQLite atomic limits used by email change.
- `src/tenancy.js` — detail+runtime: account creation, sign-in paths, capacity SQL, account identity and epoch.
- `src/apple-login.js` — flow+runtime: verified identity sign-in path and atomic createAccount use.
- `src/intervals-oauth.js` — flow: callback identity binding and saved-credential ordering.
- `src/wahoo.js` — flow: OAuth callback identity binding.
- `src/whoop.js` — flow: OAuth callback identity binding.
- `src/ultrahuman.js` — flow: OAuth callback identity binding.
- `src/testflight-waitlist.js` — detail+runtime: public signup, owner list/decision, ASC selection, signing and capacity.
- `src/routes-admin.js` — flow: waitlist owner authorization and Origin/method handling.
- `src/entrypoint.js` — flow: public/admin routing, bound environment and OAuth callback follow-up.
- `ios-native/Loadwise/Data/APIClient.swift` — flow: sendQueued pending/error mapping.
- `ios-native/Loadwise/App/AppModel.swift` — flow: outbox failure cap and pending removal.
- `ios-native/Loadwise/Data/APIClient+Waitlist.swift` — flow: waitlist model, list and decision API.
- `ios-native/Loadwise/Screens/WaitlistView.swift` — detail: single-screen approve guard, displayed list and absent pagination.
- `tests/account-capacity.test.mjs` — overview: reviewed regression assertions; not represented as executed without private prompts.
- `tests/email-change.test.mjs` — overview: reviewed regression assertions; not represented as executed without private prompts.
- `tests/google-login.test.mjs` — overview: reviewed regression assertions; not represented as executed without private prompts.
- `tests/google-scopes.test.mjs` — overview: reviewed regression assertions; not represented as executed without private prompts.
- `tests/idempotency.test.mjs` — overview: reviewed regression assertions; not represented as executed without private prompts.
- `tests/testflight-waitlist.test.mjs` — overview: reviewed regression assertions; not represented as executed without private prompts.
