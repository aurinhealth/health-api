// Read-only recheck of original public functions. No private prompts, no network.
import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import * as recovery from '/workspace/health-api-recheck/src/recovery-model.js';
import { localDate, localDateTime, withTimeZone, timeZone } from '/workspace/health-api-recheck/src/user-time.js';
import { sessionOf, sameSession } from '/workspace/health-api-recheck/src/activity-match.js';
import { createD1 } from '/workspace/health-api-recheck/tests/helpers/d1.mjs';
const root='/workspace/health-api-recheck/src/';
const read=name=>readFileSync(root+name,'utf8');
const clean=s=>s.replace(/^import .*;\n/gm,'').replace(/^export \{[^}]*\};?\s*$/gm,'').replace(/\bexport /g,'');
const compile=(s,deps,names)=>new Function(...Object.keys(deps),clean(s)+'\nreturn {'+names.join(',')+'};')(...Object.values(deps));
const between=(s,a,b)=>s.slice(s.indexOf(a),s.indexOf(b));
const L=(_cs,en)=>en;
const results=[]; const record=(id,data)=>{ results.push({id,...data}); console.log(JSON.stringify({id,...data})); };
const availability=compile(read('training-availability.js'),{L},['normalizeAvailability','availabilityOn','parseTimeWindow']);
const planner=compile(read('week-planner.js'),{...availability,L,bilingual:(_cs,en)=>en,...recovery},['sanitizeWeekPlan','planWeekRoles','weekTargets','weekLoadsBefore','weeklyRunCap','capRunVolume','committedRunMinutes','isRunActivity','hrvWeekTrendDown','hrvSourceRows']);
const adaptive=compile(read('adaptive-week.js'),{...availability,...planner,L,timeZone},['weekProposal']);
const start='2026-10-19',today=start;
const dates=Array.from({length:7},(_,i)=>new Date(Date.parse(start+'T12:00:00Z')+i*86400000).toISOString().slice(0,10));
const makeWeek=(planned=[],completed=[])=>({days:dates.map((date,i)=>({date,daily:{training:{planned:i?[]:planned,completed:i?[]:completed}}}))});
const prefs=planner.sanitizeWeekPlan({days:[['run'],['run'],[],['run'],[],['run'],[]],availability:Array(7).fill({minutes:90})});
for(const [name,week] of [['four days',makeWeek()],['60 completed',makeWeek([],[{type:'Run',durationHours:1}])],['60 planned',makeWeek([{type:'Run',durationHours:1}])]]){
 const r=adaptive.weekProposal({prefs,start,today,week,history:[],state:{status:'active'}});
 const proposed=r.items.filter(x=>x.sport==='run').reduce((n,x)=>n+x.minutes,0);
 const committed=name==='four days'?0:60;
 assert.ok(committed+proposed<=60); if(committed===60) assert.equal(proposed,0);
 record(name==='60 planned'?'A08-basic':'A07',{name,proposed,committed,runCap:r.targets.runCap});
}
// Boundary/property check: resulting runs never exceed room and are >=20 min.
let checks=0;
for(const cap of [0,19,20,21,39,40,59,60,61,120,179])for(const committed of [0,10,19,20,45,60,120])for(const minutes of [[20],[30,30],[20,35,50,95],[20,20,20,20]]){
 const out=planner.capRunVolume({status:'ok',items:minutes.map(m=>({sport:'run',minutes:m}))},{cap},committed);
 assert.ok(out.items.reduce((n,x)=>n+x.minutes,0)<=Math.max(0,cap-committed));
 assert.ok(out.items.every(x=>x.minutes>=20)); checks++;
}
record('A07-boundaries',{checks,passed:true});
const counted=planner.committedRunMinutes(today,today,30,30);
const after=planner.capRunVolume({status:'ok',items:[{sport:'run',minutes:30}]},{cap:60},counted);
assert.equal(counted,30); assert.equal(after.items[0].minutes,30);
record('A08-remaining',{scenario:'done 30 min morning run + distinct planned 30 min evening run',counted,actualCommitted:60,proposed:30,actualWeekAfterProposal:90,cap:60});
const distinctWeek=adaptive.weekProposal({prefs,start,today,history:[],state:{status:'active'},week:makeWeek([{id:'evening',type:'Run',durationHours:.5,startTime:today+'T18:00:00'}],[{id:'morning',type:'Run',durationHours:.5,startTime:today+'T07:00:00'}])});
const distinctProposed=distinctWeek.items.filter(x=>x.sport==='run').reduce((n,x)=>n+x.minutes,0);
assert.equal(distinctWeek.targets.runCap.committed,30);assert.equal(distinctProposed,30);
record('A08-weekProposal',{actualCommitted:60,counted:distinctWeek.targets.runCap.committed,proposed:distinctProposed,actualWeekAfterProposal:60+distinctProposed,cap:distinctWeek.targets.runCap.cap});

const model=compile(read('workout-model.js'),{L},['buildWorkout','zoneOf','zonesFor','flattenSteps','totalMinutes','zoneMinutes','renderForEnvironment','difficultyFromStructure']);
const endurance=compile(read('endurance-templates.js'),{L,...model},['ownLibraryWorkout','cleanEnduranceTemplate','enduranceStructure','enduranceSystem']);
for(const [sport,low,high,expected] of [['ride',70,81,'endurance'],['run',73,82,'recovery']]){
 const template=endurance.cleanEnduranceTemplate({sport,name:'Own easy workout',blocks:[{repeats:1,steps:[{seconds:1800,low,high}]}]});
 const structure=endurance.enduranceStructure(template);
 const result=endurance.ownLibraryWorkout({id:'abcdefghij',sport,name:template.name,structure_json:JSON.stringify(structure)});
 assert.equal(result.primary_system,expected);
 record('A17',{sport,average:structure[0].power,system:result.primary_system});
}

const sleepSettings=()=>({goal:null});
const readiness=compile(read('readiness.js'),{...recovery,sleepSettings,markCyclePhases:rows=>rows},['readinessFor','readinessRows','primaryNights','sleepIndexFor']);
const clockOf=iso=>iso?localDateTime(iso).slice(11,16):null;
const minutesOf=iso=>{const c=clockOf(iso);return c?Number(c.slice(0,2))*60+Number(c.slice(3,5)):null;};
const dayStrain=(rows,date)=>{const load=recovery.heartRateLoad(rows.find(r=>r.id===date)?.hrZoneMinutes);return load==null?null:recovery.strainScore(load);};
const tonightChoice=(_settings,_date,need)=>({need,wake:{},chosen:null,wakeOnce:false});
const common={...recovery,...readiness,localDate,localDateTime,sleepSettings,tonightChoice,clockOf,minutesOf,dayStrain};
const {buildHealth}=compile(read('app-health.js'),common,['buildHealth']);
const {clockOf:_c,minutesOf:_m,dayStrain:_d,...todayCommon}=common;
const {buildToday}=compile(read('app-today.js'),{...todayCommon,L,environmentFor:()=>({}),withHeartRateLoad:t=>t,daySessions:()=>({sessions:[]}),deviceEnergyExtra:()=>0,recoveryToday:()=>null,cycleState:()=>null,askPeriodToday:()=>false,cycleTrainingCaution:()=>null,isHardSession:()=>false},['buildToday']);
const sessions=[{date:today,startTime:'2026-10-18T23:00:00Z',endTime:'2026-10-19T06:00:00Z',durationMin:420,timeInBedMin:420,stages:{},nap:false},{date:today,startTime:'2026-10-19T13:00:00Z',endTime:'2026-10-19T14:00:00Z',durationMin:60,timeInBedMin:60,stages:{},nap:true}];
const h=buildHealth({date:today,hour:16,sleep:{sessions},profile:{age:35}}),t=buildToday({date:today,hour:16,sleep:{sessions},profile:{age:35}});
assert.equal(h.sleep.debt.minutes,0); assert.equal(t.strain.target.debt,0);
record('A20',{healthDebt:h.sleep.debt.minutes,todayDebt:t.strain.target.debt});
withTimeZone('America/New_York',()=>{
 const at='2026-10-20T01:00:00Z',weight={records:[{sample_time:at,value_numeric:80}]};
 const h=buildHealth({date:today,weight}),t=buildToday({date:today,weight});
 assert.equal(h.weight.latest,80);assert.equal(h.weight.date,today);assert.equal(t.weight.latest,80);
 record('A21',{at,localDate:localDate(at),healthDate:h.weight.date,healthLatest:h.weight.latest,todayLatest:t.weight.latest});
});
const db=createD1();db.userId=7;
db.sqlite.exec(`CREATE TABLE strength_sets(user_id INTEGER,workout_date TEXT,exercise TEXT,rpe REAL,updated_at TEXT,completed INTEGER,type TEXT);CREATE TABLE health_datapoints(user_id INTEGER,source_family TEXT,data_type TEXT,start_time TEXT,end_time TEXT,payload_json TEXT,record_role TEXT);`);
const payload={type:'Ride',name:'Synthetic long ride',start_date:'2026-10-19T08:00:00Z',start_date_local:'2026-10-19T10:00:00',moving_time:10800,icu_training_load:180};
db.sqlite.prepare('INSERT INTO health_datapoints VALUES(?,?,?,?,?,?,?)').run(7,'wahoo','activity',payload.start_date_local,'2026-10-19T13:00:00',JSON.stringify(payload),'primary');
const stored=compile(read('fitness-insights.js').slice(read('fitness-insights.js').indexOf('export function storedActivities(')),{n:(v,f=0)=>Number.isFinite(Number(v))?Number(v):f,iso:v=>String(v||'').slice(0,10),localDate,sameSession},['storedActivities']);
const {loadTrainingDoses}=compile(read('muscle-fatigue.js').slice(read('muscle-fatigue.js').indexOf('export async function loadTrainingDoses(')),{localDate,shiftDate:(d,n)=>new Date(Date.parse(d+'T12:00:00Z')+n*86400000).toISOString().slice(0,10),WINDOW_DAYS:7,HISTORY_DAYS:28,dateOnly:v=>String(v||'').slice(0,10),...stored,sessionOf,activityKind:a=>/ride/i.test(a.type)?'ride':null},['loadTrainingDoses']);
const dose=await loadTrainingDoses(db,{now:Date.parse('2026-10-19T15:00:00Z')});assert.equal(dose.activities.length,1);
record('A19',{wahooActivities:dose.activities.length,tss:dose.activities[0].tss});

const library=read('workout-library.js'),templates=read('workout-templates.js');
const getSource=between(library,'export async function getWorkout(','export async function getCapabilities(');
const linkSource=between(library,'export async function scheduledLink(','export async function markScheduleCompleted(');
const getLib=compile(getSource+'\n'+linkSource,{ownLibraryWorkout:endurance.ownLibraryWorkout,builtInById:()=>new Map(),ensureTrainingTables:async()=>{}},['getWorkout','scheduledLink']);
const snap=createD1();snap.userId=3;
snap.sqlite.exec(`CREATE TABLE saved_workouts(user_id INTEGER,id TEXT,sport TEXT,name TEXT,structure_json TEXT);CREATE TABLE planned_own_workouts(user_id INTEGER,id TEXT,saved_id TEXT,sport TEXT,name TEXT,structure_json TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,id));CREATE TABLE workout_schedule_links(id INTEGER PRIMARY KEY,user_id INTEGER,workout_id TEXT,scheduled_date TEXT,intervals_event_id TEXT);`);
const structure=JSON.stringify([{durationMinutes:30,power:65}]);
snap.sqlite.prepare('INSERT INTO saved_workouts VALUES(?,?,?,?,?)').run(3,'abcdefghij','ride','Legacy ride',structure);
snap.sqlite.prepare('INSERT INTO planned_own_workouts(user_id,id,saved_id,sport,name,structure_json) VALUES(?,?,?,?,?,?)').run(3,'fixedcopy1','abcdefghij','ride','Snapshot ride',structure);
snap.sqlite.prepare('INSERT INTO workout_schedule_links VALUES(?,?,?,?,?)').run(1,3,'own-abcdefghij','2026-10-19','legacy');
const legacyBefore=await getLib.getWorkout(snap,'own-abcdefghij');
snap.sqlite.exec("UPDATE saved_workouts SET name='Edited run',sport='run' WHERE id='abcdefghij'");
const legacyAfter=await getLib.getWorkout(snap,'own-abcdefghij'),newAfter=await getLib.getWorkout(snap,'own-fixedcopy1');
assert.equal(legacyBefore.sport,'ride');assert.equal(legacyAfter.sport,'run');assert.equal(newAfter.sport,'ride');
snap.sqlite.exec("DELETE FROM saved_workouts");assert.equal(await getLib.scheduledLink(snap,'own-abcdefghij','2026-10-19'),null);assert.equal((await getLib.getWorkout(snap,'own-fixedcopy1')).duration_minutes,30);
record('A18',{newSnapshotStable:true,legacyBefore:{name:legacyBefore.name,sport:legacyBefore.sport},legacyAfter:{name:legacyAfter.name,sport:legacyAfter.sport},legacyScheduledLinkAfterDelete:null});
// The new snapshot's SELECT-then-INSERT has no uniqueness for its contents.
let sequence=0,arrived=0,release;const gate=new Promise(r=>release=r);
const raceDb={...snap,prepare(sql){const statement=snap.prepare(sql);if(!sql.startsWith('SELECT id FROM planned_own_workouts'))return statement;return {bind(...args){const bound=statement.bind(...args);return {async first(){const value=await bound.first();if(++arrived===2)release();await gate;return value;}};}};}};
const {plannedCopy}=compile(between(templates,'async function plannedCopy(','export async function ensureShareTable('),{newId:()=>('racecopy'+(++sequence)).padEnd(10,'x')},['plannedCopy']);
const row={id:'newsource1',sport:'ride',name:'Same template'};
const ids=await Promise.all([plannedCopy(raceDb,3,row,JSON.parse(structure)),plannedCopy(raceDb,3,row,JSON.parse(structure))]);
assert.notEqual(ids[0],ids[1]);
const {buildIntervalsEvent}=compile(between(library,'export function buildIntervalsEvent(','export async function scheduleWorkoutInIntervals('),{...model,L,sportOf:s=>s==='run'?'run':'ride',carbsPerHour:()=>null,focusLine:()=>'',DEFAULT_START:'17:00',n:(v,f=0)=>Number.isFinite(Number(v))?Number(v):f},['buildIntervalsEvent']);
const events=[];for(const id of ids){const w=await getLib.getWorkout(snap,'own-'+id);events.push(buildIntervalsEvent(w,'2026-10-21'));}
assert.notEqual(events[0].external_id,events[1].external_id);
record('N-training-snapshot-race',{copies:ids,externalIds:events.map(e=>e.external_id),sameDate:events[0].start_date_local,duplicateSnapshots:snap.sqlite.prepare("SELECT COUNT(*) AS n FROM planned_own_workouts WHERE saved_id='newsource1'").get().n});
const calendar=createD1();calendar.userId=3;
const tables=compile(between(library,'export async function ensureTrainingTables(','async function importedWorkouts('),{},['ensureTrainingTables']);
calendar.sqlite.exec(`CREATE TABLE planned_own_workouts(user_id INTEGER,id TEXT,saved_id TEXT,sport TEXT,name TEXT,structure_json TEXT,PRIMARY KEY(user_id,id));CREATE TABLE health_datapoints(id INTEGER PRIMARY KEY,user_id INTEGER,source_family TEXT,data_type TEXT,external_id TEXT,sample_time TEXT,start_time TEXT,end_time TEXT,payload_json TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,source_family,data_type,external_id));`);
for(const id of ids)calendar.sqlite.prepare('INSERT INTO planned_own_workouts VALUES(?,?,?,?,?,?)').run(3,id,row.id,row.sport,row.name,structure);
const localSource=read('local-workouts.js');
const local=compile(between(localSource,'export async function ensureLocalWorkouts(','export async function syncLocalWorkout('),{L},['ensureLocalWorkouts','storeLocalEvent']);
const scheduler=compile(library.slice(library.indexOf('export async function scheduleWorkoutInIntervals(')),{...model,...tables,...local,L,getWorkout:getLib.getWorkout,assertTrainingAllowed:()=>{},getAthleteState:async()=>({status:'active'}),environmentOf:s=>s==='outdoor'?'outdoor':'indoor',sportOf:s=>s==='run'?'run':'ride',buildIntervalsEvent,athleteThresholds:async()=>null,plannedStart:async()=> '17:00',syncLocalWorkout:async()=>({status:'off'})},['scheduleWorkoutInIntervals']);
const scheduled=await Promise.all(ids.map(id=>scheduler.scheduleWorkoutInIntervals({},calendar,{workoutId:'own-'+id,date:'2026-10-21',confirm:true})));
const calendarCount=calendar.sqlite.prepare('SELECT COUNT(*) AS n FROM local_workouts').get().n;
assert.equal(calendarCount,2);assert.deepEqual(scheduled.map(s=>s.status),['ok','ok']);
record('N-training-snapshot-calendar',{calendarEvents:calendarCount,scheduleLinks:calendar.sqlite.prepare('SELECT COUNT(*) AS n FROM workout_schedule_links').get().n,providerDelivery:'off; no external calls',statuses:scheduled.map(s=>s.status)});

const pick=compile(read('ai-workout-pick.js'),{...model,L},['workoutLoadCheck']);
const fit=compile(between(read('ai-workout-compose.js'),'export function composeFits(','function newId('),{...model,...endurance,...pick},['composeFits']);
const proposedStructure=[{durationMinutes:5,power:50},{durationMinutes:25,power:83},{durationMinutes:5,power:50}];
assert.equal(fit.composeFits({structure:proposedStructure,sport:'ride',type:'tempo',length:30,cap:45}),true);
const ai=model.buildWorkout({id:'ai-example001',sport:'ride',name:'Synthetic composed tempo',system:'tempo',structure:proposedStructure});
const outdoors=model.renderForEnvironment(ai,'outdoor');assert.equal(outdoors.duration_minutes,45);
record('N-training-compose-budget',{dayLimit:30,requestedLength:30,acceptedBaseMinutes:ai.duration_minutes,renderedOutdoorMinutes:outdoors.duration_minutes,check:true});
// Execute the unchanged /compose branch with an isolated valid composer response.
// This tests route policy, not an actual AI response or private prompt.
const entry=read('entrypoint.js');
const composeRoute=between(entry,"    if(url.pathname==='/app/api/workouts/compose'", "    if(url.pathname==='/app/api/workouts/generate'");
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
let composedRequest;
const deps={
 env:{DB:{}},url:new URL('https://example.invalid/app/api/workouts/compose?date=2026-10-21'),request:new Request('https://example.invalid/app/api/workouts/compose',{method:'POST'}),sport:'ride',ctx:{},
 assertTrainingAllowed:()=>{},getAthleteState:async()=>({status:'active'}),localToday:()=>today,
 libraryDay:async()=>({date:'2026-10-21',coach:{readiness:{status:'green'},recommendation:{session:{kind:'tempo',durationMinutes:30}}},filters:{durationMinutes:30,maxDurationMinutes:30,durationSoft:true,environment:'outdoor',system:'tempo'}}),
 libraryKind:(_sport,kind)=>kind,COMPOSE_VARIANTS:3,composeKey:()=> 'isolated-query',readinessCheckin:async()=>null,recentWorkoutRatings:async()=>[],
 shiftDate:(d,n)=>new Date(Date.parse(d+'T12:00:00Z')+n*86400000).toISOString().slice(0,10),
 composeWorkout:async(_env,options)=>{composedRequest=options;return ai;},renderForEnvironment:model.renderForEnvironment,cached:(_env,_ctx,_key,fn)=>fn(),athleteThresholds:async()=>({}),stepRows:()=>[],rideFtpFor:()=>({ftp:null}),explainWorkout:()=>({how:[],fueling:[],environment:[]})
};
const response=await new AsyncFunction(...Object.keys(deps),composeRoute)(...Object.values(deps));
const responseBody=await response.json();assert.equal(responseBody.workout.duration_minutes,45);
record('N-training-compose-route',{status:response.status,requestedLength:composedRequest.minutes,dayLimit:30,returnedMinutes:responseBody.workout.duration_minutes});
writeFileSync('/workspace/aurin-reaudit-2026-10-20/training-metrics-repro-results.json',JSON.stringify(results,null,2));
