// Original backend food import function with local SQLite and no-op schema dependencies.
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {createD1} from '/workspace/health-api/tests/helpers/d1.mjs';
const source=readFileSync('/workspace/health-api/src/apple-food.js','utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const save=new Function('ensureFoodLogTable','ensureFluidLog',source+'\nreturn saveAppleFood;')(async()=>{},async()=>{});
const DB=createD1();
DB.sqlite.exec(`CREATE TABLE food_logs(id INTEGER PRIMARY KEY,user_id INTEGER,consumed_date TEXT,consumed_at TEXT,recipe_title TEXT,kcal REAL,note TEXT,source TEXT);
 CREATE TABLE fluid_log(id INTEGER PRIMARY KEY,user_id INTEGER,date TEXT,consumed_at TEXT,ml INTEGER,external_id TEXT,source TEXT);
 INSERT INTO food_logs VALUES(1,7,'2026-10-19','2026-10-19T12:00:00','Imported meal',500,'{"external_id":"hk-meal"}','apple-health');
 INSERT INTO fluid_log VALUES(1,7,'2026-10-19','2026-10-19T12:00:00',250,'hk-drink','apple-health');`);
const result=await save(DB,7,{from:'2026-10-01',to:'2026-10-20',meals:[],drinks:[]});
const remainingMeals=DB.sqlite.prepare('SELECT COUNT(*) AS n FROM food_logs').get().n;
const remainingDrinks=DB.sqlite.prepare('SELECT COUNT(*) AS n FROM fluid_log').get().n;
assert.equal(result.removed,2);assert.equal(remainingMeals,0);assert.equal(remainingDrinks,0);
console.log(JSON.stringify({result,remainingMeals,remainingDrinks}));
