**Dílčí audit — výživa, veřejný web, testovací infrastruktura a provoz**

Revidovaný commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Aplikace nebyla měněna. Tento podklad navazuje na první devítinálezový report; původní nález předčasného potvrzení idempotentního zápisu nepočítá znovu.

**F1 [P2] Export jídla do Google zahazuje uživatelem zadaný čas**

Místo: [food-google-sync.js:20](../../src/food-google-sync.js#L20).

`foodGooglePayload()` přijímá původní čas jen tehdy, když obsahuje časovou zónu. Nový food endpoint ale přes `mealConsumedAt()` ukládá uživatelem zadaný čas ve formátu `YYYY-MM-DDTHH:MM:SS` bez offsetu. Ten je platným lokálním časem aplikace, nikoli chybějící hodnotou. Export ho nahradí polednem UTC.

Scénář: snídaně zapsaná v 07:30 se při exportu uloží jako 12:00 UTC. V Praze může být v Google zobrazena ve 14:00. Jde o nesoulad časové osy a historie při používání obou služeb; makroživiny se tím samy nemění.

Reprodukce původní funkce: `2026-10-19T07:30:00` → `2026-10-19T12:00:00.000Z`. [repro-food-audit.mjs](./repro-food-audit.mjs).

Oprava: rozlišovat platný lokální čas a neznámý čas. Lokální čas převádět přes uživatelovu časovou zónu včetně letního času a do exportu přidat správný offset. Poledne používat pouze tam, kde čas skutečně chybí. Regresní test: lokální 07:30, explicitní UTC/offset, změna dne a přechod letního času.

Jistota vysoká; runtime ověření původní funkce, bez reálného Google API.

**F2 [P2] Hromadná změna jídel může selhat až po částečném uložení a opakování vytváří kopie**

Místo: [food-entry-management.js:101](../../src/food-entry-management.js#L101), řádky 101–106. Zpracování chyby: [routes-food.js:48](../../src/routes-food.js#L48). iOS tok: [MealDetailView.swift:58](../../ios-native/Loadwise/Screens/MealDetailView.swift#L58).

`bulkFoodEntries()` provádí jednotlivé změny postupně bez společné transakce. Pokud další záznam už neexistuje nebo nastane chyba úložiště, endpoint vrátí chybu celé operace. Dřívější změny přitom zůstávají uložené; export do Google se připravuje až po dokončení celé funkce, takže změněné položky mohou zůstat i nesynchronizované.

Scénář: uživatel vybere dvě jídla, druhé mezitím smaže jiné zařízení. Kopírování první jídlo vloží a na druhém selže. UI zůstane v chybovém stavu se stejným výběrem; opakování zkopíruje první jídlo podruhé. To není pouze hypotetický výpadek sítě — stačí běžná změna dat mezi načtením seznamu a potvrzením.

Reprodukce původní funkce nad SQLite: vybraná ID `[1,999]` → chyba a jedna vložená kopie; opakování → chyba a dvě kopie. [repro-food-audit.mjs](./repro-food-audit.mjs).

Oprava: nejprve ověřit všechny vstupy a lokální změny provést atomicky, včetně přípravy exportních záznamů tam, kde mají stejné úložiště. Alternativní smlouva API musí explicitně vracet částečné výsledky a klient opakovat jen neprovedené části. Kopírování chránit idempotentním klíčem. Regresní test: chybějící druhé ID, selhání prostředního zápisu a opakování stejného požadavku.

Jistota vysoká; skutečné SQLite a původní funkce, staticky trasované UI a endpoint.

**F3 [P2] Workflow pro aktualizaci mikroživin nedokáže projít vlastními testy**

Místo: [food-micros.yml:54](../../.github/workflows/food-micros.yml#L54), řádky 54–55.

Workflow checkoutne jen veřejný repozitář a spouští `micronutrients.test.mjs` a `world-foods.test.mjs`. Oba importují moduly závislé na `src/lang.js`, který přímo importuje `src/private/lang.js`. Soukromý repozitář se v tomto workflow nestahuje a `src/private` je gitignored. Čistý GitHub runner proto skončí na `ERR_MODULE_NOT_FOUND` ještě před buildem a uploadem dat.

Ověření přesného příkazu workflow v prostředí se stejným chybějícím checkoutem: oba testové soubory selžou při načítání. Výstup: [food-workflow-tests.tap](./food-workflow-tests.tap). Nebyl spuštěn vzdálený workflow ani upload do R2.

Oprava: doplnit checkout soukromého repozitáře se stejnou ověřenou revizí jako ostatní pipeline. Lepší dlouhodobé oddělení je přesunout základní lokalizační funkce mimo závislost na AI promptech, aby data build nemusel potřebovat soukromé texty. Regresní ověření: čistý checkout a přesný workflow test/build příkaz bez ručně předpřipravených souborů.

Jistota vysoká; explicitní importní závislost a lokálně zopakovaný příkaz.

**F4 [P3] Veřejný návod slibuje odpojení Apple, které běžný uživatel v aplikaci nemá**

Místa: [site-pages.js:764](../../src/site-pages.js#L764) a [site-pages.js:863](../../src/site-pages.js#L863); blokace endpointu v [owner-only-routes.js:15](../../src/owner-only-routes.js#L15).

Anglický i český text uvádějí, že Sign in with Apple lze odpojit v Nastavení → Účet. V aktuálním Swift UI není volání `/app/api/me/apple` a tento endpoint je navíc pro běžné uživatele zařazený mezi owner-only cesty. Uživatel tudíž nenajde popsaný postup. Alternativa v nastavení Apple ID je v textu uvedená a fungování této externí alternativy nebylo testováno.

Oprava: doplnit bezpečný uživatelský tok odpojení s kontrolou alternativního přihlášení, nebo sladit obě jazykové verze návodu se skutečně dostupným postupem. Nepovolovat endpoint ostatním bez kontroly identity a ochrany před ztrátou přístupu k účtu. Regresní ověření: běžný ne-owner účet a shoda všech nabízených postupů s nastavením aplikace.

Jistota vysoká ze zdrojového kódu; jde o chybu produktového návodu, nikoli důkaz narušení účtu nebo právní závěr.

**Technická rizika a mezery — nejsou další potvrzené funkční chyby**

- Test a deploy samostatně checkoutují aktuální výchozí revizi soukromých promptů bez společného připnutého SHA. Pokud se soukromý repozitář mezi joby změní, může se nasadit jiná kombinace než prošla testem. Doporučení: určit revizi jednou, předat ji oběma jobům a uložit ji do release metadat. V tomto auditu nebyl ověřen konkrétní takto chybný release.
- Standardní lint obsahuje pouze `no-undef`. Je užitečný pro chybějící proměnné, ale neověřuje API kontrakty, ztrátu dat, autorizaci, zdrojové priority ani ekonomické limity AI.
- Z 240 testových souborů obsahuje 91 čtení zdrojových souborů nebo `serverSource()`. Neznamená to, že všech 91 jsou výlučně textové testy; znamená to, že samotný počet souborů není míra pokrytí chování. Nebylo naměřeno procento coverage. Konkrétní existující test idempotence dokonce výslovně přijímá předčasné `ok`, které audit reprodukoval jako chybu.
- Zálohovací plán v repozitáři kopíruje centrální databázi a uživatelské shardy týdně a udržuje 28 dní. Není zde automatizovaný restore drill ani důkaz změřeného RTO. Doporučení: pravidelný izolovaný restore se zkouškou routes, počtů a přihlášení. Skutečné nastavení Cloudflare Time Travel a externí runbook nebyly dostupné; netvrdíme, že žádná další obnova neexistuje.
- Veřejné datové tabulky a generované katalogy mají samostatné aktualizační a cache cesty. Nutné ověřit verzi potravin a mikroživin, jednotky a kvalitu odhadovaných hodnot na reálném vzorku. Audit neprováděl nutriční nebo klinickou validaci externích databází.
- Obrana proti XSS v hlavičkách nemá restriktivní `script-src`; kód s tímto omezením počítá kvůli inline skriptům. Bez prokázané injekční cesty to není potvrzený XSS nález. Doporučení: nonce/hash strategie a samostatné testy veřejných OAuth/share stránek.
- U stavu účtu, lokální cache a workflow je vhodná matice účet × server × den × síťová chyba. Dosavadní jednotlivé unit a screenshot testy nezajišťují souběh a přenos vlastnictví; potvrzené nálezy výše i v nativních reportech ukazují konkrétní chybějící scénáře.

**Pokrytí**

Detail nebo sledování toku: `src/routes-food.js`, `food-entry-management.js`, `food-portions.js`, `food-log.js`, `food-google-sync.js`, `food-sources.js`, `personal-foods.js`, `personal-recipes.js`, `shared-foods.js`, `food-suggestions.js`, `food-catalog-storage.js`, `world-foods.js`, `micronutrients.js`, `fluids.js`, `cookbook.js`, `food-label.js`, `food-photo.js`, `food-chat.js`, `app-food.js`, `app-food-week.js`; odpovídající food endpointy v `index.js` a nativní bulk tok v `MealDetailView.swift` / `APIClient+Food.swift`.

Přehled implementace, guardů a závislostí: `food-ai.js`, `food-recommend.js`, `nutrition-intelligence.js`, `nutrition-next.js`; AI instrukce v chybějícím `src/private` nebyly přečtené ani nahrazované. Apple/Google food import je detailněji v samostatném konektorovém reportu.

Veřejný web a provozní návaznosti: `main.js`, `web-security.js`, `web-app-closed.js`, `app-origin.js`, relevantní části `site-pages.js`, `public/_headers`, `package.json`, `eslint.config.mjs`, `.gitignore`, `wrangler.jsonc`, deploy/test/iOS/release/backup/data workflows a relevantní provisioning a backup skripty. Detailní přehled infrastruktury a migrací doplňuje `provoz.md`.

Neprovedeno: skutečné doručení dat do Google, produkční migrace a obnova, čtení produkčních záznamů, browser/simulátor rendering, externí AI a vyhodnocení fotografie skutečným modelem.
