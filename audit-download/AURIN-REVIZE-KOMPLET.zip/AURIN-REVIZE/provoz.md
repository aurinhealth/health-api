**Dílčí audit — provoz, CI, vydávání, databázové migrace a servisní nástroje**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Kontrola byla lokální a read-only vůči aplikaci i vzdáleným službám. Zahrnuje všech deset workflow, všechny skripty `.mjs`, Python pro TestFlight, SQL bootstrap/migrace a konfiguraci Workeru. U velkých datových builderů jde o přehled architektury a kritických vstupů/výstupů, nikoli o validaci každé externí potravinové tabulky. Strojově čitelné skutečné hloubky jsou v [provoz-pokryti.json](./provoz-pokryti.json).

**O1 — [P2] Workflow mikroživin nemůže v čistém checkoutu projít před sestavením dat**

Tento nález již potvrdil hlavní auditor; **nepočítat jej dvakrát**. [food-micros.yml:54](../../.github/workflows/food-micros.yml#L54), řádky 54–55, spouštějí testy závislé přes `lang.js` na `src/private/lang.js`. Na rozdíl od hlavního testovacího a deploy workflow zde chybí checkout soukromého repozitáře promptů. Ten je gitignored, takže ho standardní `actions/checkout` nezíská.

Výsledek: čistý runner skončí před krokem Build, tedy i před požadovaným uploadem mikroživin. Nejde pouze o omezení tohoto auditu; je to chybějící závislost definovaného workflow. Lokální výstup odpovídajícího příkazu je v [food-workflow-tests.tap](./food-workflow-tests.tap).

Oprava: doplnit stejný autorizovaný checkout soukromé závislosti jako do hlavních testů, případně rozdělit čistě datové moduly tak, aby formát/konstanty a jejich testy neimportovaly vrstvu AI lokalizace. Před R2 uploadem ověřit celý čistý build, nikoli pouze přeskakovat selhávající testy. Acceptance: workflow z čistého runneru úspěšně otestuje a vytvoří artefakt při `upload:false`.

**O2 — [P3] Konkrétní osobní adresa majitele zůstává ve veřejném SQL souboru**

Místo: [0004_backfill_completed_strength_20261002.sql:15](../../migrations/0004_backfill_completed_strength_20261002.sql#L15).

Současná konfigurace přesunula `OWNER_EMAIL` do secretu a zdůrazňuje, že osobní adresa není součástí repozitáře. Jednorázová historická migrace však stále obsahuje konkrétní adresu v podmínce uživatele pro backfill tréninku. Adresu zde záměrně neopakuji. Je to osobní metadata a identifikace účtu, **nikoli heslo ani API klíč**. Nález sám neumožňuje přihlášení.

Oprava: rozhodnout, zda tento již historický datový backfill musí být v bootstrapu nových databází, a odstranit konkrétní osobní identifikátor z aktuálně publikované verze. Nespoléhat na to, že přesun proměnné do secretu odstranil i ostatní výskyty. Historie Git může starou adresu nadále obsahovat; případná práce s historií vyžaduje samostatné uvážení dopadu, není nutnou součástí této revize.

Jistota vysoká ze statické kontroly současného souboru. Priorita P3 znamená opravu minimalizace veřejných osobních metadat; nejde o důkaz úniku credentialů.

**Provozní rizika a nedoložené vlastnosti — nejsou další počítané potvrzené vady**

| Oblast | Zjištění a dopad | Doporučená oprava nebo ověření |
|---|---|---|
| Reprodukovatelnost nasazení | `deploy-worker.yml` získá soukromé prompty znovu v test jobu a deploy jobu bez společně zafixovaného SHA. Změna soukromého repozitáře mezi nimi může způsobit test jiné kombinace kódu, než se nasadí. | Na začátku určit SHA obou repozitářů, použít je v obou jobech a zaznamenat je k releasu. Ověřit i rollback kombinace server + prompty. |
| Úplnost záloh | `backupPlan()` plánuje pouze centrální DB a 20 uživatelských shardů. Samostatná `FOODS` databáze společného katalogu a jeho kontribucí není v tomto plánu. Lokální výpočet plánu vrátil 21 DB a žádnou katalogovou. | Doplnit katalog do obnovovacího plánu nebo doložit jiný mechanismus jeho zálohy a obnovy. Tento audit nemá přístup k případným zálohám spravovaným mimo repozitář. |
| Obnova po havárii | Repozitář obsahuje týdenní export do R2 s 28denní retencí, nikoli automatický restore drill. Odkazovaný postup obnovy žije v externích projektových souborech, které zde nebyly dostupné. | V izolovaném prostředí pravidelně obnovit core, shards i katalog; ověřit počty, route a otevření účtů. Stanovit skutečné RPO/RTO a jejich měření. Týdenní export sám neprokazuje nulovou ztrátu mezi běhy. |
| Atomická publikace R2 dat | World-food builder má výchozí verzi pouze podle dne (`YYYYMMDD`). Dva buildy/uploady v témže dni mohou přepisovat stejné pack keys, zatímco Worker drží starší indexy. Přepnutí `current.json` jako posledního pak neposkytne izolaci dvou odlišných obsahů stejné verze. | Použít unikátní neměnnou verzi/hash a odmítnout přepsání existujícího release. Ověřit dvě publikace během stejného dne se zahřátou cache. Reálné R2 chování zde nebylo spuštěno. |
| Rozsah CI kvality | ESLint vynucuje jen `no-undef`; syntaxe a zelené testy neodhalují všechna logická, kontraktová, souběhová nebo bezpečnostní selhání. | Zachovat rychlý lint, ale přidat zejména kontraktové a scénářové regresní testy nalezených chyb. Počet testovacích souborů není code coverage. |
| Testy na PR versus main | PR test workflow má path filter jen na `src`, `tests`, package a vlastní konfiguraci; samotné změny některých servisních skriptů/migrací ho nespouštějí. Deploy na main část těchto změn testuje až před nasazením. | Doplnit relevantní scripts/migrations/config path filtry a ověření čisté migrace jako test PR. Nejde o tvrzení, že běžný main deploy testy neprovádí. |
| Datové buildery a assety | Build potravin používá externí tabulky; render svalů navíc licencovaný model a lokální Playwright/browser. Tyto vstupy a plné prostředí nejsou součástí běžného checkoutu. | Dokumentovat verze, checksumy, licence a přesný postup. Udržovat malá redistribuovatelná testovací data a kontrolu výstupního formátu. Chybějící placený model nepovažuji automaticky za bug aplikace. |
| GitHub/Cloudflare ochrany | YAML odkazuje na prostředí production/testflight/backup a má omezená oprávnění a concurrency. Samotný YAML neprokazuje skutečně nastavené approvals, branch protection, rozsah tokenů ani dostupnost credentialů. | Provést read-only provozní ověření skutečných nastavení a audit přístupů při předání k produkci. V tomto auditu nebyly tajné hodnoty ani účty prohlíženy. |
| Runtime služby | Cloudflare RPC self-binding pro per-user joby, kompatibilita `nodejs_als`, Smart Placement a pravidelné cron jsou deklarované. Bez nasazení nelze měřit skutečné CPU/query limity nebo doručení každého cronu. | Staging test se zátěží přes maximální kapacitu účtů, přerušením jednoho jobu a pomalými providery; sledovat izolaci limitů a prodlení. |

**Lokální ověření, která proběhla**

- Syntaktická kontrola všech `scripts/*.mjs` přes `node --check` prošla. Neprovádí importy, síť ani jejich CLI mutace.
- Python pro TestFlight prošel `ast.parse`; nebylo voláno App Store Connect ani GitHub API.
- `staging/schema.sql` bylo provedeno ve skutečném lokálním SQLite. Poté bylo respektováno předvyplnění tabulky `d1_migrations`: 10 již reflektovaných migrací přeskočeno, zbývajících 20 se úspěšně aplikovalo. Následný user-shard marker i samostatné food schema prošly. Výsledek je v [schema-verification.json](./schema-verification.json).
- Tento DDL test neověřuje plnou migraci produkčních dat, Cloudflare implementaci D1 ani online cutover během souběžného provozu. Pro důkaz degradace starších dat jsou potřeba jejich anonymizované fixtures.
- `backupPlan(wrangler.jsonc)` byl spuštěn jako čistá funkce bez volání Wrangleru; potvrdil výčet 21 databází uvedený výše.
- Původní test suite/lint a reprodukce aplikace jsou zaznamenané v hlavním reportu; nebyly zbytečně znovu spouštěny pro nezměněný kód.

**Přehled workflow**

| Workflow | Zkontrolovaná cesta | Hloubka |
|---|---|---|
| `deploy-worker.yml` | test gate, main check, oddělené prostředí/concurrency, bootstrap/migrace/provisioning, deploy, readiness a smoke | flow |
| `vydat.yml` | výběr main buildů, smoke SHA, nasazení serveru, externí TestFlight release a poznámky | flow |
| `ios-native.yml` | Xcode/XcodeGen, unit snapshoty, smoke demo, screenshoty, IPA a artefakty | flow |
| `ios-testflight.yml` | readiness secret names, archive/sign/upload, verze, notes job a cleanup | flow |
| `health-strength-tests.yml` | checkout privátní závislosti, Node 22, check/lint/test a PR filtry | detail |
| `food-micros.yml` | chybějící privátní checkout, test/build/upload gating, artefakty | detail |
| `db-backup.yml` | týdenní plán, prostředí backup a concurrency s produkčním deployem | detail |
| `coach-eval.yml` | ruční staging evaluace, OIDC audience, artefakt odpovědí | detail |
| `site-copy.yml` | pouze varování při změně app bez webu; nejde o prokázání shody obsahů | detail |
| `testflight-notes.yml` | kontrola popisu PR a vyvolání Python parseru | detail |

**Přehled servisních skriptů a SQL**

| Skupina | Soubory | Hloubka a omezení |
|---|---|---|
| Provisioning a cutover | `provision-user-shards.mjs`, `provision-food-catalog.mjs`, `food-catalog-tools.mjs`, `verify-user-shards.mjs`, `smoke-food-catalog.mjs` | flow/detail identity DB, routing, EU kontrola, staging flag, canary cleanup, copy/fingerprint a rollback stavu; žádný remote běh |
| Záloha a přesun řádků | `backup-databases.mjs`, `move-personal-rows.mjs` | detail plánu/retence a flow safe copy/verify/delete; žádný remote běh ani čtení skutečných osobních řádků |
| Gates a logy | `require-private-prompts.mjs`, `require-secrets.mjs`, `ci-summary.mjs` | detail preflightu, pouze názvy secretů a omezení veřejného logování |
| Katalog | `build-world-foods.mjs`, `upload-world-foods.mjs`, `build-micronutrients.mjs`, `micronutrient-matches.mjs` | přehled schémat, verzování, jednotek a zdrojů; flow publikace; bez kompletních upstream datasetů |
| Svalový model a web | `build-muscle-model.mjs`, `upload-muscle-model.mjs`, `render-muscles-site.mjs`, `render-muscles-site.html` | přehled binárního formátu, skupin, uploadu a renderovacího kontraktu; licencovaný model/render nebyl spuštěn |
| Ostatní nástroje | `import-cookbook.mjs`, `coach-eval.mjs`, `recovery-validation-rmcorr.mjs` | flow omezení výstupů, autorizované volání stagingu a formát korelací; soukromá kuchařka a skutečný model nebyly použity |
| TestFlight Python | `.github/scripts/testflight_notes.py` | flow parseru, limitu textu, JWT tvorby, výběru release a volání ASC; jen syntax test lokálně |
| Databáze | všech 30 `migrations/*.sql`, `staging/schema.sql`, `staging/user-data-shard.sql`, `food-migrations/0001_catalog.sql` | přehled DDL/DML a runtime čistého bootstrapu s ledgerem; ne historická produkční data |

**Dokončující přehled serverových provozních helperů**

`src/push.js` byl přečten včetně přeregistrování tokenu jinému účtu, validace prostředí, JWT cache, APNs chyb a atomického claimu ranní notifikace. `src/ops-report.js` byl přečten včetně scope zachytávání chyb, shrnutí podle služby, zaseknutých smazání, AI nákladů a denního report markeru. `src/user-jobs-entrypoint.js` je malý RPC wrapper; distribuce jobů zůstává posouzená v hlavním reportu. `src/support-report.js` byl již zahrnut v [backend-platforma.md](./backend-platforma.md). Bez skutečné APNs konfigurace, produkčních logů a e-mailu nelze ověřit doručení nebo provozní četnost chyb.

**Doporučené pořadí provozních úprav**

1. Opravit čistý build mikroživin a ověřit jeho dry-run z čistého checkoutu.
2. Zafixovat a zaznamenat SHA soukromých promptů pro každý serverový release.
3. Uzavřít inventář obnovovaných databází včetně FOODS a provést restore drill.
4. Přidat do PR ověření čistého bootstrapu a nejdůležitější kontraktové/souběhové regresní scénáře aplikace.
5. Zpřesnit verzování R2 dat a doložit skutečná produkční oprávnění, rate limits a provozní SLO.

Žádný bod tohoto reportu neznamená, že audit provedl nasazení, obnovu, odeslání e-mailu nebo změnu reálných zdravotních dat.
