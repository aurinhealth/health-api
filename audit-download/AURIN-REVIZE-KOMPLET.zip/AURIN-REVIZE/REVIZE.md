**První fáze revize — archiv původních devíti nálezů.** Aktuální rozšířený výsledek je v [souhrnném reportu](./KOMPLETNI-REPORT.md) a [PDF](./AURIN-REVIZE.pdf): 33 doložených nálezů, úplný přehled pokrytí a pořadí oprav.

**Hloubková revize aplikace Aurin**

Revidovaný commit: `02d575e570a179a5c156bcc9708877a2c18f3de8` v `/workspace/health-api`.

Výsledek: **9 ověřených nálezů — 2× P1, 7× P2.** Před širším vydáním doporučuji opravit oba přenosy dat mezi účty a chybu potvrzování nedokončeného zápisu. Nenalezl jsem důkaz anonymního přístupu k cizímu účtu; popsané přenosy mají konkrétní předpoklady uvedené níže.

P1 znamená vysokou prioritu kvůli porušení oddělení osobních dat. P2 znamená funkční nebo bezpečnostní chybu k naplánované opravě. Čísla vyjadřují prioritu opravy, nikoli naměřenou četnost výskytu v produkci.

| ID | Priorita | Nález | Ověření |
|---|---|---|---|
| 1 | P1 | HealthKit po expiraci přihlášení pokračuje do jiného účtu | Statická analýza celého toku |
| 2 | P1 | Nový účet může odeslat čekající zápisy předchozího účtu | Statická analýza souběžných toků |
| 3 | P2 | Probíhající zápis dostane předčasné potvrzení úspěchu | Původní funkce + skutečné lokální SQLite |
| 4 | P2 | OAuth callback neváže propojení na účet, který ho zahájil | Původní moduly ve VM, náhrada DB a sítě |
| 5 | P2 | Google přihlašovací ticket lze opakovat po odvolání session | Původní moduly ve VM, náhrada DB |
| 6 | P2 | Starší úprava gymu přepíše později dokončenou sérii | Statická analýza souběžných toků |
| 7 | P2 | Běžecký limit přidává běhy i při vyčerpaném rozpočtu | Původní výpočet návrhu týdne ve VM |
| 8 | P2 | Dnešní plánovaný běh se neodečte z týdenního rozpočtu | Původní výpočet návrhu týdne ve VM |
| 9 | P2 | Push kouče se nespouští bez Google/Intervals propojení | Původní definice a predikáty výběru jobů |

**1. [P1] HealthKit po expiraci přihlášení pokračuje do jiného účtu**

Primární místo: [AppModel.swift:1384](../../ios-native/Loadwise/App/AppModel.swift#L1384), řádky 1384–1389. Navazující upload: [AppleHealth.swift:306](../../ios-native/Loadwise/App/AppleHealth.swift#L306) a [AppleHealth.swift:333](../../ios-native/Loadwise/App/AppleHealth.swift#L333).

`clearLocal(expired: true)` zachová zapnutý import Apple Health. Pozastavení přes `AppleHealth.pause()` se provádí pouze při běžném odhlášení. Ani větev `anotherAccount` v `signedIn()` import při přihlášení jiného účtu nevypne. `AppleHealth.run()` kontroluje pouze zapnutí, dostupnost HealthKit a existenci session; neověřuje, komu původní povolení patřilo. Upload používá právě aktuální přihlášení.

Scénář: A zapne Apple Health, jeho session později vyprší a aplikace dostane 401. Na stejném telefonu se přihlásí existující účet B s obecným souhlasem ke zdravotním datům. Po vypršení desetiminutového omezení synchronizace se zdravotní data telefonu odešlou do B, přestože B Apple Health v aplikaci nezapnul. Backend ukládá upload pod aktuálním `USER_ID` v [entrypoint.js:2077](../../src/entrypoint.js#L2077).

Dopad: chybné přiřazení citlivých zdravotních dat a porušení oddělení účtů. Nejde o možnost vzdáleně číst libovolný HealthKit; předpokladem je změna účtu na telefonu s již povoleným přístupem.

Oprava: vázat povolení importu na stabilní ID účtu a server, při každém ukončení přihlášení import pozastavit a obnovovat ho až po ověření shody. Zrušit rozpracovaný sync a před každým POST ověřit generaci účtu. Samotné `pause()` nestačí: `disconnect()` neruší běžící `running` task, který může po `await reader.collect()` pokračovat s novou session.

Regresní ověření: A povolí HealthKit → 401 → B se přihlásí → žádný upload do B. Druhý případ musí změnit účet během pozastaveného `reader.collect()`.

Jistota vysoká ze statické analýzy; scénář nebyl spuštěn v iOS simulátoru.

**2. [P1] Nový účet může odeslat čekající zápisy předchozího účtu**

Primární místo: [AppModel.swift:370](../../ios-native/Loadwise/App/AppModel.swift#L370), řádky 370–375. Souběžný zápis identity: [RootView.swift:224](../../ios-native/Loadwise/App/RootView.swift#L224) a [AppModel.swift:295](../../ios-native/Loadwise/App/AppModel.swift#L295).

`signedIn()` nastaví `.signedIn` před `await api.account()` a před rozlišením původního a nového účtu. Vzniklá obrazovka Today má vlastní `.task`, která spouští `refreshIfStale()` → `performRefresh()` → `sendOutbox()`. Čekající zápisy zachované po expiraci mohou odejít s novou cookie dříve, než se outbox vyčistí.

Existuje i druhé pořadí: `RootView.task` souběžně volá `loadAccountInitial()`, který přepíše uložené ID a e-mail. Pokud tento požadavek doběhne první, pozdější `anotherAccount()` porovnává B s již uloženým B a změnu účtu přehlédne.

Scénář: A vytvoří offline jídlo, pití nebo vážení; při pozdějším načítání vyprší session a outbox zůstane zachovaný. Přihlásí se B. Pomalá nebo různě rychlá odpověď na požadavky `/me` umožní odeslání dat A do B.

Oprava: nejprve získat a ověřit identitu, rozhodnout o místních datech a teprve potom zveřejnit `.signedIn`. Outbox ukládat se stabilním ID vlastníka a serverem a ověřovat je i těsně před odesláním. Referenční identitu nesmí přepsat souběžný požadavek před rozhodnutím o změně účtu.

Regresní ověření: zadržet první `/me`, povolit Today refresh a zkontrolovat, že žádná položka A neodejde pod B. Zvlášť obrátit pořadí odpovědí obou `/me` požadavků.

Jistota vysoká ze statické analýzy; projev závisí na pořadí dokončení síťových operací. Nebylo spuštěno v simulátoru.

**3. [P2] Probíhající zápis dostane předčasné potvrzení úspěchu**

Primární místo: [idempotency.js:49](../../src/idempotency.js#L49), řádky 49–57. Přijetí na klientovi: [APIClient.swift:649](../../ios-native/Loadwise/Data/APIClient.swift#L649) a [AppModel.swift:834](../../ios-native/Loadwise/App/AppModel.swift#L834).

Pokud opakování stejného `requestId` dorazí během prvního zápisu, `withIdempotency()` vrací HTTP 200 s `{status:'ok', duplicate:true}`, i když ještě neexistuje výsledek. První pokus přitom může později selhat. iOS pokládá libovolné 2xx za úspěch a odstraní položku z outboxu.

Scénář: zápis jídla, pití nebo váhy překročí klientský dvacetisekundový timeout; další odeslání dorazí, zatímco první Worker ještě běží. Opakování dostane 200 a klient ho zahodí. První pokus následně selže před uložením dat. Uživatel ztratí záznam, přestože obdržel potvrzení úspěchu.

Lokální reprodukce původní funkce nad SQLite skončila:

```json
{"firstStatus":500,"replayStatus":200,"replayBody":{"status":"ok","duplicate":true},"writes":0,"claims":0}
```

Oprava: rozlišit probíhající a dokončený požadavek. Probíhající stav musí vracet odpověď, kterou klient bezpečně zopakuje, nebo počkat na skutečný výsledek. Se současným klientem lze použít 503; samotné přepnutí na 409/425 není dostatečné, protože `sendQueued()` většinu 4xx zahazuje. Případný nový stav je nutné podporovat na obou stranách. S ohledem na současné zahazování po pěti serverových chybách je vhodné odlišit „stále probíhá“ i od skutečného selhání serveru.

Existující test souběžného opakování v `tests/idempotency.test.mjs` očekává právě předčasné `ok` a neověřuje pozdější selhání původního pokusu.

Reprodukce: [repro-idempotency.mjs](./repro-idempotency.mjs). Jistota vysoká; runtime reprodukce bez externích služeb a soukromých promptů.

**4. [P2] OAuth callback neváže propojení na účet, který ho zahájil**

Primární místo: [google-oauth.js:20](../../src/google-oauth.js#L20), řádky 20–35. Vydání state cookie: řádky 12–17 téhož souboru.

OAuth state obsahuje náhodnou hodnotu a návratový cíl, ale ne identitu účtu. Callback kontroluje shodu state, potom uloží klíče pod aktuální `env.USER_ID`. Vstupní brána odvozuje tento scope z aktuální session, nikoli z identity při zahájení autorizace.

Scénář: propojení Google Health začne pod A. Ve sdíleném browser kontextu se před návratem z Google změní Aurin session na B. Callback s platným state uloží zdravotní zdroj A do B. Následná synchronizace může importovat data do nesprávného účtu.

Nativní connect ticket původní účet ověřuje při zahájení, ale [native-connect.js:84](../../src/native-connect.js#L84) následně vydá běžnou browser session cookie; identita není samostatně připnutá k pozdějšímu callbacku. iOS používá neephemerální autentizační browser. Nejde o anonymní obejití přihlášení; předpokladem je změna platné session v témže browser kontextu během autorizace.

Lokální běh původních modulů s náhradou sítě a úložiště: start pod UID 11, callback pod UID 22, výsledek 302, `google` i `google_scopes` uložené pod UID 22. Obdobný state vzor je i u dalších providerů; runtime reprodukce byla provedena pro Google.

Oprava: serverový jednorázový OAuth challenge svázaný s `user_id`, poskytovatelem a expirací. Callback s jiným účtem odmítnout ještě před uložením klíčů. Stejnou vlastnost sjednotit u všech providerů.

Reprodukce: [repro-auth.mjs](./repro-auth.mjs). Jistota vysoká pro backendový tok; celý přechod browser session nebyl simulován v iOS.

**5. [P2] Google přihlašovací ticket lze opakovat po odvolání session**

Primární místo: [google-login.js:138](../../src/google-login.js#L138), řádky 138–142. Vydání ticketu: [google-login.js:103](../../src/google-login.js#L103). Vydání session: [dashboard-auth.js:149](../../src/dashboard-auth.js#L149).

Pětiminutový app handoff ticket není jednorázový ani svázaný s epochou přihlášení platnou při vydání. Opakovaná výměna ticketu a verifieru vždy vytvoří novou session s aktuální `session_epoch` načtenou z databáze.

Scénář: po úspěšném přihlášení přes Google uživatel odvolá sessions pomocí „odhlásit všude“ nebo akcí, která zvýší epochu. Držitel již použitého ticketu a verifieru je během zbývající platnosti znovu vymění a získá platnou měsíční session s novou epochou. Omezení: musí mít obě hodnoty a stihnout pětiminutové okno; tento nález sám neposkytuje cestu k jejich získání.

Lokální reprodukce: první výměna 200; epoch 0 → 1; opakovaná výměna stejných hodnot opět 200; nová session má epochu 1 a projde `sessionMatchesUser()`.

Oprava: ticket atomicky spotřebovat a vázat na epochu při vydání. Obdobný mechanismus jednorázového použití již existuje pro connect tickets v `native-connect.js`.

Reprodukce: [repro-auth.mjs](./repro-auth.mjs). Jistota vysoká; runtime reprodukce s lokální náhradou úložiště.

**6. [P2] Starší úprava gymu přepíše později dokončenou sérii**

Primární místa: [TrainingModeView.swift:976](../../ios-native/Loadwise/Screens/TrainingModeView.swift#L976), řádky 976–985, a [TrainingModeView.swift:994](../../ios-native/Loadwise/Screens/TrainingModeView.swift#L994), řádky 994–1008.

`saveEdited()` a `add()` zveřejní nový `day`, potom čekají na síťové `loadMuscles()` a až následně uloží zachycený snapshot. Během čekání není nastaveno `saving`, takže uživatel může odškrtnout sérii. `complete()` uloží novější stav, ale původní operace potom odešle starší snapshot s nehotovou sérií.

`AppModel.saveGym()` zápisy serializuje a slučuje podle pořadí příchodu. Nezná však stáří obsahu; starý snapshot, který přijde až po načtení svalů, vyhraje. Přepíše i místní cache. Na obrazovce přitom může série dál vypadat jako hotová, protože starší operace znovu nenastavuje `day`.

Scénář: přidat nový cvik → zpozdit odpověď `gymMuscles` → dokončit jeho sérii → nechat odpověď doběhnout → znovu načíst trénink. Série se vrátí do nehotového stavu.

Oprava: zařadit zápis změněného dne před prvním čekáním na síťová metadata. Svaly načítat nezávisle. Další možností je verzovat změny a před uložením odmítat starší snapshoty.

Jistota vysoká ze statické analýzy; bez běhu v simulátoru.

**7. [P2] Běžecký limit přidává běhy i při vyčerpaném rozpočtu**

Primární místo: [week-planner.js:342](../../src/week-planner.js#L342), řádky 339–343.

`capRunVolume()` správně vypočte zbývající rozpočet, ale u každého návrhu vynutí `Math.max(20, ...)`. I s nulovým zbytkem tak zachová všechny běhy po dvaceti minutách. Při příliš mnoha dnech není možné limit dodržet pouhým zkracováním každého běhu.

Reprodukce skutečného `weekProposal()` bez CTL a bez historie: čtyři běžecké dny vytvoří 80 minut při limitu 60. Pokud už dnes uživatel dokončil 60 minut, tři budoucí dny přidají dalších 60 minut — celkem 120 proti limitu 60. Odpověď přitom nese `limited:true`. Scénář je dosažitelný přes `POST /app/api/coach/week`; následné `capWeekTargets()` už běžecký týdenní limit neprosazuje.

Dopad: překročení vlastního ochranného pravidla pro růst běžecké zátěže, zejména u začátečníků. Z nálezu nelze odvozovat, že v produkci způsobil zranění.

Oprava: pokud nezbývá rozpočet na minimální smysluplný běh, návrh vynechat. Omezit také počet navržených běhů a po zaokrouhlení ověřit součet proti zbývajícímu rozpočtu.

Reprodukce: [repro-domain.mjs](./repro-domain.mjs). Jistota vysoká; původní výpočet spuštěný ve VM s lokální náhradou lokalizace, bez AI promptů.

**8. [P2] Dnešní plánovaný běh se neodečte z týdenního rozpočtu**

Primární místo: [adaptive-week.js:145](../../src/adaptive-week.js#L145). Druhé místo se stejnou chybou: [entrypoint.js:727](../../src/entrypoint.js#L727).

Výpočet `runCommitted` vybírá plánované běhy jen pro `date > today`; pro dnešek bere pouze dokončené. Dosud neodběhnutý dnešní plán tedy nezapočítá. Jde o jinou chybu než minimálních dvacet minut: projeví se i při dostatečně dlouhých nových bězích, bez aktivace omezování.

Reprodukce `weekProposal()`: dnes naplánovaný Run 60 minut a dva volné budoucí běžecké dny → `committed:0`, další návrhy 30 + 30 minut, `limited:false`. Celkový týdenní plán má 120 minut proti limitu 60.

Oprava: započítat dokončené běhy a dosud nedokončené plánované běhy od dneška včetně. Při párování dokončených a plánovaných aktivit zabránit dvojímu započítání. Opravit oba výpočty a ideálně pravidlo sdílet.

Reprodukce: [repro-domain.mjs](./repro-domain.mjs). Jistota vysoká; původní výpočet spuštěný ve VM.

**9. [P2] Push kouče se nespouští bez Google/Intervals propojení**

Primární místo: [entrypoint.js:252](../../src/entrypoint.js#L252), řádky 252–259. Filtrace podle providerů: [entrypoint.js:298](../../src/entrypoint.js#L298).

Jediné plánované volání `coachPush()` je uvnitř jobu `sync`, který požaduje `google` nebo `intervals`. Uživatel s pouze WHOOP, Ultrahuman nebo Apple Health proto tento job nemá, i když má zařízení pro push, souhlasy a zapnutá oznámení kouče.

U Apple Health existuje samostatné volání ranní připravenosti při uploadu noci. To ale nevolá `coachPush()` a neposkytuje plánované opakování ranního push při přechodném selhání nebo uploadu před ranním oknem. WHOOP/Ultrahuman import ranní push sám nevolá. Účet s Google nebo Intervals tímto konkrétním filtrem postižen není.

Reprodukce nad původními definicemi jobů: pro `CONNECTED_PROVIDERS=['whoop']` se v příslušné minutě vybere pouze import WHOOP; job obsahující push se nevybere. Pro prázdný seznam, který má i Apple-Health-only účet, se nevybere žádný. Google i Intervals job `sync` mají.

Oprava: vyčlenit notifikace do samostatného jobu vybíraného podle aktivního účtu, souhlasu a registrovaného zařízení, nezávisle na konkrétním zdravotním providerovi. Zachovat existující preference a ochranu proti duplicitám.

Reprodukce: [repro-push-selection.mjs](./repro-push-selection.mjs). Jistota vysoká pro chybu plánování; doručování přes APNs nebylo testováno.

**Rozsah a výsledky kontrol**

Revize pokryla vstupní bránu Workeru, autentizaci a OAuth, správu session, oddělení účtů, shard routing, mazání a export účtu, vybrané synchronizační a retry toky, idempotenci, notifikační joby, běžecké plánování a iOS stav účtu, HealthKit, outbox a ukládání gymu. Byly přečteny i relevantní workflow pro testy, nasazení a zálohy. Nejde o tvrzení, že každá funkce aplikace byla úplně formálně ověřena.

| Kontrola | Výsledek |
|---|---|
| `npm run lint` | Prošlo; konfigurace kontroluje `no-undef`, nejde o komplexní bezpečnostní analýzu |
| `node --check` pro dostupné `src/*.js` a `scripts/*.mjs` | Prošlo |
| Standardní `npm test` | Preflight zastaví chybějící `src/private` |
| Standardní `npm run check` | Zastaví se na neexistujícím `src/private/*.js` |
| Přímé `node --test --test-reporter=tap tests/*.test.mjs` | 28 úspěšných položek z 240; 212 neúspěšných. Dominantní příčina: chybějící `src/private/lang.js`, ne 212 potvrzených chyb aplikace |
| Čtyři lokální reprodukční skripty | Potvrdily nálezy 3, 4, 5, 7, 8, 9 |
| Xcode, iOS unit/UI testy a simulátor | Nebyly dostupné; nálezy v iOS jsou ze statické analýzy |
| Produkční API, reálné účty a externí synchronizace | Nebyly volány ani měněny |

Testovací prostředí mělo Node `v24.19.0`; CI používá Node 22. Soukromé prompty nebyly získávány ani doplňovány náhradními soubory. VM reprodukce používají původní relevantní funkce s izolovanými náhradami jejich okolí; nenahrazují úplný integrační test nasazené aplikace.

V revidovaných místech jsou i užitečné ochrany: vstupní brána odmítá nepovolené anonymní endpointy, session se ověřují proti epoše uživatele, šifrování nových provider credentials je svázané s uživatelem i providerem a chybějící shard nevede k tichému fallbacku na jiné uživatelské úložiště. Tyto ochrany výše uvedené mezery v konkrétních tocích neuzavírají.

**Doporučené pořadí práce**

1. Uzavřít změnu identity v iOS před spuštěním obrazovek, outboxu a HealthKit; zavést vlastnictví místních operací podle ID účtu a serveru. Opravit nálezy 1–2 společně, se samostatnými regresními scénáři.
2. Opravit nedokončený idempotentní zápis na serveru i v klientovi tak, aby čekající data nemohla zmizet pod falešným potvrzením.
3. Svázat OAuth autorizaci s účtem a Google handoff udělat jednorázový s kontrolou epochy.
4. Opravit pořadí ukládání gymu a oba nezávislé problémy běžeckého rozpočtu.
5. Oddělit notifikační plánování od konkrétního datového provideru.
6. S dostupným soukromým repozitářem spustit plnou sadu na Node 22 a na macOS přidat a spustit výše uvedené regresní scénáře přepnutí účtu a souběžných zápisů.

**Artefakty a reprodukce**

```sh
node /workspace/aurin-review/repro-idempotency.mjs
node --experimental-vm-modules /workspace/aurin-review/repro-auth.mjs
node /workspace/aurin-review/repro-domain.mjs
node /workspace/aurin-review/repro-push-selection.mjs
```

Úplný výstup přímého spuštění testů: [tests.tap](./tests.tap).

Zdrojový kód aplikace nebyl změněn. Report a reprodukce jsou uložené mimo repozitář.
