// Original email handler and rate limiter, real local SQLite, fake delivery only.
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { webcrypto, createHmac } from 'node:crypto';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
const root = '/workspace/health-api/src';
const DB = createD1();
DB.sqlite.exec('CREATE TABLE users(id INTEGER PRIMARY KEY, email TEXT); INSERT INTO users VALUES(7,\'member@example.invalid\')');
for (const name of ['0014_passkeys_email_codes.sql', '0027_email_code_limits.sql']) DB.sqlite.exec(readFileSync('/workspace/health-api/migrations/' + name, 'utf8'));
let sent = 0;
const env = { DB, RAW_DB: DB, SESSION_SECRET: 'local-test-secret-not-real', OWNER_EMAIL: 'owner@example.invalid', EMAIL_FROM:'noreply@example.invalid', EMAIL:{send: async()=>{ sent++; return {messageId:'local-'+sent}; }} };
const doubles = {
  'dashboard-auth.js':{signText:async(value,secret)=>createHmac('sha256',secret).update(value).digest('base64url'),sessionSecret:env=>env.SESSION_SECRET,timingSafeEqualString:(a,b)=>a===b,signedInResponse:async()=>Response.json({}),userSessionCookie:async()=>''},
  'lang.js': { L:(cs,en)=>en },
  'site-pages.js':{siteLang:()=> 'en'},
  'app-review.js':{reviewCodeActive:()=>false},
  'tenancy.js':{normalizeEmail:value=>String(value||'').trim().toLowerCase(),emailCodeAccess:async()=> 'known',signInEmailUser:async()=>null,changeUserEmail:async()=>({}),bumpSessionEpoch:async()=>1}
};
const context=vm.createContext({console,crypto:webcrypto,Request,Response,Headers,URL,URLSearchParams,TextEncoder,TextDecoder,btoa,atob,Date,Uint8Array,Uint32Array});
const cache=new Map();
async function load(file){
 if(cache.has(file))return cache.get(file);
 const values=doubles[path.basename(file)];
 const m=values?new vm.SyntheticModule(Object.keys(values),function(){for(const [k,v]of Object.entries(values))this.setExport(k,v);},{context,identifier:file}):new vm.SourceTextModule(readFileSync(file,'utf8'),{context,identifier:file});
 cache.set(file,m);
 await m.link((spec,ref)=>load(path.resolve(path.dirname(ref.identifier),spec)));
 return m;
}
const m=await load(path.join(root,'email-login.js'));await m.evaluate();
const url=new URL('https://aurin.health/app/api/account/email/start');
const user={id:7,email:'member@example.invalid',isOwner:false};
const statuses=[];
for(let i=0;i<500;i++){
 const request=new Request(url,{method:'POST',headers:{Origin:url.origin,'Content-Type':'application/json','CF-Connecting-IP':'192.0.2.1'},body:JSON.stringify({email:'target-'+i+'@example.invalid'})});
 statuses.push((await m.namespace.handleEmailChange(request,env,url,{signedIn:true,user})).status);
}
assert.ok(statuses.every(s=>s===200));assert.equal(sent,500);
const budget=DB.sqlite.prepare("SELECT day_count FROM request_limits WHERE key='email-codes:day'").get().day_count;
assert.equal(budget,500);
const regular=await m.namespace.sendCode(env,'legitimate@example.invalid','en');
assert.equal(regular,false);
console.log(JSON.stringify({singleUser:user.id,requestsInSameMinute:statuses.length,successfulRequests:statuses.filter(s=>s===200).length,sentMessages:sent,globalBudgetUsed:budget,normalSigninCodeCanBeSent:regular}));
