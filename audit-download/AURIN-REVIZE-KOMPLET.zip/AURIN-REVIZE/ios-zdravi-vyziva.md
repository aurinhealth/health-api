**Dílčí audit iOS — zdraví, výživa, deník, cyklus a nastavení**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Read-only revize. Xcode a simulátor nebyly dostupné, takže nejde o runtime test uživatelského rozhraní. Uvedené nálezy jsou ověřené statickým trasováním UI → model → API.

**Potvrzené nové nálezy**

**H1 [P1] Vypnutí všech kategorií Apple Health ve skutečnosti čtení nevypne**

Místo: [AppleHealthViews.swift:118](../../ios-native/Loadwise/Screens/AppleHealthViews.swift#L118), řádky 118–127. Stavový model: [AppleHealth.swift:244](../../ios-native/Loadwise/App/AppleHealth.swift#L244), řádky 244–257.

V Nastavení → Zdroje dat → Apple Health jsou přepínače „Oprávnění“ navázané na lokální `chosen`. Přepnutí „Zapnout vše“ na vypnuto nastaví prázdnou množinu, ale `onChange` ji na řádku 119 ihned ignoruje. `health.categories`, `enabled` ani aktivní HealthKit observers se nezmění. Totéž nastane při vypnutí poslední jednotlivé kategorie. Obrazovka přitom zobrazí všechny přepínače vypnuté a žádnou chybu. Další `AppleHealth.run()` po desetiminutovém omezení stále předá do `reader.collect(categories, …)` poslední uložené kategorie a odešle data serveru. Samotné odstranění UI guardu nestačí: `AppleHealth.update()` prázdnou množinu rovněž odmítá.

Scénář: zapnout čtení Apple Health → otevřít jeho oprávnění v Aurinu → vypnout „Zapnout vše“ → nechat přijít další synchronizaci. UI tvrdí, že není vybrán žádný datový typ, ale import pokračuje s původním výběrem. Nejde o odvolání systémového HealthKit oprávnění v Nastavení iOS; nález se týká výslovného nastavení, co smí Aurin číst.

Dopad: další zpracování zdravotních dat v rozporu s viditelnou uživatelskou volbou. Priorita P1 odpovídá porušení očekávaného zastavení toku citlivých dat; četnost v produkci není měřená.

Oprava: prázdný výběr musí pozastavit import, zastavit observers a bezpečně zastavit či invalidovat rozpracovaný upload. Alternativně nesmí UI dovolit poslední typ vypnout a musí jasně nabídnout skutečné odpojení; nemůže pouze zobrazovat všechny přepínače vypnuté. Uložené prázdné kategorie se při dalším startu nesmí znovu interpretovat jako „vše“ (současný initializer na řádku 161 to tak dělá).

Regresní ověření na zařízení/simulátoru s test readerem: všechny typy on → všechny off → model.enabled/categories i další kolekce odpovídají off; zopakovat poslední jednotlivou kategorii a restart aplikace. Jistota vysoká ze statické analýzy; reálný HealthKit nebyl volán.

**H2 [P2] Deník po přepnutí dne ponechá editovatelné odpovědi předchozího dne**

Místa: [JournalViews.swift:367](../../ios-native/Loadwise/Screens/JournalViews.swift#L367), [JournalViews.swift:487](../../ios-native/Loadwise/Screens/JournalViews.swift#L487), [JournalViews.swift:506](../../ios-native/Loadwise/Screens/JournalViews.swift#L506).

`weekStrip` při výběru dne pouze změní `date`. Původní `day` zůstává v paměti a `body` ho dál vykresluje; hlavička už přitom používá nové `date`. Neexistuje podmínka `day.date == date`, loading lock ani vyčištění předchozích odpovědí. `load()` teprve čeká na nový požadavek, při chybě staré odpovědi ponechá. Během této doby jsou aktivní odpovědi, follow-upy i kontextové akce. `setAnswer()` pak sestaví POST s novým `date`, ale podle stavu položky z předchozího dne. `APIClient.saveJournalEntry()` body předá beze změny a backend skutečně zapisuje pod dodaným datem.

Scénář: otevřít pondělí s odpovědí „ano“, přepnout na úterý a zpozdit/odmítnout odpověď `/app/api/journal?date=…`. Zobrazí se úterní hlavička s pondělními odpověďmi. Klepnutí na odpověď může smazat či změnit úterní záznam podle pondělního stavu, aniž uživatel úterní hodnotu vůbec viděl. Při nedostupné síti nesoulad není jen krátká animace: přetrvává do dalšího úspěšného načtení.

Oprava: při změně data zobrazit stav stejného dne z cache, nebo starý editor odstranit a zápisy blokovat do načtení odpovědi se shodným datem. U načítání i dokončování zápisu zachytit požadované datum a při návratu ověřit, že je stále otevřené; odpověď na uložené pondělí nesmí přepsat editor úterý.

Regresní ověření: zadržet GET nového dne, ověřit nulovou možnost editace starých odpovědí; poté zadržet POST předchozího dne a přepnout den, pustit odpovědi v obráceném pořadí. Jistota vysoká ze statické analýzy; SwiftUI nebylo spuštěno.

**H3 [P3] Neúspěšné smazání receptu je v UI vydáno za odstranění**

Místo: [AddFoodSheet.swift:271](../../ios-native/Loadwise/Screens/AddFoodSheet.swift#L271), řádky 271–275.

Kontextová akce „Smazat recept“ ignoruje chybu `deleteRecipe` pomocí `try?` a poté recept vždy odstraní z místního seznamu. Při offline/500 tak položka zmizí bez hlášení, přestože na serveru zůstala. Znovuotevření nebo další zařízení ji vrátí. Tento požadavek neprochází trvalým outboxem, který by smazání později dokončil.

Oprava: místní seznam změnit až po úspěchu, případně použít optimistický stav s rollbackem a zobrazenou chybou nebo trvalý delete outbox. Regrese: odmítnout DELETE receptu a ověřit, že položka nezmizí jako úspěšně odstraněná. Jistota vysoká ze statické analýzy; dopad je omezen na nesoulad UI a uložených receptů.

Známé přenesení cyklu mezi účty je vedeno auditem jádra; backendové částečné hromadné změny jídel jsou vedené hlavním auditem. Zde nejsou započteny podruhé.

**Pokrytí**

Strojově čitelný úplný seznam této části: [ios-zdravi-vyziva-pokryti.json](./ios-zdravi-vyziva-pokryti.json). Obsahuje i související modely a testy. `detail` znamená detail implementace krátkého souboru, `flow` cílené čtení uživatelského toku, akcí a návazných API, `overview` přehled struktury/výpočtů či relevantních assertions. Žádná z těchto úrovní neznamená provedený integrační test na iOS.

| Oblast / soubory v `ios-native/Loadwise/Screens` | Hloubka | Co bylo posouzeno |
|---|---|---|
| `AppleHealthViews.swift` | detail | connect/category switches/sync, persistence původní volby, prázdný výběr |
| `FoodProductEditor.swift`, `RecipeEditorView.swift`, `PortionWheel.swift` | detail | změna produktu a porcí, kontrola množství, metadata proti nutričnímu základu, formulář receptu |
| `AddFoodSheet.swift`, `BarcodeScanSheet.swift`, `FoodEntryEditSheet.swift`, `FoodSuggestionsView.swift` | flow | hledání a cancellation, AI/OCR fallback, skener a ukládání, edit/copy/delete, owner korekce |
| `AddSheet.swift`, `FoodView.swift`, `MealDetailView.swift`, `DrinkHistoryView.swift`, `NutrientsView.swift` | flow | cílový den/jídlo, rychlé pití, editace a hromadné akce, chybové stavy, pinning živin |
| `BulkSelection.swift`, `DrinkFavorites.swift` | detail | výběr/hromadný formulář, zamykání při ukládání, oblíbené nápoje a jednotky |
| `FoodDraftCard.swift`, `FoodWeekWidget.swift` | overview | potvrzení návrhu, vynechané neznámé produkty, přehled součtů a načítání týdne |
| `JournalViews.swift`, `JournalEditor.swift`, `JournalImpact.swift` | flow | načtení dne, zápisy ano/ne/extra, fix/pinning/custom položky, přepínání dnů/metrik a chybové stavy |
| `CycleViews.swift` | flow | nastavení cyklu, day logging, pill, life stage, contraception a error handling; známý account-cache nález je veden jinde |
| `LoginView.swift`, `SetupFlowView.swift` | flow | Apple/Google/e-mail/passkey nabídka, consent a onboarding stránky, automatické předvyplnění a dokončení |
| `SettingsView.swift`, `SettingsPages/SettingsProfile.swift`, `SettingsGoals.swift`, `SettingsExperience.swift`, `SettingsHome.swift` | flow | dostupnost položek, profilové změny, sign-out/email flow, cíle/zkušenost a zapnutí deníku |
| `SettingsPages/SettingsPrivacy.swift`, `SettingsShared.swift`, `SettingsAppearance.swift`, `SettingsQuickActions.swift` | detail | export/delete/AI consent UI, save helper, jazyk/jednotky a místní rychlé akce |
| `SettingsPages/SettingsSources.swift`, `SettingsIntegrations.swift`, `SettingsConnectFlow.swift`, `SettingsSignIn.swift`, `SyncViews.swift` | flow | source priority a sync, connect/disconnect stránky, per-provider stav, passkeys a export preferences |
| `SettingsPages/SettingsAppIcon.swift` | overview | unlock a volba alternativní ikony, selhání systémového nastavení |
| `HealthView.swift`, `HealthDetails.swift`, `MetricDetails.swift` | flow | načítání, empty/error fallback, zobrazené detaily, jednotky a data správného dne |
| `RecoveryViews.swift`, `SleepPlanner.swift`, `SleepSettingsView.swift` | flow | log hotové rutiny/sauny, timer, přizpůsobení spánku, uložení času a systémový budík |
| `NotificationsSettingsView.swift` | flow | preference/přepínače, masky dní, přepočet lokálních připomínek, permission stav |
| `DayPager.swift`, `DayTimeline.swift`, `WeatherViews.swift`, `WidgetBoard.swift` | flow | day swiping/cache, interaktivní akce timeline, počasí/poloha s cancellation, editace dashboardu |
| `TodayView.swift`, `StepsDetailView.swift`, `ActiveEnergyDetailView.swift`, `StrainDetailView.swift`, `VO2maxDetailView.swift`, `Widgets.swift`, `PanelWidgets.swift` | overview | související data a navigace, vykreslovací modely/grafy; ne kompletní vizuální validace |
| `SubscriptionView.swift` | flow | status/locked state, pilotní paywall a chybové načítání; ne reálná platební transakce |
| `ReportProblemView.swift`, `SuggestFeatureView.swift` | flow/detail | příloha diagnostiky/screenshotu, zobrazení odesílaného obsahu, success/failure a demo |

Čtené relevantní testy: přehled nativních `FoodWeekTests`, `OutboxTests`, `SnapshotTests`, `LanguageTests` a backendového `journal.test.mjs`. Backend testy ověřují store/statistiku, ale nenahrazují test přepnutí dnů v nativním editoru. V této části nebyl vytvořen ani spuštěn Swift test; Xcode chybí.

**Technická a UX rizika — oddělená od výše potvrzených chyb**

- **Tiché selhání změn:** `CycleViews.swift:701,747,893`, `JournalViews.swift:313,542`, `JournalEditor.swift:210` a `NutrientsView.swift` při ukládání favorites mají `try?` bez spolehlivé viditelné chyby/rollbacku. Zvlášť contraception picker se zavírá i po neúspěchu. Jde o opakovaný vzor k sjednocení s explicitním výsledkem zápisu. H3 výše je úzce doložený případ pro smazání receptu; ostatní případy nejsou počítány jako samostatné potvrzené chyby.
- **Stará data po změně filtru:** některé read-only views (`NutrientsView`, `JournalImpactView`, `FoodSuggestionsView`) při načítání jiného rozsahu či filtru ponechají předchozí data; chybu pak někdy vykreslují jen v initial empty větvi. Doporučené je vyznačit loading/stale/error u již existujících dat. Konkrétní zápisové riziko Deníku je H2; ostatní jsou zde UX/testovací riziko.
- **Neznámý stav souhlasu:** `PrivacySettingsView` při chybě čtení `aiAllowed()` vykreslí default off a nastaví `aiLoaded=true`. Doporučuji odlišit neznámý stav od ověřeného vypnutí a nabídnout retry; backendové vynucení souhlasu je auditované odděleně.
- **Neserializované drobné změny nastavení:** například favorites živin nebo čas pilulkové připomínky spouštějí po každé změně samostatný task. Neprokazuji produkční přepsání pořadí; cílené testy s obrácenou latencí mají ověřit, že poslední uživatelská volba zůstane posledním uloženým stavem.
- **Přístupnost:** kód má explicitní labels a selected traits na řadě míst, widget reordering má VoiceOver alternativu a paywall respektuje Reduce Motion. Současně malé icon-only ovladače (např. plus/minus návrhu jídla) a složité grafy potřebují reálnou kontrolu VoiceOverem; samotný statický počet `.accessibilityLabel` neprokazuje použitelnost.
- **Jednotky a lokalizace:** převody g/ml/porce a ml/fl oz jsou oddělené od uložených metrických dat, což je vhodné. Je nutný vizuální průchod CS/EN, desetinné čárky, velkého textu, 12/24 hodin a dlouhých názvů. Statická revize nemůže prokázat, že se všechny texty vejdou na nejmenší iPhone.
- **Nákupy:** aktuální paywall je pilotní nabídka s pevnými cenovými texty; nezaměňovat jej za audit StoreKit nákupů, obnovy předplatného či App Store server notifications. Reálný transakční cyklus není tímto review potvrzený.

**Doporučené cílené ověření před vydáním**

1. Apple Health všechny kategorie off / poslední off / restart / background wake: žádná další kolekce ani upload.
2. Deník: zpožděné a selhané načtení dne, změna dne během zápisu, obrácené pořadí odpovědí a přepínání metrik.
3. Jídlo/pití/recepty: save/delete/copy s offline, timeoutem, 400, 401, 429 a 503; stálá možnost opravy a žádné falešné úspěchy.
4. Cyklus a pilulka: změny nastavení bez sítě, odmítnuté HealthKit/notification oprávnění, časová zóna a restart telefonu.
5. VoiceOver, největší text, Reduce Motion, světlý/tmavý režim, nejmenší iPhone, CS/EN a imperiální jednotky.

**Omezení**

Bez fyzického zařízení nelze potvrdit skutečnou podobu, chování VoiceOveru, pořadí SwiftUI tasků, PhotoKit/HealthKit oprávnění a dostupnost widgetů. Síťové API nebylo voláno, aplikační kód nebyl změněn.
