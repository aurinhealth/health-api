// Read-only audit harness. Original functions execute with no private prompts or network.
// Rendering/metadata dependencies unrelated to these calculations are supplied locally.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as recovery from '/workspace/health-api/src/recovery-model.js';
import { localDate, localDateTime, withTimeZone } from '/workspace/health-api/src/user-time.js';
import { sessionOf, sameSession } from '/workspace/health-api/src/activity-match.js';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';

const root = '/workspace/health-api/src/';
const read = name => readFileSync(root + name, 'utf8');
const compile = (source, deps, exports) => new Function(...Object.keys(deps), source
  .replace(/^import .*;\n/gm, '')
  .replace(/^export \{[^}]*\};?\s*$/gm, '')
  .replace(/\bexport (?=(?:async )?(?:function|const))/g, '') + '\nreturn {' + exports.join(',') + '};')(...Object.values(deps));
const sleepSettings = () => ({ goal: null });
const readiness = compile(read('readiness.js'), { ...recovery, sleepSettings, markCyclePhases: rows => rows }, ['readinessFor', 'readinessRows', 'primaryNights', 'sleepIndexFor']);
const clockOf = iso => iso ? localDateTime(iso).slice(11, 16) : null;
const minutesOf = iso => { const c = clockOf(iso); return c ? Number(c.slice(0, 2)) * 60 + Number(c.slice(3, 5)) : null; };
const dayStrain = (rows, date) => { const load = recovery.heartRateLoad(rows.find(r => r.id === date)?.hrZoneMinutes); return load == null ? null : recovery.strainScore(load); };
const tonightChoice = (settings, date, need) => ({ need, wake: {}, chosen: null, wakeOnce: false });
const common = { ...recovery, ...readiness, localDate, localDateTime, sleepSettings, tonightChoice, clockOf, minutesOf, dayStrain };
const { buildHealth } = compile(read('app-health.js'), common, ['buildHealth']);
const { clockOf: unusedClock, minutesOf: unusedMinutes, dayStrain: unusedStrain, ...todayCommon } = common;
const { buildToday } = compile(read('app-today.js'), {
  ...todayCommon, L: (cs, en) => en, environmentFor: () => ({}),
  withHeartRateLoad: training => training, daySessions: () => ({ sessions: [] }), deviceEnergyExtra: () => 0,
  recoveryToday: () => null, cycleState: () => null, askPeriodToday: () => false, cycleTrainingCaution: () => null, isHardSession: () => false
}, ['buildToday']);

const date = '2026-10-19';
const sessions = [
  { date, startTime: '2026-10-18T23:00:00Z', endTime: '2026-10-19T06:00:00Z', durationMin: 420, timeInBedMin: 420, stages: {}, nap: false },
  { date, startTime: '2026-10-19T13:00:00Z', endTime: '2026-10-19T14:00:00Z', durationMin: 60, timeInBedMin: 60, stages: {}, nap: true }
];
const health = buildHealth({ date, hour: 16, sleep: { sessions }, profile: { age: 35 } });
const today = buildToday({ date, hour: 16, sleep: { sessions }, profile: { age: 35 } });
assert.equal(health.sleep.debt.minutes, 60);
assert.equal(today.strain.target.debt, 0);
console.log(JSON.stringify({ proof: 'naps omitted from Health debt', healthDebt: health.sleep.debt.minutes, todayDebt: today.strain.target.debt }));

withTimeZone('America/New_York', () => {
  const at = '2026-10-20T01:00:00Z'; // 21:00 on 19 October locally; normal Apple Health timestamp.
  assert.equal(localDate(at), date);
  const weight = { records: [{ sample_time: at, value_numeric: 80 }] };
  const h = buildHealth({ date, weight });
  const t = buildToday({ date, weight });
  assert.equal(h.weight, null);
  assert.equal(t.weight, null);
  console.log(JSON.stringify({ proof: 'weight assigned to UTC day and hidden', at, actualLocalDate: localDate(at), requestedDate: date, healthWeight: h.weight, todayWeight: t.weight }));
});

const db = createD1(); db.userId = 7;
db.sqlite.exec(`CREATE TABLE strength_sets (user_id INTEGER, workout_date TEXT, exercise TEXT, rpe REAL, updated_at TEXT, completed INTEGER, type TEXT);
  CREATE TABLE health_datapoints (user_id INTEGER, source_family TEXT, data_type TEXT, start_time TEXT, end_time TEXT, payload_json TEXT, record_role TEXT);`);
const payload = { type: 'Ride', name: 'Long ride', start_date: '2026-10-19T08:00:00Z', start_date_local: '2026-10-19T10:00:00', moving_time: 10800, icu_training_load: 180 };
db.sqlite.prepare('INSERT INTO health_datapoints VALUES (?,?,?,?,?,?,?)').run(7, 'wahoo', 'activity', payload.start_date_local, '2026-10-19T13:00:00', JSON.stringify(payload), 'primary');
const n = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const stored = compile(read('fitness-insights.js').slice(read('fitness-insights.js').indexOf('export function storedActivities(')), { n, iso: v => String(v || '').slice(0, 10), localDate, sameSession }, ['storedActivities']);
const { loadTrainingDoses } = compile(read('muscle-fatigue.js').slice(read('muscle-fatigue.js').indexOf('export async function loadTrainingDoses(')), {
  localDate, shiftDate: (d, count) => new Date(Date.parse(d + 'T12:00:00Z') + count * 86400000).toISOString().slice(0, 10), WINDOW_DAYS: 7, HISTORY_DAYS: 28,
  dateOnly: v => String(v || '').slice(0, 10), ...stored, sessionOf, activityKind: a => /ride/i.test(a.type) ? 'ride' : null
}, ['loadTrainingDoses']);
const now = Date.parse('2026-10-19T15:00:00Z');
const missing = await loadTrainingDoses(db, { now });
assert.equal(missing.activities.length, 0);
db.sqlite.exec("UPDATE health_datapoints SET source_family='intervals'");
const seen = await loadTrainingDoses(db, { now });
assert.equal(seen.activities.length, 1);
console.log(JSON.stringify({ proof: 'same workout omitted for Wahoo but included for Intervals', wahooActivities: missing.activities.length, intervalsActivities: seen.activities.length, tss: seen.activities[0].tss }));
