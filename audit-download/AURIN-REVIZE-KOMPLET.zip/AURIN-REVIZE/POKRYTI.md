# Pokrytí auditu Aurin

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Každá uvedená úroveň má původ v dílčím reportu nebo skutečně provedené doplňující kontrole. Celkový inventář a kontrola chování jsou různé věci.

- **detail:** čtena konkrétní implementace modulu/komponenty či rizikových funkcí; ne automaticky každý vizuální řádek velkého souboru.
- **flow:** sledován konkrétní uživatelský/datový tok a související guardy/persistence.
- **overview:** přehled veřejné implementace, kontraktů, vybraných větví nebo struktury dat.
- **inventory:** pouze zařazeno; nepočítá se jako revidovaný zdroj.

Žádná z těchto úrovní neznamená automaticky provedený runtime integrační test. U datových katalogů přehled znamená strukturu/klíče, nikoli ruční odbornou validaci každého záznamu.

| Oblast | Dostupné | Revidovaný zdroj/tok | Detail | Flow | Overview | Pouze inventář |
|---|---:|---:|---:|---:|---:|---:|
| Backend JS | 236 | 236 | 43 | 76 | 117 | 0 |
| Swift včetně nativních testů | 212 | 212 | 45 | 92 | 75 | 0 |
| Servisní MJS skripty | 20 | 20 | 4 | 9 | 7 | 0 |
| GitHub workflow | 10 | 10 | 6 | 4 | 0 | 0 |
| SQL migrace a bootstrap | 33 | 33 | 0 | 0 | 33 | 0 |

Sloučený manifest má **528 unikátních cest**, včetně konfigurace a části testových zdrojů. Úrovně různých auditorů se nedvojí: pro cestu se uchovává nejvyšší doložená úroveň a všechny zdroje evidence.

**Testy:** všech240backendových testových souborů bylo zahrnuto do přímého běhu, ale chybějící soukromé moduly většinu zablokovaly ještě před provedením. Čtení selected assertions a nativních testů není prohlášení o spuštění iOS ani o100%code coverage. Viz hlavní report a uložený TAP výstup.

**Záměrně neověřené:** binární/fontové a screenshotové assety po každém pixelu, kompletní externí datasety a obsah soukromých promptů. Bez prostředí nelze potvrdit reálné API, produkční ochrany, HealthKit/BT/APNs/StoreKit ani finální rendering a VoiceOver.

**Strojově čitelné podklady:** [pokryti.csv](./pokryti.csv), [pokryti-sloucene.json](./pokryti-sloucene.json), [inventar.csv](./inventar.csv).

## Všechny kontrolované cesty

| Soubor | Hloubka | Zdroj manifestu |
|---|---|---|
| [.github/scripts/testflight_notes.py](../../.github/scripts/testflight_notes.py) | flow | provoz-pokryti.json, root-pokryti.json |
| [.github/workflows/coach-eval.yml](../../.github/workflows/coach-eval.yml) | detail | provoz-pokryti.json |
| [.github/workflows/db-backup.yml](../../.github/workflows/db-backup.yml) | detail | provoz-pokryti.json |
| [.github/workflows/deploy-worker.yml](../../.github/workflows/deploy-worker.yml) | flow | provoz-pokryti.json |
| [.github/workflows/food-micros.yml](../../.github/workflows/food-micros.yml) | detail | provoz-pokryti.json |
| [.github/workflows/health-strength-tests.yml](../../.github/workflows/health-strength-tests.yml) | detail | provoz-pokryti.json |
| [.github/workflows/ios-native.yml](../../.github/workflows/ios-native.yml) | flow | provoz-pokryti.json |
| [.github/workflows/ios-testflight.yml](../../.github/workflows/ios-testflight.yml) | flow | provoz-pokryti.json |
| [.github/workflows/site-copy.yml](../../.github/workflows/site-copy.yml) | detail | provoz-pokryti.json |
| [.github/workflows/testflight-notes.yml](../../.github/workflows/testflight-notes.yml) | detail | provoz-pokryti.json |
| [.github/workflows/vydat.yml](../../.github/workflows/vydat.yml) | flow | provoz-pokryti.json |
| [.gitignore](../../.gitignore) | detail | root-pokryti.json |
| [eslint.config.mjs](../../eslint.config.mjs) | detail | root-pokryti.json |
| [food-migrations/0001_catalog.sql](../../food-migrations/0001_catalog.sql) | overview | provoz-pokryti.json |
| [ios-native/Loadwise/App/AppModel+Cycle.swift](../../ios-native/Loadwise/App/AppModel+Cycle.swift) | detail | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/App/AppModel.swift](../../ios-native/Loadwise/App/AppModel.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/AppRoute.swift](../../ios-native/Loadwise/App/AppRoute.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/AppleHealth.swift](../../ios-native/Loadwise/App/AppleHealth.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/AppleHealthExport.swift](../../ios-native/Loadwise/App/AppleHealthExport.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/AppleHealthProfile.swift](../../ios-native/Loadwise/App/AppleHealthProfile.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/AppleWorkoutRoute.swift](../../ios-native/Loadwise/App/AppleWorkoutRoute.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/BackgroundRefresh.swift](../../ios-native/Loadwise/App/BackgroundRefresh.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/CrashReports.swift](../../ios-native/Loadwise/App/CrashReports.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/CycleHealth.swift](../../ios-native/Loadwise/App/CycleHealth.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/GymLiveActivity.swift](../../ios-native/Loadwise/App/GymLiveActivity.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/HeartRateSensor.swift](../../ios-native/Loadwise/App/HeartRateSensor.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/KeyboardDismiss.swift](../../ios-native/Loadwise/App/KeyboardDismiss.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/LiveWorkout.swift](../../ios-native/Loadwise/App/LiveWorkout.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/LoadwiseApp.swift](../../ios-native/Loadwise/App/LoadwiseApp.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/Outbox.swift](../../ios-native/Loadwise/App/Outbox.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/PushRegistration.swift](../../ios-native/Loadwise/App/PushRegistration.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/QuickActions.swift](../../ios-native/Loadwise/App/QuickActions.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/Reminders.swift](../../ios-native/Loadwise/App/Reminders.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/RootView.swift](../../ios-native/Loadwise/App/RootView.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/SettingsStore.swift](../../ios-native/Loadwise/App/SettingsStore.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/SiriShortcuts.swift](../../ios-native/Loadwise/App/SiriShortcuts.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/SystemAlarm.swift](../../ios-native/Loadwise/App/SystemAlarm.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/WatchWorkout.swift](../../ios-native/Loadwise/App/WatchWorkout.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/WidgetBridge.swift](../../ios-native/Loadwise/App/WidgetBridge.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/App/WorkoutHeartRate.swift](../../ios-native/Loadwise/App/WorkoutHeartRate.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Athlete.swift](../../ios-native/Loadwise/Data/APIClient+Athlete.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Coach.swift](../../ios-native/Loadwise/Data/APIClient+Coach.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Food.swift](../../ios-native/Loadwise/Data/APIClient+Food.swift) | flow | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json, root-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+FoodSuggestions.swift](../../ios-native/Loadwise/Data/APIClient+FoodSuggestions.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+GymPlan.swift](../../ios-native/Loadwise/Data/APIClient+GymPlan.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Push.swift](../../ios-native/Loadwise/Data/APIClient+Push.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Setup.swift](../../ios-native/Loadwise/Data/APIClient+Setup.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Subscription.swift](../../ios-native/Loadwise/Data/APIClient+Subscription.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Support.swift](../../ios-native/Loadwise/Data/APIClient+Support.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient+Training.swift](../../ios-native/Loadwise/Data/APIClient+Training.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/APIClient.swift](../../ios-native/Loadwise/Data/APIClient.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/Auth.swift](../../ios-native/Loadwise/Data/Auth.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/CalendarModels.swift](../../ios-native/Loadwise/Data/CalendarModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/CoachModels.swift](../../ios-native/Loadwise/Data/CoachModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/CycleModels.swift](../../ios-native/Loadwise/Data/CycleModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/DemoCalendar.swift](../../ios-native/Loadwise/Data/DemoCalendar.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/DemoData.swift](../../ios-native/Loadwise/Data/DemoData.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/DemoEnglish.swift](../../ios-native/Loadwise/Data/DemoEnglish.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/DemoNutrients.swift](../../ios-native/Loadwise/Data/DemoNutrients.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/ErrorLog.swift](../../ios-native/Loadwise/Data/ErrorLog.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/FoodModels.swift](../../ios-native/Loadwise/Data/FoodModels.swift) | flow | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Data/GymHistory.swift](../../ios-native/Loadwise/Data/GymHistory.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/GymIntensity.swift](../../ios-native/Loadwise/Data/GymIntensity.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/GymModels.swift](../../ios-native/Loadwise/Data/GymModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/GymSides.swift](../../ios-native/Loadwise/Data/GymSides.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/HealthModels.swift](../../ios-native/Loadwise/Data/HealthModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/JSONValue.swift](../../ios-native/Loadwise/Data/JSONValue.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/JournalModels.swift](../../ios-native/Loadwise/Data/JournalModels.swift) | flow | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Data/Models.swift](../../ios-native/Loadwise/Data/Models.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/MuscleModels.swift](../../ios-native/Loadwise/Data/MuscleModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/Passkeys.swift](../../ios-native/Loadwise/Data/Passkeys.swift) | flow | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/RecoveryModels.swift](../../ios-native/Loadwise/Data/RecoveryModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/ServerChoice.swift](../../ios-native/Loadwise/Data/ServerChoice.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/SettingsModels.swift](../../ios-native/Loadwise/Data/SettingsModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/SnapshotCache.swift](../../ios-native/Loadwise/Data/SnapshotCache.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/SyncModels.swift](../../ios-native/Loadwise/Data/SyncModels.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/TrainingModels.swift](../../ios-native/Loadwise/Data/TrainingModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/WorkoutModels.swift](../../ios-native/Loadwise/Data/WorkoutModels.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Data/WorkoutTemplates.swift](../../ios-native/Loadwise/Data/WorkoutTemplates.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Loadwise/Design/AurinMark.swift](../../ios-native/Loadwise/Design/AurinMark.swift) | overview | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/Avatar.swift](../../ios-native/Loadwise/Design/Avatar.swift) | flow | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/BodyFigure.swift](../../ios-native/Loadwise/Design/BodyFigure.swift) | overview | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/Charts.swift](../../ios-native/Loadwise/Design/Charts.swift) | flow | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/Components.swift](../../ios-native/Loadwise/Design/Components.swift) | overview | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/DrinkFigure.swift](../../ios-native/Loadwise/Design/DrinkFigure.swift) | overview | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/Format.swift](../../ios-native/Loadwise/Design/Format.swift) | flow | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/HorizontalPan.swift](../../ios-native/Loadwise/Design/HorizontalPan.swift) | detail | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/Muscle3D.swift](../../ios-native/Loadwise/Design/Muscle3D.swift) | flow | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/MuscleFigure.swift](../../ios-native/Loadwise/Design/MuscleFigure.swift) | overview | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/SettingsRows.swift](../../ios-native/Loadwise/Design/SettingsRows.swift) | overview | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/SwipeBack.swift](../../ios-native/Loadwise/Design/SwipeBack.swift) | detail | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/SwipeRow.swift](../../ios-native/Loadwise/Design/SwipeRow.swift) | detail | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/TrendChart.swift](../../ios-native/Loadwise/Design/TrendChart.swift) | flow | ios-design-pokryti.json |
| [ios-native/Loadwise/Design/Typography.swift](../../ios-native/Loadwise/Design/Typography.swift) | detail | ios-design-pokryti.json |
| [ios-native/Loadwise/Screens/ActiveEnergyDetailView.swift](../../ios-native/Loadwise/Screens/ActiveEnergyDetailView.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/ActivityEditing.swift](../../ios-native/Loadwise/Screens/ActivityEditing.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ActivityRouteMap.swift](../../ios-native/Loadwise/Screens/ActivityRouteMap.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ActivityTypeSheet.swift](../../ios-native/Loadwise/Screens/ActivityTypeSheet.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/AddFoodSheet.swift](../../ios-native/Loadwise/Screens/AddFoodSheet.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/AddSheet.swift](../../ios-native/Loadwise/Screens/AddSheet.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/AppleHealthViews.swift](../../ios-native/Loadwise/Screens/AppleHealthViews.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/AthleteStatusView.swift](../../ios-native/Loadwise/Screens/AthleteStatusView.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/AvailabilityView.swift](../../ios-native/Loadwise/Screens/AvailabilityView.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/BarcodeScanSheet.swift](../../ios-native/Loadwise/Screens/BarcodeScanSheet.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/BulkSelection.swift](../../ios-native/Loadwise/Screens/BulkSelection.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/CoachMarkdown.swift](../../ios-native/Loadwise/Screens/CoachMarkdown.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/CoachMemory.swift](../../ios-native/Loadwise/Screens/CoachMemory.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/CoachPick.swift](../../ios-native/Loadwise/Screens/CoachPick.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/CoachPlanning.swift](../../ios-native/Loadwise/Screens/CoachPlanning.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/CoachTextCard.swift](../../ios-native/Loadwise/Screens/CoachTextCard.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/CoachView.swift](../../ios-native/Loadwise/Screens/CoachView.swift) | detail | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/CycleViews.swift](../../ios-native/Loadwise/Screens/CycleViews.swift) | flow | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/DayPager.swift](../../ios-native/Loadwise/Screens/DayPager.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/DayTimeline.swift](../../ios-native/Loadwise/Screens/DayTimeline.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/DrinkFavorites.swift](../../ios-native/Loadwise/Screens/DrinkFavorites.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/DrinkHistoryView.swift](../../ios-native/Loadwise/Screens/DrinkHistoryView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/EnduranceWorkouts.swift](../../ios-native/Loadwise/Screens/EnduranceWorkouts.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/FocusSheet.swift](../../ios-native/Loadwise/Screens/FocusSheet.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/FoodDraftCard.swift](../../ios-native/Loadwise/Screens/FoodDraftCard.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/FoodEntryEditSheet.swift](../../ios-native/Loadwise/Screens/FoodEntryEditSheet.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/FoodProductEditor.swift](../../ios-native/Loadwise/Screens/FoodProductEditor.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/FoodSuggestionsView.swift](../../ios-native/Loadwise/Screens/FoodSuggestionsView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/FoodView.swift](../../ios-native/Loadwise/Screens/FoodView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/FoodWeekWidget.swift](../../ios-native/Loadwise/Screens/FoodWeekWidget.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/FormDetailView.swift](../../ios-native/Loadwise/Screens/FormDetailView.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymDayParts.swift](../../ios-native/Loadwise/Screens/GymDayParts.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymLive.swift](../../ios-native/Loadwise/Screens/GymLive.swift) | detail | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymLog.swift](../../ios-native/Loadwise/Screens/GymLog.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymPlaces.swift](../../ios-native/Loadwise/Screens/GymPlaces.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymPlanActions.swift](../../ios-native/Loadwise/Screens/GymPlanActions.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymSessionView.swift](../../ios-native/Loadwise/Screens/GymSessionView.swift) | detail | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymStretching.swift](../../ios-native/Loadwise/Screens/GymStretching.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/GymTools.swift](../../ios-native/Loadwise/Screens/GymTools.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/HealthDetails.swift](../../ios-native/Loadwise/Screens/HealthDetails.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/HealthView.swift](../../ios-native/Loadwise/Screens/HealthView.swift) | flow | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/JournalEditor.swift](../../ios-native/Loadwise/Screens/JournalEditor.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/JournalImpact.swift](../../ios-native/Loadwise/Screens/JournalImpact.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/JournalViews.swift](../../ios-native/Loadwise/Screens/JournalViews.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/LoginView.swift](../../ios-native/Loadwise/Screens/LoginView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/MealDetailView.swift](../../ios-native/Loadwise/Screens/MealDetailView.swift) | flow | ios-zdravi-vyziva-pokryti.json, root-pokryti.json |
| [ios-native/Loadwise/Screens/MetricDetails.swift](../../ios-native/Loadwise/Screens/MetricDetails.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/MuscleViews.swift](../../ios-native/Loadwise/Screens/MuscleViews.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/MyWorkouts.swift](../../ios-native/Loadwise/Screens/MyWorkouts.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/NotificationsSettingsView.swift](../../ios-native/Loadwise/Screens/NotificationsSettingsView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/NutrientsView.swift](../../ios-native/Loadwise/Screens/NutrientsView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/PanelWidgets.swift](../../ios-native/Loadwise/Screens/PanelWidgets.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/PlanEditorSheet.swift](../../ios-native/Loadwise/Screens/PlanEditorSheet.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/PlanScreens.swift](../../ios-native/Loadwise/Screens/PlanScreens.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/PlanSessionActions.swift](../../ios-native/Loadwise/Screens/PlanSessionActions.swift) | detail | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/PortionWheel.swift](../../ios-native/Loadwise/Screens/PortionWheel.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/RecipeEditorView.swift](../../ios-native/Loadwise/Screens/RecipeEditorView.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/RecordsView.swift](../../ios-native/Loadwise/Screens/RecordsView.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/RecoveryViews.swift](../../ios-native/Loadwise/Screens/RecoveryViews.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/ReportProblemView.swift](../../ios-native/Loadwise/Screens/ReportProblemView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/RoutineSettings.swift](../../ios-native/Loadwise/Screens/RoutineSettings.swift) | flow | ios-design-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsAppIcon.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsAppIcon.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsAppearance.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsAppearance.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsConnectFlow.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsConnectFlow.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsExperience.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsExperience.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsGoals.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsGoals.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsHome.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsHome.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsIntegrations.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsIntegrations.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsPrivacy.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsPrivacy.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsProfile.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsProfile.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsQuickActions.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsQuickActions.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsShared.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsShared.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsSignIn.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsSignIn.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsPages/SettingsSources.swift](../../ios-native/Loadwise/Screens/SettingsPages/SettingsSources.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SettingsView.swift](../../ios-native/Loadwise/Screens/SettingsView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SetupFlowView.swift](../../ios-native/Loadwise/Screens/SetupFlowView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/ShareCards.swift](../../ios-native/Loadwise/Screens/ShareCards.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ShareImages.swift](../../ios-native/Loadwise/Screens/ShareImages.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ShareSheet.swift](../../ios-native/Loadwise/Screens/ShareSheet.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ShareWeekMilestone.swift](../../ios-native/Loadwise/Screens/ShareWeekMilestone.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/SleepPlanner.swift](../../ios-native/Loadwise/Screens/SleepPlanner.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SleepSettingsView.swift](../../ios-native/Loadwise/Screens/SleepSettingsView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/StepsDetailView.swift](../../ios-native/Loadwise/Screens/StepsDetailView.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/StrainDetailView.swift](../../ios-native/Loadwise/Screens/StrainDetailView.swift) | overview | ios-trenink-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SubscriptionView.swift](../../ios-native/Loadwise/Screens/SubscriptionView.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SuggestFeatureView.swift](../../ios-native/Loadwise/Screens/SuggestFeatureView.swift) | detail | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/SyncViews.swift](../../ios-native/Loadwise/Screens/SyncViews.swift) | flow | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/ThresholdCheckCard.swift](../../ios-native/Loadwise/Screens/ThresholdCheckCard.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/TodayView.swift](../../ios-native/Loadwise/Screens/TodayView.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/TrainingCalendar.swift](../../ios-native/Loadwise/Screens/TrainingCalendar.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/TrainingLibrary.swift](../../ios-native/Loadwise/Screens/TrainingLibrary.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/TrainingModeParts.swift](../../ios-native/Loadwise/Screens/TrainingModeParts.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/TrainingModeView.swift](../../ios-native/Loadwise/Screens/TrainingModeView.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/TrainingPlans.swift](../../ios-native/Loadwise/Screens/TrainingPlans.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/TrainingView.swift](../../ios-native/Loadwise/Screens/TrainingView.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/VO2maxDetailView.swift](../../ios-native/Loadwise/Screens/VO2maxDetailView.swift) | overview | ios-trenink-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/WeatherViews.swift](../../ios-native/Loadwise/Screens/WeatherViews.swift) | flow | ios-trenink-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/WeekPlanView.swift](../../ios-native/Loadwise/Screens/WeekPlanView.swift) | detail | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/WidgetBoard.swift](../../ios-native/Loadwise/Screens/WidgetBoard.swift) | flow | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/Widgets.swift](../../ios-native/Loadwise/Screens/Widgets.swift) | overview | ios-zdravi-vyziva-pokryti.json |
| [ios-native/Loadwise/Screens/WorkoutDetailViews.swift](../../ios-native/Loadwise/Screens/WorkoutDetailViews.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/WorkoutMerge.swift](../../ios-native/Loadwise/Screens/WorkoutMerge.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/WorkoutProfile.swift](../../ios-native/Loadwise/Screens/WorkoutProfile.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/WorkoutRating.swift](../../ios-native/Loadwise/Screens/WorkoutRating.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/WorkoutSharing.swift](../../ios-native/Loadwise/Screens/WorkoutSharing.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ZonesDetailView.swift](../../ios-native/Loadwise/Screens/ZonesDetailView.swift) | overview | ios-trenink-pokryti.json |
| [ios-native/Loadwise/Screens/ZonesSettingsView.swift](../../ios-native/Loadwise/Screens/ZonesSettingsView.swift) | flow | ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/AppIconTests.swift](../../ios-native/LoadwiseTests/AppIconTests.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/LoadwiseTests/EnduranceTemplateTests.swift](../../ios-native/LoadwiseTests/EnduranceTemplateTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/ExerciseOrderTests.swift](../../ios-native/LoadwiseTests/ExerciseOrderTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/FoodWeekTests.swift](../../ios-native/LoadwiseTests/FoodWeekTests.swift) | overview | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/LoadwiseTests/GymCoachTests.swift](../../ios-native/LoadwiseTests/GymCoachTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/GymIntensityTests.swift](../../ios-native/LoadwiseTests/GymIntensityTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/GymLiveActivityTests.swift](../../ios-native/LoadwiseTests/GymLiveActivityTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/GymSetEditTests.swift](../../ios-native/LoadwiseTests/GymSetEditTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/LanguageTests.swift](../../ios-native/LoadwiseTests/LanguageTests.swift) | overview | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/LoadwiseTests/MuscleTests.swift](../../ios-native/LoadwiseTests/MuscleTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/OutboxTests.swift](../../ios-native/LoadwiseTests/OutboxTests.swift) | overview | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/LoadwiseTests/ShareImageTests.swift](../../ios-native/LoadwiseTests/ShareImageTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseTests/SiriShortcutsTests.swift](../../ios-native/LoadwiseTests/SiriShortcutsTests.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/LoadwiseTests/SnapshotTests.swift](../../ios-native/LoadwiseTests/SnapshotTests.swift) | overview | ios-jadro-pokryti.json, ios-zdravi-vyziva-pokryti.json |
| [ios-native/LoadwiseTests/WorkoutShareTests.swift](../../ios-native/LoadwiseTests/WorkoutShareTests.swift) | overview | ios-jadro-pokryti.json, ios-trenink-pokryti.json |
| [ios-native/LoadwiseUITests/SmokeTests.swift](../../ios-native/LoadwiseUITests/SmokeTests.swift) | overview | ios-design-pokryti.json |
| [ios-native/LoadwiseWidgets/GymActivityWidget.swift](../../ios-native/LoadwiseWidgets/GymActivityWidget.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/LoadwiseWidgets/LoadwiseWidgets.swift](../../ios-native/LoadwiseWidgets/LoadwiseWidgets.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Privacy/App/PrivacyInfo.xcprivacy](../../ios-native/Privacy/App/PrivacyInfo.xcprivacy) | overview | ios-jadro-pokryti.json |
| [ios-native/Privacy/Widgets/PrivacyInfo.xcprivacy](../../ios-native/Privacy/Widgets/PrivacyInfo.xcprivacy) | overview | ios-jadro-pokryti.json |
| [ios-native/Shared/ClockText.swift](../../ios-native/Shared/ClockText.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Shared/GymActivity.swift](../../ios-native/Shared/GymActivity.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Shared/L10n.swift](../../ios-native/Shared/L10n.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Shared/Palette.swift](../../ios-native/Shared/Palette.swift) | overview | ios-jadro-pokryti.json |
| [ios-native/Shared/QuickDrink.swift](../../ios-native/Shared/QuickDrink.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Shared/Units.swift](../../ios-native/Shared/Units.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/Shared/WidgetSnapshot.swift](../../ios-native/Shared/WidgetSnapshot.swift) | detail | ios-jadro-pokryti.json |
| [ios-native/project.yml](../../ios-native/project.yml) | overview | ios-jadro-pokryti.json |
| [migrations/0001_optimize_reads.sql](../../migrations/0001_optimize_reads.sql) | overview | provoz-pokryti.json |
| [migrations/0002_training_library.sql](../../migrations/0002_training_library.sql) | overview | provoz-pokryti.json |
| [migrations/0003_nutridatabaze.sql](../../migrations/0003_nutridatabaze.sql) | overview | provoz-pokryti.json |
| [migrations/0004_backfill_completed_strength_20261002.sql](../../migrations/0004_backfill_completed_strength_20261002.sql) | overview | provoz-pokryti.json |
| [migrations/0004_drop_food_databases.sql](../../migrations/0004_drop_food_databases.sql) | overview | provoz-pokryti.json |
| [migrations/0005_api_cache_versions.sql](../../migrations/0005_api_cache_versions.sql) | overview | provoz-pokryti.json |
| [migrations/0006_assistant_chats.sql](../../migrations/0006_assistant_chats.sql) | overview | provoz-pokryti.json |
| [migrations/0007_food_logs_status.sql](../../migrations/0007_food_logs_status.sql) | overview | provoz-pokryti.json |
| [migrations/0008_strength_sets_plan_row.sql](../../migrations/0008_strength_sets_plan_row.sql) | overview | provoz-pokryti.json |
| [migrations/0009_account_workflow.sql](../../migrations/0009_account_workflow.sql) | overview | provoz-pokryti.json |
| [migrations/0010_ai_usage.sql](../../migrations/0010_ai_usage.sql) | overview | provoz-pokryti.json |
| [migrations/0011_account_deletions.sql](../../migrations/0011_account_deletions.sql) | overview | provoz-pokryti.json |
| [migrations/0012_user_time_zone.sql](../../migrations/0012_user_time_zone.sql) | overview | provoz-pokryti.json |
| [migrations/0013_cookbook_and_consents.sql](../../migrations/0013_cookbook_and_consents.sql) | overview | provoz-pokryti.json |
| [migrations/0014_passkeys_email_codes.sql](../../migrations/0014_passkeys_email_codes.sql) | overview | provoz-pokryti.json |
| [migrations/0015_drop_unused_tables.sql](../../migrations/0015_drop_unused_tables.sql) | overview | provoz-pokryti.json |
| [migrations/0016_support_reports.sql](../../migrations/0016_support_reports.sql) | overview | provoz-pokryti.json |
| [migrations/0017_user_data_shards.sql](../../migrations/0017_user_data_shards.sql) | overview | provoz-pokryti.json |
| [migrations/0018_food_catalog_cutover.sql](../../migrations/0018_food_catalog_cutover.sql) | overview | provoz-pokryti.json |
| [migrations/0019_sync_destinations.sql](../../migrations/0019_sync_destinations.sql) | overview | provoz-pokryti.json |
| [migrations/0020_request_limits.sql](../../migrations/0020_request_limits.sql) | overview | provoz-pokryti.json |
| [migrations/0021_session_epoch.sql](../../migrations/0021_session_epoch.sql) | overview | provoz-pokryti.json |
| [migrations/0022_push_tokens.sql](../../migrations/0022_push_tokens.sql) | overview | provoz-pokryti.json |
| [migrations/0023_export_attempts.sql](../../migrations/0023_export_attempts.sql) | overview | provoz-pokryti.json |
| [migrations/0024_signup_waitlist.sql](../../migrations/0024_signup_waitlist.sql) | overview | provoz-pokryti.json |
| [migrations/0025_ops_events.sql](../../migrations/0025_ops_events.sql) | overview | provoz-pokryti.json |
| [migrations/0026_account_deletion_retries.sql](../../migrations/0026_account_deletion_retries.sql) | overview | provoz-pokryti.json |
| [migrations/0026_food_suggestions.sql](../../migrations/0026_food_suggestions.sql) | overview | provoz-pokryti.json |
| [migrations/0027_email_code_limits.sql](../../migrations/0027_email_code_limits.sql) | overview | provoz-pokryti.json |
| [migrations/0028_connection_accounts.sql](../../migrations/0028_connection_accounts.sql) | overview | provoz-pokryti.json |
| [package.json](../../package.json) | detail | root-pokryti.json |
| [public/_headers](../../public/_headers) | detail | root-pokryti.json |
| [scripts/backup-databases.mjs](../../scripts/backup-databases.mjs) | detail | provoz-pokryti.json, root-pokryti.json |
| [scripts/build-micronutrients.mjs](../../scripts/build-micronutrients.mjs) | overview | provoz-pokryti.json |
| [scripts/build-muscle-model.mjs](../../scripts/build-muscle-model.mjs) | overview | provoz-pokryti.json |
| [scripts/build-world-foods.mjs](../../scripts/build-world-foods.mjs) | overview | provoz-pokryti.json |
| [scripts/ci-summary.mjs](../../scripts/ci-summary.mjs) | detail | provoz-pokryti.json |
| [scripts/coach-eval.mjs](../../scripts/coach-eval.mjs) | flow | provoz-pokryti.json |
| [scripts/food-catalog-tools.mjs](../../scripts/food-catalog-tools.mjs) | flow | provoz-pokryti.json |
| [scripts/import-cookbook.mjs](../../scripts/import-cookbook.mjs) | flow | provoz-pokryti.json |
| [scripts/micronutrient-matches.mjs](../../scripts/micronutrient-matches.mjs) | overview | provoz-pokryti.json |
| [scripts/move-personal-rows.mjs](../../scripts/move-personal-rows.mjs) | flow | provoz-pokryti.json |
| [scripts/provision-food-catalog.mjs](../../scripts/provision-food-catalog.mjs) | flow | provoz-pokryti.json, root-pokryti.json |
| [scripts/provision-user-shards.mjs](../../scripts/provision-user-shards.mjs) | flow | provoz-pokryti.json, root-pokryti.json |
| [scripts/recovery-validation-rmcorr.mjs](../../scripts/recovery-validation-rmcorr.mjs) | flow | provoz-pokryti.json |
| [scripts/render-muscles-site.html](../../scripts/render-muscles-site.html) | overview | provoz-pokryti.json |
| [scripts/render-muscles-site.mjs](../../scripts/render-muscles-site.mjs) | overview | provoz-pokryti.json |
| [scripts/require-private-prompts.mjs](../../scripts/require-private-prompts.mjs) | detail | provoz-pokryti.json |
| [scripts/require-secrets.mjs](../../scripts/require-secrets.mjs) | detail | provoz-pokryti.json |
| [scripts/smoke-food-catalog.mjs](../../scripts/smoke-food-catalog.mjs) | flow | provoz-pokryti.json |
| [scripts/upload-muscle-model.mjs](../../scripts/upload-muscle-model.mjs) | overview | provoz-pokryti.json |
| [scripts/upload-world-foods.mjs](../../scripts/upload-world-foods.mjs) | overview | provoz-pokryti.json |
| [scripts/verify-user-shards.mjs](../../scripts/verify-user-shards.mjs) | flow | provoz-pokryti.json, root-pokryti.json |
| [src/account-data.js](../../src/account-data.js) | detail | backend-platforma-pokryti.json |
| [src/account-sync.js](../../src/account-sync.js) | flow | doplneni-pokryti.json |
| [src/activity-chat-edits.js](../../src/activity-chat-edits.js) | overview | backend-domena-pokryti.json |
| [src/activity-detail.js](../../src/activity-detail.js) | overview | backend-domena-pokryti.json |
| [src/activity-edits.js](../../src/activity-edits.js) | flow | backend-domena-pokryti.json |
| [src/activity-energy-check.js](../../src/activity-energy-check.js) | overview | backend-domena-pokryti.json |
| [src/activity-energy-choices.js](../../src/activity-energy-choices.js) | overview | backend-domena-pokryti.json |
| [src/activity-match.js](../../src/activity-match.js) | overview | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/activity-origin.js](../../src/activity-origin.js) | overview | backend-domena-pokryti.json |
| [src/activity-type.js](../../src/activity-type.js) | flow | backend-domena-pokryti.json |
| [src/adaptive-engine.js](../../src/adaptive-engine.js) | overview | backend-domena-pokryti.json |
| [src/adaptive-week.js](../../src/adaptive-week.js) | overview | backend-domena-pokryti.json |
| [src/ai-routes.js](../../src/ai-routes.js) | detail | backend-domena-pokryti.json, backend-platforma-pokryti.json |
| [src/ai-usage.js](../../src/ai-usage.js) | flow | backend-domena-pokryti.json, backend-platforma-pokryti.json |
| [src/ai-workout-compose.js](../../src/ai-workout-compose.js) | overview | backend-domena-pokryti.json |
| [src/ai-workout-pick.js](../../src/ai-workout-pick.js) | overview | backend-domena-pokryti.json |
| [src/api-cache.js](../../src/api-cache.js) | detail | backend-platforma-pokryti.json |
| [src/app-calendar.js](../../src/app-calendar.js) | overview | backend-domena-pokryti.json |
| [src/app-food-week.js](../../src/app-food-week.js) | detail | root-pokryti.json |
| [src/app-food.js](../../src/app-food.js) | detail | root-pokryti.json |
| [src/app-health.js](../../src/app-health.js) | flow | doplneni-pokryti.json |
| [src/app-milestones.js](../../src/app-milestones.js) | overview | backend-domena-pokryti.json |
| [src/app-origin.js](../../src/app-origin.js) | detail | root-pokryti.json |
| [src/app-review.js](../../src/app-review.js) | overview | doplneni-pokryti.json |
| [src/app-today.js](../../src/app-today.js) | flow | doplneni-pokryti.json |
| [src/app-training.js](../../src/app-training.js) | overview | backend-domena-pokryti.json |
| [src/app-version.js](../../src/app-version.js) | overview | doplneni-pokryti.json |
| [src/apple-app-site-association.js](../../src/apple-app-site-association.js) | overview | doplneni-pokryti.json |
| [src/apple-food.js](../../src/apple-food.js) | flow | doplneni-pokryti.json |
| [src/apple-health.js](../../src/apple-health.js) | flow | doplneni-pokryti.json |
| [src/apple-login.js](../../src/apple-login.js) | flow | backend-platforma-pokryti.json |
| [src/assistant-app-context.js](../../src/assistant-app-context.js) | overview | backend-domena-pokryti.json |
| [src/assistant-chats.js](../../src/assistant-chats.js) | overview | backend-domena-pokryti.json |
| [src/assistant-stream.js](../../src/assistant-stream.js) | overview | backend-domena-pokryti.json |
| [src/athlete-focus.js](../../src/athlete-focus.js) | overview | backend-domena-pokryti.json |
| [src/athlete-state.js](../../src/athlete-state.js) | overview | backend-domena-pokryti.json |
| [src/athlete-weight.js](../../src/athlete-weight.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/chat-ask.js](../../src/chat-ask.js) | overview | backend-domena-pokryti.json |
| [src/coach-actions.js](../../src/coach-actions.js) | flow | backend-domena-pokryti.json |
| [src/coach-allowance.js](../../src/coach-allowance.js) | detail | backend-domena-pokryti.json, backend-platforma-pokryti.json |
| [src/coach-assistant.js](../../src/coach-assistant.js) | flow | backend-domena-pokryti.json |
| [src/coach-engine.js](../../src/coach-engine.js) | overview | backend-domena-pokryti.json |
| [src/coach-eval.js](../../src/coach-eval.js) | overview | backend-domena-pokryti.json |
| [src/coach-gym-adjustment.js](../../src/coach-gym-adjustment.js) | overview | backend-domena-pokryti.json |
| [src/coach-inbox.js](../../src/coach-inbox.js) | overview | backend-domena-pokryti.json |
| [src/coach-pick.js](../../src/coach-pick.js) | overview | backend-domena-pokryti.json |
| [src/coach-push.js](../../src/coach-push.js) | overview | backend-domena-pokryti.json |
| [src/coach-reflection.js](../../src/coach-reflection.js) | overview | backend-domena-pokryti.json |
| [src/coach-review.js](../../src/coach-review.js) | overview | backend-domena-pokryti.json |
| [src/coach-ride-reviews.js](../../src/coach-ride-reviews.js) | overview | backend-domena-pokryti.json |
| [src/connect-return.js](../../src/connect-return.js) | overview | doplneni-pokryti.json |
| [src/connection-health.js](../../src/connection-health.js) | flow | doplneni-pokryti.json |
| [src/connection-secrets.js](../../src/connection-secrets.js) | flow | doplneni-pokryti.json |
| [src/connections.js](../../src/connections.js) | overview | doplneni-pokryti.json |
| [src/consent.js](../../src/consent.js) | detail | backend-platforma-pokryti.json |
| [src/cookbook.js](../../src/cookbook.js) | detail | root-pokryti.json |
| [src/cycle-model.js](../../src/cycle-model.js) | flow | doplneni-pokryti.json |
| [src/cycle-store.js](../../src/cycle-store.js) | flow | doplneni-pokryti.json |
| [src/cycling-coach-v2.js](../../src/cycling-coach-v2.js) | flow | backend-domena-pokryti.json |
| [src/cycling-workouts.js](../../src/cycling-workouts.js) | overview | backend-domena-pokryti.json |
| [src/dashboard-auth.js](../../src/dashboard-auth.js) | flow | backend-platforma-pokryti.json |
| [src/dashboard-shared.js](../../src/dashboard-shared.js) | overview | doplneni-pokryti.json |
| [src/dashboard-sync.js](../../src/dashboard-sync.js) | flow | doplneni-pokryti.json |
| [src/date-format.js](../../src/date-format.js) | overview | doplneni-pokryti.json |
| [src/design-system.js](../../src/design-system.js) | overview | doplneni-pokryti.json |
| [src/email-login.js](../../src/email-login.js) | detail | backend-platforma-pokryti.json |
| [src/email-sender.js](../../src/email-sender.js) | detail | backend-platforma-pokryti.json |
| [src/endurance-templates.js](../../src/endurance-templates.js) | detail | backend-domena-pokryti.json |
| [src/energy-budget.js](../../src/energy-budget.js) | overview | backend-domena-pokryti.json |
| [src/energy-profile.js](../../src/energy-profile.js) | overview | backend-domena-pokryti.json |
| [src/entrypoint.js](../../src/entrypoint.js) | overview | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/exercise-feedback.js](../../src/exercise-feedback.js) | overview | backend-domena-pokryti.json |
| [src/exercise-feel-en.js](../../src/exercise-feel-en.js) | overview | backend-domena-pokryti.json |
| [src/exercise-feel.js](../../src/exercise-feel.js) | overview | backend-domena-pokryti.json |
| [src/exercise-photos.js](../../src/exercise-photos.js) | overview | backend-domena-pokryti.json |
| [src/exercise-technique-data-en.js](../../src/exercise-technique-data-en.js) | overview | backend-domena-pokryti.json |
| [src/exercise-technique-data.js](../../src/exercise-technique-data.js) | overview | backend-domena-pokryti.json |
| [src/exercise-technique.js](../../src/exercise-technique.js) | overview | backend-domena-pokryti.json |
| [src/export-retry.js](../../src/export-retry.js) | flow | doplneni-pokryti.json |
| [src/fitness-insights.js](../../src/fitness-insights.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/fluids.js](../../src/fluids.js) | detail | root-pokryti.json |
| [src/food-ai.js](../../src/food-ai.js) | overview | root-pokryti.json |
| [src/food-catalog-storage.js](../../src/food-catalog-storage.js) | detail | root-pokryti.json |
| [src/food-chat.js](../../src/food-chat.js) | detail | root-pokryti.json |
| [src/food-entry-management.js](../../src/food-entry-management.js) | detail | root-pokryti.json |
| [src/food-google-sync.js](../../src/food-google-sync.js) | detail | root-pokryti.json |
| [src/food-label.js](../../src/food-label.js) | detail | root-pokryti.json |
| [src/food-log.js](../../src/food-log.js) | flow | root-pokryti.json |
| [src/food-photo.js](../../src/food-photo.js) | detail | root-pokryti.json |
| [src/food-portions.js](../../src/food-portions.js) | detail | root-pokryti.json |
| [src/food-recommend.js](../../src/food-recommend.js) | overview | root-pokryti.json |
| [src/food-sources.js](../../src/food-sources.js) | detail | root-pokryti.json |
| [src/food-suggestions.js](../../src/food-suggestions.js) | detail | root-pokryti.json |
| [src/github-oidc.js](../../src/github-oidc.js) | flow | backend-platforma-pokryti.json |
| [src/google-dashboard.js](../../src/google-dashboard.js) | flow | doplneni-pokryti.json |
| [src/google-food.js](../../src/google-food.js) | overview | doplneni-pokryti.json |
| [src/google-login.js](../../src/google-login.js) | overview | doplneni-pokryti.json |
| [src/google-oauth.js](../../src/google-oauth.js) | overview | doplneni-pokryti.json |
| [src/google-scopes.js](../../src/google-scopes.js) | overview | doplneni-pokryti.json |
| [src/gym-adjust.js](../../src/gym-adjust.js) | overview | backend-domena-pokryti.json |
| [src/gym-catalog.js](../../src/gym-catalog.js) | overview | backend-domena-pokryti.json |
| [src/gym-equipment-ai.js](../../src/gym-equipment-ai.js) | overview | backend-domena-pokryti.json |
| [src/gym-equipment.js](../../src/gym-equipment.js) | overview | backend-domena-pokryti.json |
| [src/gym-intensity.js](../../src/gym-intensity.js) | overview | backend-domena-pokryti.json |
| [src/gym-plan-store.js](../../src/gym-plan-store.js) | overview | backend-domena-pokryti.json |
| [src/gym-review.js](../../src/gym-review.js) | overview | backend-domena-pokryti.json |
| [src/gym-set-options.js](../../src/gym-set-options.js) | overview | backend-domena-pokryti.json |
| [src/gym-sides.js](../../src/gym-sides.js) | overview | backend-domena-pokryti.json |
| [src/gym-trim.js](../../src/gym-trim.js) | overview | backend-domena-pokryti.json |
| [src/health-point-json.js](../../src/health-point-json.js) | overview | doplneni-pokryti.json |
| [src/heart-rate-compaction.js](../../src/heart-rate-compaction.js) | overview | doplneni-pokryti.json |
| [src/icons.js](../../src/icons.js) | overview | doplneni-pokryti.json |
| [src/idempotency.js](../../src/idempotency.js) | overview | doplneni-pokryti.json |
| [src/illness-check.js](../../src/illness-check.js) | overview | doplneni-pokryti.json |
| [src/index.js](../../src/index.js) | flow | doplneni-pokryti.json |
| [src/internal-auth.js](../../src/internal-auth.js) | overview | doplneni-pokryti.json |
| [src/intervals-athlete.js](../../src/intervals-athlete.js) | flow | doplneni-pokryti.json |
| [src/intervals-auth.js](../../src/intervals-auth.js) | flow | doplneni-pokryti.json |
| [src/intervals-oauth.js](../../src/intervals-oauth.js) | flow | doplneni-pokryti.json |
| [src/intervals-reads.js](../../src/intervals-reads.js) | flow | doplneni-pokryti.json |
| [src/intervals-sleep.js](../../src/intervals-sleep.js) | flow | doplneni-pokryti.json |
| [src/intervals-strength.js](../../src/intervals-strength.js) | overview | doplneni-pokryti.json |
| [src/intervals-webhook.js](../../src/intervals-webhook.js) | flow | doplneni-pokryti.json |
| [src/intervals-zones.js](../../src/intervals-zones.js) | overview | doplneni-pokryti.json |
| [src/ip-rate-limit.js](../../src/ip-rate-limit.js) | detail | backend-platforma-pokryti.json |
| [src/journal-catalog.js](../../src/journal-catalog.js) | overview | doplneni-pokryti.json |
| [src/journal-impact.js](../../src/journal-impact.js) | overview | doplneni-pokryti.json |
| [src/journal-store.js](../../src/journal-store.js) | overview | ios-zdravi-vyziva-pokryti.json |
| [src/lang.js](../../src/lang.js) | overview | doplneni-pokryti.json |
| [src/library-workouts.js](../../src/library-workouts.js) | overview | backend-domena-pokryti.json |
| [src/local-workouts.js](../../src/local-workouts.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/main.js](../../src/main.js) | detail | root-pokryti.json |
| [src/manual-heart-rate.js](../../src/manual-heart-rate.js) | overview | backend-domena-pokryti.json |
| [src/manual-pairs.js](../../src/manual-pairs.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/micronutrients.js](../../src/micronutrients.js) | detail | root-pokryti.json |
| [src/morning-checkin.js](../../src/morning-checkin.js) | overview | doplneni-pokryti.json |
| [src/muscle-detail.js](../../src/muscle-detail.js) | flow | doplneni-pokryti.json |
| [src/muscle-fatigue.js](../../src/muscle-fatigue.js) | flow | doplneni-pokryti.json |
| [src/muscle-model.js](../../src/muscle-model.js) | flow | doplneni-pokryti.json |
| [src/native-connect.js](../../src/native-connect.js) | overview | doplneni-pokryti.json |
| [src/night-detail.js](../../src/night-detail.js) | flow | doplneni-pokryti.json |
| [src/nutrition-intelligence.js](../../src/nutrition-intelligence.js) | overview | root-pokryti.json |
| [src/nutrition-next.js](../../src/nutrition-next.js) | overview | root-pokryti.json |
| [src/onboarding.js](../../src/onboarding.js) | overview | backend-domena-pokryti.json, backend-platforma-pokryti.json |
| [src/ops-report.js](../../src/ops-report.js) | flow | backend-platforma-pokryti.json, provoz-pokryti.json |
| [src/own-fitness.js](../../src/own-fitness.js) | flow | doplneni-pokryti.json |
| [src/owner-only-routes.js](../../src/owner-only-routes.js) | detail | backend-platforma-pokryti.json |
| [src/passkeys.js](../../src/passkeys.js) | flow | backend-platforma-pokryti.json |
| [src/performance-trends.js](../../src/performance-trends.js) | overview | backend-domena-pokryti.json |
| [src/personal-foods.js](../../src/personal-foods.js) | detail | root-pokryti.json |
| [src/personal-recipes.js](../../src/personal-recipes.js) | detail | root-pokryti.json |
| [src/pinned-exercises.js](../../src/pinned-exercises.js) | overview | backend-domena-pokryti.json |
| [src/plan-context.js](../../src/plan-context.js) | flow | backend-domena-pokryti.json |
| [src/plan-match.js](../../src/plan-match.js) | overview | backend-domena-pokryti.json |
| [src/planned-detail.js](../../src/planned-detail.js) | flow | backend-domena-pokryti.json |
| [src/planned-events.js](../../src/planned-events.js) | flow | backend-domena-pokryti.json |
| [src/planned-workout.js](../../src/planned-workout.js) | flow | backend-domena-pokryti.json |
| [src/profile-suggestions.js](../../src/profile-suggestions.js) | overview | doplneni-pokryti.json |
| [src/push.js](../../src/push.js) | flow | backend-platforma-pokryti.json, provoz-pokryti.json |
| [src/readiness-lock.js](../../src/readiness-lock.js) | flow | doplneni-pokryti.json |
| [src/readiness.js](../../src/readiness.js) | flow | doplneni-pokryti.json |
| [src/recovery-hours.js](../../src/recovery-hours.js) | flow | doplneni-pokryti.json |
| [src/recovery-model.js](../../src/recovery-model.js) | flow | doplneni-pokryti.json |
| [src/recovery-plan.js](../../src/recovery-plan.js) | flow | doplneni-pokryti.json |
| [src/recovery-time.js](../../src/recovery-time.js) | flow | doplneni-pokryti.json |
| [src/recovery-today.js](../../src/recovery-today.js) | flow | doplneni-pokryti.json |
| [src/recovery-validation.js](../../src/recovery-validation.js) | flow | doplneni-pokryti.json |
| [src/ride-analysis.js](../../src/ride-analysis.js) | overview | backend-domena-pokryti.json |
| [src/ride-review.js](../../src/ride-review.js) | overview | backend-domena-pokryti.json |
| [src/routes-account.js](../../src/routes-account.js) | detail | backend-platforma-pokryti.json, doplneni-pokryti.json |
| [src/routes-admin.js](../../src/routes-admin.js) | detail | backend-platforma-pokryti.json |
| [src/routes-cycle.js](../../src/routes-cycle.js) | flow | doplneni-pokryti.json |
| [src/routes-food.js](../../src/routes-food.js) | detail | root-pokryti.json |
| [src/routes-gym.js](../../src/routes-gym.js) | overview | doplneni-pokryti.json |
| [src/routes-journal.js](../../src/routes-journal.js) | flow | ios-zdravi-vyziva-pokryti.json |
| [src/routes-sync.js](../../src/routes-sync.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/routes-training.js](../../src/routes-training.js) | overview | doplneni-pokryti.json |
| [src/run-review.js](../../src/run-review.js) | overview | backend-domena-pokryti.json |
| [src/running-workouts.js](../../src/running-workouts.js) | overview | backend-domena-pokryti.json |
| [src/screen-texts.js](../../src/screen-texts.js) | overview | backend-domena-pokryti.json |
| [src/session-intensity.js](../../src/session-intensity.js) | overview | backend-domena-pokryti.json |
| [src/share-milestone.js](../../src/share-milestone.js) | overview | backend-domena-pokryti.json |
| [src/share-week.js](../../src/share-week.js) | overview | backend-domena-pokryti.json |
| [src/shared-foods.js](../../src/shared-foods.js) | detail | root-pokryti.json |
| [src/site-pages.js](../../src/site-pages.js) | overview | root-pokryti.json |
| [src/sleep-sessions.js](../../src/sleep-sessions.js) | flow | doplneni-pokryti.json |
| [src/source-priority.js](../../src/source-priority.js) | overview | doplneni-pokryti.json |
| [src/staging.js](../../src/staging.js) | detail | backend-platforma-pokryti.json |
| [src/strength-balance.js](../../src/strength-balance.js) | detail | backend-domena-pokryti.json |
| [src/strength-context.js](../../src/strength-context.js) | flow | backend-domena-pokryti.json |
| [src/strength-gateway.js](../../src/strength-gateway.js) | overview | backend-domena-pokryti.json |
| [src/strength-generator.js](../../src/strength-generator.js) | flow | backend-domena-pokryti.json |
| [src/strength-history.js](../../src/strength-history.js) | flow | backend-domena-pokryti.json |
| [src/strength-intelligence.js](../../src/strength-intelligence.js) | flow | backend-domena-pokryti.json |
| [src/strength-normalization.js](../../src/strength-normalization.js) | overview | backend-domena-pokryti.json |
| [src/strength-timing.js](../../src/strength-timing.js) | detail | backend-domena-pokryti.json |
| [src/stretching.js](../../src/stretching.js) | overview | backend-domena-pokryti.json |
| [src/subscription.js](../../src/subscription.js) | detail | backend-platforma-pokryti.json |
| [src/support-report.js](../../src/support-report.js) | detail | backend-platforma-pokryti.json |
| [src/sync-destinations.js](../../src/sync-destinations.js) | flow | doplneni-pokryti.json |
| [src/tenancy.js](../../src/tenancy.js) | flow | backend-platforma-pokryti.json |
| [src/threshold-check-state.js](../../src/threshold-check-state.js) | overview | backend-domena-pokryti.json |
| [src/threshold-check.js](../../src/threshold-check.js) | overview | backend-domena-pokryti.json |
| [src/training-availability.js](../../src/training-availability.js) | overview | backend-domena-pokryti.json |
| [src/training-history.js](../../src/training-history.js) | overview | backend-domena-pokryti.json |
| [src/training-load.js](../../src/training-load.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/training-plans.js](../../src/training-plans.js) | flow | backend-domena-pokryti.json |
| [src/training-profile.js](../../src/training-profile.js) | overview | backend-domena-pokryti.json |
| [src/training-status.js](../../src/training-status.js) | overview | backend-domena-pokryti.json |
| [src/training-zones.js](../../src/training-zones.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/trend-facts.js](../../src/trend-facts.js) | overview | backend-domena-pokryti.json |
| [src/ultrahuman.js](../../src/ultrahuman.js) | flow | doplneni-pokryti.json |
| [src/user-data-routing.js](../../src/user-data-routing.js) | detail | backend-platforma-pokryti.json |
| [src/user-data-shards.js](../../src/user-data-shards.js) | detail | backend-platforma-pokryti.json |
| [src/user-jobs-entrypoint.js](../../src/user-jobs-entrypoint.js) | overview | backend-platforma-pokryti.json, provoz-pokryti.json |
| [src/user-time.js](../../src/user-time.js) | flow | doplneni-pokryti.json |
| [src/wahoo.js](../../src/wahoo.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/watch-detail.js](../../src/watch-detail.js) | overview | doplneni-pokryti.json |
| [src/watch-forward.js](../../src/watch-forward.js) | flow | doplneni-pokryti.json |
| [src/web-app-closed.js](../../src/web-app-closed.js) | detail | root-pokryti.json |
| [src/web-security.js](../../src/web-security.js) | detail | root-pokryti.json |
| [src/webauthn.js](../../src/webauthn.js) | overview | doplneni-pokryti.json |
| [src/week-ai.js](../../src/week-ai.js) | overview | backend-domena-pokryti.json |
| [src/week-planner.js](../../src/week-planner.js) | overview | backend-domena-pokryti.json |
| [src/week-revision.js](../../src/week-revision.js) | overview | backend-domena-pokryti.json |
| [src/weight-sync.js](../../src/weight-sync.js) | flow | doplneni-pokryti.json |
| [src/wellness-sync.js](../../src/wellness-sync.js) | flow | doplneni-pokryti.json |
| [src/whoop.js](../../src/whoop.js) | flow | doplneni-pokryti.json |
| [src/workload-ratio.js](../../src/workload-ratio.js) | flow | backend-domena-pokryti.json, doplneni-pokryti.json |
| [src/workout-explanation.js](../../src/workout-explanation.js) | overview | backend-domena-pokryti.json |
| [src/workout-i18n.js](../../src/workout-i18n.js) | overview | backend-domena-pokryti.json |
| [src/workout-library.js](../../src/workout-library.js) | flow | backend-domena-pokryti.json |
| [src/workout-merge.js](../../src/workout-merge.js) | overview | backend-domena-pokryti.json |
| [src/workout-model.js](../../src/workout-model.js) | detail | backend-domena-pokryti.json |
| [src/workout-templates.js](../../src/workout-templates.js) | flow | backend-domena-pokryti.json |
| [src/world-foods.js](../../src/world-foods.js) | detail | root-pokryti.json |
| [staging/schema.sql](../../staging/schema.sql) | overview | provoz-pokryti.json |
| [staging/user-data-shard.sql](../../staging/user-data-shard.sql) | overview | provoz-pokryti.json |
| [tests/account-capacity.test.mjs](../../tests/account-capacity.test.mjs) | overview | backend-platforma-pokryti.json |
| [tests/account-data.test.mjs](../../tests/account-data.test.mjs) | overview | backend-platforma-pokryti.json |
| [tests/ai-usage-parallel.test.mjs](../../tests/ai-usage-parallel.test.mjs) | overview | backend-platforma-pokryti.json |
| [tests/coach-allowance.test.mjs](../../tests/coach-allowance.test.mjs) | overview | backend-platforma-pokryti.json |
| [tests/email-change.test.mjs](../../tests/email-change.test.mjs) | overview | backend-platforma-pokryti.json |
| [tests/journal.test.mjs](../../tests/journal.test.mjs) | overview | ios-zdravi-vyziva-pokryti.json |
| [tests/support-report.test.mjs](../../tests/support-report.test.mjs) | overview | backend-platforma-pokryti.json |
| [wrangler.jsonc](../../wrangler.jsonc) | overview | root-pokryti.json |