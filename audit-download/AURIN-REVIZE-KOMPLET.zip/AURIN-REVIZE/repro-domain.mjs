// Read-only review reproduction. Executes original modules in vm wrappers.
// Only localization is supplied locally; no AI prompt module is loaded or mocked.
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { personalBaseline } from '/workspace/health-api/src/recovery-model.js';
const root='/workspace/health-api/src/';
const src=name=>readFileSync(root+name,'utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const context=vm.createContext({console, assert, personalBaseline, L:(cs,en)=>en, bilingual:(cs,en)=>en});
vm.runInContext(`const availabilityModule=(()=>{${src('training-availability.js')}\nreturn {availabilityOn,parseTimeWindow,normalizeAvailability};})();`,context);
vm.runInContext(`const {availabilityOn,parseTimeWindow,normalizeAvailability}=availabilityModule; const plannerModule=(()=>{${src('week-planner.js')}\nreturn {sanitizeWeekPlan,planWeekRoles,weekTargets,weekLoadsBefore,weeklyRunCap,capRunVolume,isRunActivity,hrvWeekTrendDown,hrvSourceRows};})();`,context);
vm.runInContext(`const {sanitizeWeekPlan,planWeekRoles,weekTargets,weekLoadsBefore,weeklyRunCap,capRunVolume,isRunActivity,hrvWeekTrendDown,hrvSourceRows}=plannerModule; const adaptiveModule=(()=>{${src('adaptive-week.js')}\nreturn {weekProposal};})();`,context);
vm.runInContext(`
const start='2026-10-19', today=start;
const training=(planned=[],completed=[])=>({planned,completed});
const dates=Array.from({length:7},(_,i)=>new Date(Date.parse(start+'T12:00:00Z')+i*86400000).toISOString().slice(0,10));
const makeWeek=first=>({days:dates.map((date,i)=>({date,daily:{training:i===0?first:training()}}))});
const prefs=sanitizeWeekPlan({days:[['run'],['run'],[],['run'],[],['run'],[]], availability:Array(7).fill({minutes:90})});
const cases=[
 ['four running days, no running history',prefs,makeWeek(training())],
 ['already completed 60 minutes today',prefs,makeWeek(training([],[{type:'Run',durationHours:1}]))],
 ['already planned 60 minutes today',{...prefs,days:[['run'],['run'],[],['run'],[],[],[]]},makeWeek(training([{type:'Run',durationHours:1}]))]
];
for(const [label,prefs,week] of cases){
 const r=adaptiveModule.weekProposal({prefs,start,today,week,history:[],state:{status:'active'}});
 const existing=week.days.reduce((sum,d)=>sum+[...d.daily.training.completed,...d.daily.training.planned].reduce((n,a)=>n+a.durationHours*60,0),0);
 const proposed=r.items.reduce((n,x)=>n+x.minutes,0);
 assert.equal(r.targets.runCap.cap,60);
 if(label==='four running days, no running history') { assert.equal(existing+proposed,80); assert.equal(r.targets.runCap.limited,true); }
 if(label==='already completed 60 minutes today') { assert.equal(r.targets.runCap.committed,60); assert.equal(existing+proposed,120); }
 if(label==='already planned 60 minutes today') { assert.equal(r.targets.runCap.committed,0); assert.equal(r.targets.runCap.limited,false); assert.equal(existing+proposed,120); }
 console.log(JSON.stringify({label,cap:r.targets.runCap,items:r.items.map(x=>({date:x.date,minutes:x.minutes})),proposed:r.items.reduce((n,x)=>n+x.minutes,0),actualWeekTotal:existing+r.items.reduce((n,x)=>n+x.minutes,0)}));
}
`,context);
