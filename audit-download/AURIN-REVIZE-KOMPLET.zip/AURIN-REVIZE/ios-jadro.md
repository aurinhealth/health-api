**Dílčí audit iOS jádra Aurin**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Read-only audit App/, Data/, Shared/ a widgetů. Zdrojový kód aplikace nebyl změněn. Xcode a iOS simulátor zde nejsou dostupné; závěry jsou ze statické analýzy. Původní nálezy importu HealthKit a outboxu při změně účtu z hlavního reportu zde nejsou počítané znovu.

**N1 [P1] Data cyklu zůstávají v modelu po běžném odhlášení a mohou se zobrazit dalšímu účtu**

Primární místo: [AppModel.swift:1413](../../ios-native/Loadwise/App/AppModel.swift#L1413), řádky 1413–1420, oproti deklaracím `cycle` a `cycleHealthSynced` na řádcích 55–60. [AppModel+Cycle.swift:9](../../ios-native/Loadwise/App/AppModel+Cycle.swift#L9) při neúspěšném požadavku pouze skončí a zachová předchozí hodnotu.

`clearLocal()` resetuje Today/Training/Health/Food/calendar, ale vůbec nemaže `cycle`, `cycleHealthSynced` ani `muscleFatigue`. Stejný `AppModel` přetrvává po odhlášení, protože ho drží aplikace jako `@State`. Proto i obyčejný logout ponechá původní `CycleResponse` v paměti. Není nutný závod s dokončováním předchozího loginu ani zachování outboxu po expiraci.

Dosažitelný scénář: A má zapnutý cyklus a načtenou poslední menstruaci nebo antikoncepci → normálně se odhlásí → přihlásí se B → Today B se načte, ale samostatný `/cycle` požadavek selže. Health pak [HealthView.swift:79](../../ios-native/Loadwise/Screens/HealthView.swift#L79) kreslí stav cyklu A. Její `.task` na řádku 92 se při nenulovém `model.cycle` o nové načtení ani nepokusí. Totéž nastavení cyklu čte na [CycleViews.swift:511](../../ios-native/Loadwise/Screens/CycleViews.swift#L511); odkazované poslední datum na řádku 585 a typ antikoncepce na řádcích 537–549 pochází ze stejného starého objektu. Task na řádku 582 také přeskakuje načtení. `HealthView` tuto sekci nepodmiňuje pohlavím profilu B, pouze starým `cycle.enabled`.

Dopad: zobrazení citlivých menstruačních a antikoncepčních informací jiné přihlášené osobě na stejném telefonu. `cycleHealthSynced=true` současně může zabránit potřebnému importu cyklu B, protože tento příznak také není svázaný s účtem.

Součást stejného nedokončeného úklidu: `Reminders.cancelAll()` odstraní naplánované notifikace, ale ne `cycle.pill` ve UserDefaults. [Reminders.swift:171](../../ios-native/Loadwise/App/Reminders.swift#L171) pak plánuje další připomínky z `storedPill()`, i pokud Today nového účtu neposkytuje cyklus. Toto je další projev stejného chybějícího oddělení cyklového stavu, nikoli další samostatně počítaný nález.

Oprava: při každé změně či ztrátě identity synchronně vymazat cyklus, jeho příznaky, odvozené připomínky i další per-account modely. Asynchronní načtení svázat s ID účtu, serverem a generací; odpověď staré generace nezveřejnit. Identitu ověřit před spuštěním automatických čtení a importů. Nepovažovat nenulový objekt bez vlastníka za doklad, že je cyklus aktuální.

Regresní scénář na macOS: naplnit cycle A včetně poslední menstruace a antikoncepce, provést běžný logout, přihlásit B se simulovaným 503 pouze na `/cycle`, otevřít Health i nastavení cyklu a zkontrolovat nulový starý stav a nulové staré pill reminders. Přidat variantu opožděné odpovědi A a variantu přepnutí serveru.

Jistota vysoká ze statického sledování stavu a UI; runtime v simulátoru zde neproběhl.

**N2 [P2] Apple Health export si přenáší preference a identitu zápisů mezi účty**

Primární místo: [AppleHealthExport.swift:23](../../ios-native/Loadwise/App/AppleHealthExport.swift#L23), řádky 23–43. Automatické použití: [AppModel.swift:681](../../ios-native/Loadwise/App/AppModel.swift#L681), pro jiný den také řádek 1277.

`AppleHealthExport` ukládá `prefs` i ledger `written` do globálních klíčů UserDefaults `appleHealth.export` a `appleHealth.written`, bez ID účtu nebo serveru. Odhlášení tyto hodnoty nemění a singleton ponechá původní `prefs` v paměti. `refreshFood()` automaticky volá `saveFoodDay()`, která se řídí lokálními preferencemi na řádku 209; obecné HealthKit write oprávnění platí pro aplikaci na telefonu, nikoli pro konkrétní Aurin účet.

Scénář: A zapne export výživy do Apple Zdraví a udělí iOS write oprávnění → provede běžný logout → přihlásí se B, který má obecný souhlas ke zdravotním datům, ale export Apple Health v Aurinu nikdy nezapnul nebo ho má na serveru vypnutý → B otevře Jídlo. Jeho denní příjem se začne zapisovat do HealthKit podle preferencí A. Kontrola serverových přepínačů se v `refreshFood()` neprovádí. Ani otevření synchronizačních nastavení stav nutně neopraví: [SyncViews.swift:41](../../ios-native/Loadwise/Screens/SyncViews.swift#L41) preferuje nenulové lokální přepínače před odlišnými serverovými.

Ledger používá klíče typu `kcal:<datum>` a stejné identifikátory [AppleHealthExport.swift:237](../../ios-native/Loadwise/App/AppleHealthExport.swift#L237), takže nerozlišuje ani vlastníka předchozích souhrnů. Doloženou chybou je spuštění exportu B bez jeho per-account zapnutí; případné fyzické nahrazení staršího souhrnu v HealthKit nebylo na zařízení měřeno. Totéž globální nastavení může ovlivnit export vážení a hotových tréninků.

Oprava: preference, ledger a identitu exportu vázat na stabilní účet a server. Po logout nebo switch dočasně export vypnout; obnovit jej až po ověření vlastníka a explicitně platných přepínačů. Rozpracovaný export musí nést neměnnou identitu/generaci a před zápisem ověřit, že stále platí. Lokální offline volba smí přebít serverovou pouze pro stejný ověřený účet, ne globálně.

Regresní ověření: preference A=nutrition ON, B=OFF, běžný logout/login a načtení Food B → žádné save volání do HKHealthStore. Opakovat při přepnutí live/staging a s rozpracovaným exportem A. Samostatně ověřit, že odpojení nebo vypnutí exportu B na druhém telefonu je reprezentováno konzistentními pravidly pro lokální preference.

Jistota vysoká ze statického trasování; HealthKit zápisy nebyly prováděny.

**Další technická rizika a úkoly k ověření — nejsou další potvrzené chyby**

- Mnohé lokální cache a singletony jsou pojmenované globálně, zatímco aplikace podporuje účty i dva servery. Příklady: PendingDrinks, workout checkpoint, gym cache a `activityDestinations`. Nálezy N1/N2 prokazují konkrétní mezery; neznamená to, že každá globální preference je chybně navržená. Je vhodné vytvořit centrální tabulku vlastnictví dat (device / account+server / session) a jednotný reset při změně identity.
- Odpovědi modelových loaderů jsou většinou chráněné volbou dne, nikoli generací účtu. Vedle již známého outbox závodu stojí za samostatný cílený test odpověď starého Today/Health po logout a přihlášení B. Bez takového testu zde nepřidávám další závod jako nový nález.
- `PendingDrinks` používá read–modify–write App Group UserDefaults, nikoli transakční frontu. Je potřeba ověřit současný widget/app proces, odběr během zápisu a chování nápoje zapsaného přes Siri při odhlášení. Pouhé nalezení sdíleného klíče není důkazem konkrétní ztráty v provozu.
- `SystemAlarm.sync()` nejprve zruší původní budíky a až po vytvoření obou nových uloží jejich ID. Potřebuje test selhání druhého schedule po úspěchu prvního, aby šel částečný výsledek bezpečně zrušit nebo obnovit; AlarmKit tady nebyl dostupný.
- `OutboxStore.save()` a `SnapshotCache.save()` polykají chyby disku přes `try?`. Pro offline zápisy je potřebný test nedostatku místa nebo odmítnutého zápisu a viditelné rozlišení uloženého záznamu od záznamu pouze v RAM. Zde nebyl simulovaný iOS filesystem.
- `APIClient` je `@unchecked Sendable`, používá sdílený cookie storage a měnitelný server. Samotná anotace není bug, ale přesun serveru/účtu během čekající operace musí pokrývat runtime testy. Swift strict concurrency je v projektu zapnuté ve Swift 5 režimu jako warnings, nikoli jako záruka nepřítomnosti závodů.
- U živého tréninku je nutné testovat stav během zamknutí telefonu, BT disconnect/reconnect, force quit a návrat po update. Kód má checkpoint, ukončení osiřelé HK session a rušení pollingu; skutečná senzorová data a všechna pořadí callbacků zde ověřená nejsou.
- Widgety a Live Activity zobrazují health údaje na domovské/zamčené obrazovce. Je potřeba projít nastavení soukromí widgetů, čitelnost, VoiceOver, jazyk a chování po zamknutí na zařízení; samotnou absenci konkrétního modifieru nepočítám jako ověřený únik.

**Pokrytí**

Strojový manifest [ios-jadro-pokryti.json](./ios-jadro-pokryti.json) obsahuje přesné cesty a úrovně: `detail` = čtena implementace menšího souboru nebo konkrétní kompletní komponenty; `flow` = trasován relevantní uživatelský/datový tok v rozsáhlém souboru; `overview` = přehled deklarací, kontraktů a vybraných částí; `inventory` = pouze inventář, bez tvrzení o revizi všech řádků. Žádná z těchto úrovní sama neznamená spuštění na iOS.

| Oblast | Skutečná kontrola |
|---|---|
| `AppModel`, `RootView`, `LoadwiseApp`, `AppRoute` | Stav účtu, logout/switch, cyklus, souběžné načítání, spuštění obrazovek a deep links; detail AppModel resetů, zbytek flow |
| `AppleHealth`, `AppleHealthExport`, `AppleHealthProfile`, `CycleHealth` | Kontrakty HealthKit import/export, account lifecycle, kategorie a souhlasy; u rozsáhlého AppleHealth jen relevantní flow |
| `APIClient`, `Auth`, `Passkeys`, API extensions | Cookie/server, timeout a HTTP chyby, request headers, auth handoff; ostatní extensions přehled kontraktů, ne úplné procházení každého endpointu |
| `Outbox`, `SnapshotCache`, `ServerChoice`, `SettingsStore`, `ErrorLog` | Offline data, persistence, základní reset a modelové vstupy; již známé chyby z hlavního reportu neopakovány |
| `BackgroundRefresh`, `PushRegistration`, `Reminders`, `SystemAlarm` | Plánování, cancellation, opětovné načítání a per-account stav; skutečné doručení/AlarmKit nejsou ověřeny |
| `SiriShortcuts`, `QuickActions`, `WidgetBridge`, `Shared/QuickDrink`, `Shared/WidgetSnapshot` | Předávání dat do systému, session gating, fronta nápojů, aktuální den a clear |
| `LiveWorkout`, `HeartRateSensor`, `GymLiveActivity`, `AppleWorkoutRoute`, `WatchWorkout`, `WorkoutHeartRate` | Tok senzorů a live workoutu, časové hodnoty a export WatchWorkout; hardware a konkrétní WorkoutKit/HealthKit API běh nebyl k dispozici |
| `Shared` jazyk, jednotky, clock a activity intents | Převody, formátování, sdílená lokální volba a vstupy tlačítek |
| `Data/*Models`, demo data, katalogové pomocné modely | Strukturální přehled typů a kontraktů. U všech čtyř Demo souborů čtena implementace výběru jazyka/dekódování/generování kalendáře a struktura vložených JSON fixtures; kompletní výpočetní a UI test všech hodnot nebyl proveden |
| Widget extension | Cílený přehled timeline/deep link/intents; bez renderingu, timeline časování v reálném systému nebo full source review kreslicích komponent |
| `project.yml`, Privacy manifests | Přehled deployment target, capabilities, background modes, strict concurrency a deklarovaných dat; entitlements se generují z project.yml a samostatné soubory v checkoutu nejsou, nejde o chybějící nasazovanou capability |
| `KeyboardDismiss.swift` | Celá implementace window/editing observerů, gestového delegáta, neblokujícího tapu a příslušenství klávesnice; `fatalError` je pouze nepoužívaný coder initializer ručně konstruovaného UIInputView, ne potvrzený běžně dosažitelný pád |

**Testy a potřebné doplnění**

Čteny byly OutboxTests, SiriShortcutsTests, LanguageTests a GymLiveActivityTests. Pokrývají například překrytí jídla/pití offline změnami, rozpoznání síťových chyb, texty Siri, jednotky a stav Live Activity. Doplněn byl skutečný přehled implementace a assertions všech zbývajících jedenácti nativních testovacích souborů:

| Soubor | Co ověřuje podle implementace assertions |
|---|---|
| `AppIconTests.swift` | Existence preview assetu, unikátní ID, počet/styl ikon a Pro odměny |
| `EnduranceTemplateTests.swift` | JSON endurance bloků, převod vzdálenosti podle prahového tempa a dekódování serverové šablony |
| `ExerciseOrderTests.swift` | Řazení podle únavy, neporušení supersetu, vložení za dokončené cviky a přesuny |
| `FoodWeekTests.swift` | Dekódování týdenních cílů/přebytku, null varianty, text rozsahu a výchozí umístění widgetu |
| `GymCoachTests.swift` | Progrese vah, nedosažené opakování, minulá session, push/pull volba, zachování rutin a časů |
| `GymIntensityTests.swift` | Písmeno intenzity a RPE, warm-up, drop sety a zaokrouhlení drop váhy |
| `GymSetEditTests.swift` | Číslování po smazání, strany, propojené drop sety, zachování dokončených dat, warm-up pořadí a výchozí místa vybavení |
| `MuscleTests.swift` | Hrubý text doby regenerace, pokrytí svalů na obrázku, pořadí demo únavy, svalový detail a widget varianty |
| `ShareImageTests.swift` | Data sdílecích karet, uchování přepínačů, rozměr 1080 px a render všech variant do PNG; týdenní/milníkové kontrakty |
| `SnapshotTests.swift` | 45 pojmenovaných test metod: dekódování prázdných i plných odpovědí, změny gym plánu, jednotky, timeline, odkazy, kalendář, metadata zátěže a zápis světle/tmavě renderovaných obrazovek do PNG |
| `WorkoutShareTests.swift` | Host a formát sdílených odkazů, odmítnutí cizího hostu/ID, přenos šablony bez vah a validace počtu opakování |

Zdroje testů tedy byly skutečně přečtené/přehledově posouzené; **nebyly zde spuštěné**. U screenshotových testů je důležité rozlišit render od vizuální regrese: helper v `SnapshotTests` ověřuje existenci PNG, ale neporovnává výsledek s referenčním obrázkem a neověřuje automaticky ořezaný text či překrytí. Tyto testy také neověřují přepnutí vlastníka modelu ani AppleHealthExport preference mezi účty. Jejich nativní spuštění a kontrola výsledných snímků patří do macOS CI.

Po doplnění původních šestnácti pouze inventarizovaných cest nemá tento dílčí manifest žádný veřejný zdrojový soubor ponechaný pouze na úrovni `inventory`: 25 `detail`, 18 `flow`, 52 `overview`. U vložených velkých fixtures znamená přehled kontrolu jejich struktury a dekódovací cesty; netvrdí ruční validaci každého ukázkového čísla. Artwork ani compiled SDK do tohoto 95cestného manifestu nepatří.

Doporučené acceptance tests před opravou/znovuvydáním: (1) A→logout→B s rozdílným cyklem a selháním `/cycle`; (2) stará odpověď A po login B; (3) export preference A ON/B OFF; (4) live/staging se dvěma účty; (5) widget nápoj a logout/souběžný odběr; (6) force quit aktivního workoutu s checkpointem; (7) ztráta sítě a opětovné doručení při změně identity; (8) zamčení telefonu/odebrané HealthKit oprávnění; (9) disk full při uložení čekajícího zápisu.

Všechny uvedené potvrzené nálezy jsou odvozené z aktuálního kódu a doložené konkrétními cestami; nepředstavují tvrzení, že byl na zařízení reprodukován každý edge case. Nebyly volány produkční endpointy ani měněna zdravotní data.
