**Dílčí audit backendu — účty, přihlášení, souhlasy, oddělení dat a limity**

Revidovaný commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Jde o read-only audit; aplikační kód ani vzdálená data nebyly měněny. Výsledkem jsou **dvě nové potvrzené chyby P2**. Devět původních nálezů z [REVIZE.md](./REVIZE.md) a tři konektorové nálezy z [platform-connectors.md](./platform-connectors.md) zde nejsou počítány znovu.

**A1 — [P2] Změna e-mailu umožní jedinému účtu vyčerpat kódy pro všechny uživatele**

Primární místo: [email-login.js:214](../../src/email-login.js#L214), řádky 214–223. Sdílený budget je čerpán na [email-login.js:114](../../src/email-login.js#L114).

`handleEmailChange()` ověřuje session, Origin a cílovou adresu, ale nepoužívá `allowClient()` ani limit podle účtu. Kód je omezen pouze podle cílové adresy a společným denním rozpočtem. Při změně cílových adres lze posílat další kódy bez minutového či hodinového omezení. Navíc se `claimAndSend()` volá s výchozím `open:false`, takže tento tok může vyčerpat i dvacetiprocentní rezervu chráněnou před běžnou otevřenou registrací.

Scénář: přihlášený běžný uživatel odešle v rychlém sledu požadavky `POST /app/api/account/email/start` na různé dosud nepoužité adresy. Při výchozím `EMAIL_CODES_PER_DAY=500` tak spotřebuje celý společný denní rozpočet. Další uživatelé už nedostanou přihlašovací kód až do resetu v UTC půlnoci. Jde současně o zneužití odesílání e-mailů. Není potřeba kontrolovat cílové schránky ani úspěšně změnit vlastní e-mail; potřeba je platné běžné přihlášení a zapnuté odesílání e-mailů.

Lokální reprodukce původního handleru, skutečného limiteru a skutečného SQLite, pouze s nahrazeným doručením e-mailu:

```json
{"singleUser":7,"requestsInSameMinute":500,"successfulRequests":500,"sentMessages":500,"globalBudgetUsed":500,"normalSigninCodeCanBeSent":false}
```

Oprava: před získáním kódu zavést atomický limit na účet i zdrojovou síť, zvlášť pro změnu adresy. Použít samostatný rozpočet pro změny adres nebo zachovat rezervu pro přihlášení tak, aby jeden účet nečerpal celý pool. Omezit počet různých rozpracovaných cílových adres a vracet odpovídající důvod 429. Změnu neřeší samotný limit na cílovou adresu.

Regresní ověření: jeden účet s jednou IP a měněnými adresami narazí na svůj limit; běžný přihlašovací kód jiného uživatele jde stále odeslat. Zkontrolovat i paralelní požadavky a více IP stejného účtu.

Reprodukce: [repro-email-change-budget.mjs](./repro-email-change-budget.mjs), spuštění `node --experimental-vm-modules /workspace/aurin-review/repro-email-change-budget.mjs`. Jistota vysoká; nebyly odeslány skutečné e-maily.

**A2 — [P2] Souběžné registrace nepřidělují poslední místo atomicky**

Primární místo: [tenancy.js:446](../../src/tenancy.js#L446), řádky 446–449. Kontrola kapacity probíhá odděleně v [tenancy.js:399](../../src/tenancy.js#L399), řádky 399–415; obdobný tok je u Google sign-in na řádcích 362–364.

`mayCreateAccount()` samostatně načte počet účtů a dostupná místa ve shardech. Teprve potom přihlašovací funkce provede `INSERT INTO users`. Dvě souběžné registrace různých adres mohou obě vidět poslední volné místo a obě vytvořit účet. Vlastní allocator shardu správně chrání kapacitu atomickým SQL, takže nepoškodí existující shard; druhý nový účet ovšem zůstane bez úložiště a jeho první chráněné API požadavky skončí `UserDataUnavailable` / 503.

Scénář: při posledním dostupném místě zároveň dokončí přihlášení dva noví uživatelé. Oba dostanou vytvořený účet; jeden funguje, druhý zůstane v chybovém stavu místo čekací listiny. Nález není tvrzením o překročení počtu uživatelů ve shardu ani přístupu k cizím datům. Týká se konzistence registrace a rezervace místa.

Lokální reprodukce původní `signInEmailUser()` a `resolveUserData()` nad SQLite:

```json
{"configuredAccountLimit":1,"configuredStoragePlaces":1,"createdAccounts":[{"id":1,"email":"a@example.invalid"},{"id":2,"email":"b@example.invalid"}],"allocations":["data-001","UserDataUnavailable"]}
```

Oprava: provést vznik účtu a rezervaci kapacity jednou atomickou operací na centrální DB, například podmíněným insertem/rezervačním řádkem v transakci. Před vydáním plné session musí být místo úspěšně rezervováno. Zohlednit obnovu po přerušení, aby rezervace neuvízla navždy; druhou adresu při prohře zařadit na waitlist. Samotný následný allocator už ochranu má a není vhodné ji odstranit.

Regresní ověření: více paralelních dokončení různých účtů při jednom volném místě vytvoří nejvýše jeden aktivní účet s route; ostatní dostanou deterministickou odpověď o kapacitě, nikoli pozdější 503. Vedle e-mailu ověřit Google a Apple cestu, které používají `mayCreateAccount()`.

Reprodukce: [repro-account-capacity-race.mjs](./repro-account-capacity-race.mjs), spuštění `node --experimental-vm-modules /workspace/aurin-review/repro-account-capacity-race.mjs`. Jistota vysoká pro závod při dosažení kapacity; četnost v provozu nebyla měřena.

**Pokrytí a další posouzení**

Označení detail znamená čtení konkrétní implementace a sledování toku, nikoli plný integrační běh všech větví. Úroveň flow označuje cílené trasování relevantních funkcí; přehled není tvrzení o úplném přečtení každé větve. Strojově čitelný manifest: [backend-platforma-pokryti.json](./backend-platforma-pokryti.json).

| Soubor | Hloubka | Posouzení |
|---|---|---|
| `src/email-login.js` | detail + runtime | E-mailové přihlášení, purpose binding kódů, jednorázové spotřebování, per-IP/per-address/global limity a změna adresy; potvrzen A1 výše |
| `src/ip-rate-limit.js` | detail + runtime v reprodukci | Atomické claims a sdílený denní budget; samotný limiter funguje, chybí jeho použití v email-change toku |
| `src/tenancy.js` | flow účtů/kapacity, přehled migrace | Vznik účtů, role, změna adresy, session epoch, atomické migrace a scoped SQL; potvrzen A2 výše |
| `src/user-data-shards.js` | detail + runtime | Fail-closed přístup ke shardu, atomická kapacita route, oddělení dat a deletion lookup |
| `src/routes-account.js` | detail | Dosažitelnost změny e-mailu, přihlášení/session, passkeys, souhlasů, exportu, smazání a subscription |
| `src/account-data.js` | detail | Streamované NDJSON, paging podle rowid, vynechání credentials; chunkované mazání, trvalý retry marker, atomické odstranění markeru s route |
| `src/consent.js` | detail | Verze souhlasu, povinný health/volitelný AI, uložení a owner výjimka |
| `src/subscription.js` | detail | Pilot versus vynucený tarif, platnost předplatného, AI consent a odmítnutí přístupu |
| `src/ai-usage.js` | přehled a cílený detail | Ceník, denní/měsíční budgety, fail-open čtení proti ochraně slotů; plný LLM tok závisí na soukromých promtech |
| `src/coach-allowance.js` | přehled a cílený detail | Týdenní limity a skupiny workout konverzací; sdílené SQL claims |
| `src/dashboard-auth.js` | flow | Podepsané cookie, origin ochrana mutací, session epoch a roční absolutní limit; původní handoff problém je již ve společném reportu |
| `src/passkeys.js` | flow | Jednorázové challenge, RP a origin, vazba userHandle, limit klíčů a revokace ostatních session; kryptografické ověření je samostatný modul mimo tento dílčí detail |
| `src/apple-login.js` | flow | JWT issuer/audience/nonce/signature, ukládání a odvolání tokenu, linkování Apple identity a vzniku účtu |
| `src/user-data-routing.js` | detail | Routing centrálních/osobních/katalogových tabulek, zákaz cross-DB join/batch, zachování hranic transakcí |
| `src/ai-routes.js` | detail | Centrální allowlist AI endpointů a návaznost na kontrolu souhlasu/tarifu |
| `src/owner-only-routes.js` | detail | Odmítnutí legacy API běžným účtům; nesoulad s veřejnou nápovědou pro odpojení Apple předán hlavnímu auditu |
| `src/routes-admin.js` | detail | Role správce, Origin, owner-only cookbook, změny e-mailů, blokace a OIDC preview automace |
| `src/support-report.js` | detail | Rozměry screenshotu/diagnostiky, escapování e-mailového obsahu, per-user scope a doručení, SELECT před insertem quota |
| `src/api-cache.js` | detail | Klíč obsahuje prostředí, shard a uživatele; fail/degraded odpovědi se neukládají, TTL a bump fallback |
| `src/staging.js` | detail | Označení testovacího serveru a výběr interních testerů |
| `src/github-oidc.js` | flow | Issuer/audience/repository IDs/main workflow/actor/event, expirace a RS256; reálná GitHub identita nevolána |
| `src/email-sender.js` | detail | Konfigurace, odesílatel, escapování obsahu a notifikace změn; reálné doručování neověřeno |
| `src/onboarding.js` | přehled | Profil, zkušenost, místa, normalizace a návaznost na účet; výpočtová doména je ve vlastním reportu |
| `src/push.js`, `src/ops-report.js`, `src/user-jobs-entrypoint.js` | přehled | Inventář notifikací, claimů a background entrypointů; specifická chyba výběru providerů už je v původním reportu |
| `tests/email-change.test.mjs`, `tests/account-capacity.test.mjs`, `tests/account-data.test.mjs`, `tests/ai-usage-parallel.test.mjs`, `tests/coach-allowance.test.mjs`, `tests/support-report.test.mjs` | cílený přehled | Relevantní assertions pro účty, limity, export a mazání; nejsou tvrzeny jako kompletně provedené testy |

**Rizika a mezery ověření — nejsou další potvrzené chyby v tomto počtu**

- Soukromý LLM tok není dostupný. Ve veřejných modulech jsou rezervace ceny běžících dotazů, atomické sloty a zvláštní týdenní limit kouče; jejich existenci nelze zaměnit za ověření skutečného konečného účtování všech modelových volání. Tabulka cen je ručně verzovaná a potřebuje provozní kontrolu vůči fakturaci.
- Část finančních čtení při chybě logu vrací nulu, zatímco získání slotu potřebuje úspěšný DB zápis. Nelze bez cíleného testu tvrdit, že běžný úplný výpadek DB dovolí neomezené čerpání AI; pro izolované poruchy čtení je vhodné testovat očekávanou politiku.
- Support report quota používá `SELECT` a pozdější `INSERT` bez atomického claimu. Paralelní odeslání může vyžadovat další ochranu; zde nebyl proveden úplný runtime uživatelský scénář, proto je bod uveden jako technické riziko, ne třetí potvrzený nález.
- Stream exportu nemá konzistentní snapshot napříč souběžnými změnami ve více databázích. Uživatelské řádky se exportují správně po stránkách, ale zálohové/forenzní požadavky na přesný okamžik by vyžadovaly jiný kontrakt. Není to automaticky chyba běžného osobního exportu.
- Po neúspěšné vzdálené revokaci provider tokenu lokální smazání účtu pokračuje a token zmizí. Je vhodné ověřit, co uživatel vidí jako `failed` a jak se zajistí následná revokace; reálné poskytovatele nebylo možné ověřit. Z lokálního smazání nelze tvrdit úspěšnou revokaci u poskytovatele.
- Změna verze souhlasu, majitelské výjimky, pilotní odemčení Pro a neaktivní billing jsou explicitní produktová nastavení. Neoznačuji je bez dalšího důkazu za bezpečnostní chyby; aktivace placení vyžaduje samostatné end-to-end ověření nákupu/obnovy/expirace.

**Užitečné ověřené vlastnosti**

Smazání účtu drží trvalý retry marker a polohu shardu do dokončení a odstraňuje je atomicky; neúspěšný shard lookup nesáhne do cizího nebo implicitního úložiště. Export je stránkovaný a neobsahuje connection credentials. Passkey challenge se spotřebuje jednorázově a vazba účtu se ověřuje před přihlášením. Správcovské mutace kontrolují roli a Origin. Tyto ochrany nejsou důkazem bezchybnosti celého systému.

**Omezení**

Soukromé `src/private` chybí; nebyly vytvářeny náhradní soubory promptů. Reprodukce načítají původní relevantní moduly do VM a nahrazují jejich okolí (lokalizaci, vzdálené doručování či nerelevantní auth pomocníky), zachovávají skutečnou SQLite logiku. Nenahrazují plnou testovací sadu ani reálné poskytovatele. Účty, provozní credentials, produkční DB ani e-mailové služby nebyly používány.
