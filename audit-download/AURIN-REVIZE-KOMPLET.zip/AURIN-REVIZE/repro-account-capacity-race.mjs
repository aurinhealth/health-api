// Original tenancy and shard allocator, real local SQLite, no services/prompts.
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
const root='/workspace/health-api/src';
const context=vm.createContext({console,Date,Number,Map,Set,WeakMap,Symbol,RegExp});
const doubles={
 'lang.js':{L:(cs,en)=>en},
 'food-catalog-storage.js':{foodCatalogEnvironment:async env=>env,FoodCatalogUnavailable:class extends Error{}}
};
const cache=new Map();
async function load(file){
 if(cache.has(file))return cache.get(file);
 const vals=doubles[path.basename(file)];
 const m=vals?new vm.SyntheticModule(Object.keys(vals),function(){for(const[k,v]of Object.entries(vals))this.setExport(k,v);},{context,identifier:file}):new vm.SourceTextModule(readFileSync(file,'utf8'),{context,identifier:file});
 cache.set(file,m);await m.link((s,r)=>load(path.resolve(path.dirname(r.identifier),s)));return m;
}
const tenancy=await load(path.join(root,'tenancy.js'));await tenancy.evaluate();
const shard=await load(path.join(root,'user-data-shards.js'));await shard.evaluate();
const DB=createD1();
DB.sqlite.exec(`CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE,name TEXT,role TEXT,disabled INTEGER DEFAULT 0,last_login_at TEXT);
 CREATE TABLE user_invites(email TEXT PRIMARY KEY);
 CREATE TABLE schema_meta(key TEXT PRIMARY KEY,value TEXT);
 INSERT INTO schema_meta VALUES('user_data_sharding_enabled','1');
 CREATE TABLE user_data_shards(shard_key TEXT PRIMARY KEY,binding_name TEXT,state TEXT,accepting_new INTEGER,max_users INTEGER,max_bytes INTEGER);
 INSERT INTO user_data_shards VALUES('data-001','USER_DATA_001','ready',1,1,7000000000);
 CREATE TABLE user_data_routes(user_id INTEGER PRIMARY KEY,shard_key TEXT);
 CREATE TABLE signup_waitlist(email TEXT PRIMARY KEY);`);
const personal=createD1();
const bound={prepare:sql=> /^SELECT version FROM user_data_shard_meta/.test(sql)?{all:async()=>({results:[{version:1}],meta:{size_after:1}})}:personal.prepare(sql)};
const env={DB,USER_DATA_001:bound,USER_DATA_ROUTING:'true',OWNER_EMAIL:'owner@example.invalid',OPEN_SIGNUP:'true',ACCOUNT_LIMIT:'1'};
const users=await Promise.all(['a@example.invalid','b@example.invalid'].map(email=>tenancy.namespace.signInEmailUser(DB,env,email)));
assert.equal(users.length,2);assert.ok(users.every(u=>u?.id));
const allocations=[];
for(const user of users){try{allocations.push((await shard.namespace.resolveUserData(env,user.id)).key);}catch(error){allocations.push(error.constructor.name);}}
assert.deepEqual(allocations,['data-001','UserDataUnavailable']);
console.log(JSON.stringify({configuredAccountLimit:1,configuredStoragePlaces:1,createdAccounts:users.map(u=>({id:u.id,email:u.email})),allocations}));
