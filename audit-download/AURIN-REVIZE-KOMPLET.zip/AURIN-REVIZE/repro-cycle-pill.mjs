// Original cycle store and model, actual local SQLite. No prompts, network or app edits.
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import * as model from '/workspace/health-api/src/cycle-model.js';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
const source=readFileSync('/workspace/health-api/src/cycle-store.js','utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const store=new Function('normalizeCycleSettings','normalizeCycleDay','SYMPTOMS','L',source+'\nreturn {saveCycleDay,listCycleDays};')(model.normalizeCycleSettings,model.normalizeCycleDay,model.SYMPTOMS,(cs,en)=>en);
const db=createD1();db.userId=7;
const saved=await store.saveCycleDay(db,{date:'2026-10-19',pill:true});
const raw=db.sqlite.prepare('SELECT pill FROM cycle_days WHERE user_id=7').get().pill;
const days=await store.listCycleDays(db,'2026-10-01','2026-10-31');
const settings={enabled:true,contraception:'pill',packStart:'2026-10-01'};
const month=model.cycleMonth({settings,days,today:'2026-10-20'},'2026-10');
const displayed=month.find(d=>d.date==='2026-10-19').pill;
assert.equal(raw,'taken');assert.equal(saved.pill,null);assert.equal(days[0].pill,null);assert.equal(displayed,'planned');
console.log(JSON.stringify({input:true,stored:raw,response:saved.pill,loaded:days[0].pill,calendar:displayed}));
