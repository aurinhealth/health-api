**Dílčí audit: backendové konektory a synchronizace**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Čtena pravidla `CLAUDE.md` a původní report `REVIZE.md`; jeho devět nálezů zde neopakuji. Zdrojové soubory aplikace ani vzdálená data nebyly změněny.

**Nové potvrzené nálezy**

**C1 — [P2] Export aktivity do Google zaměňuje rozpracovanou operaci za uložený záznam.** Primární místo [sync-destinations.js:263](../../src/sync-destinations.js#L263), řádky263–271, označení `sent` v řádku300.

`pushGoogle` přijme `name:'operations/…',done:false`, uloží operation name jako `remote_id` a `deliver` ihned označí export jako `sent`. Operaci nikdy nedotáže. Při dalším odeslání stejného klíče nesplní operation name regex `GOOGLE_EXERCISE`, proto přijde nový POST namísto PATCH původního záznamu. Pokud první operace uspěje, opakované dokončení/editace vytvoří další aktivitu; pokud selže, UI přesto ukazovalo „odesláno“ bez následné kontroly.

Dosažitelnost: `POST /app/api/sync/activity`, [routes-sync.js:27](../../src/routes-sync.js#L27). iOS `shareGym` používá stálý klíč `gym:<datum>` právě proto, aby opakované dokončení upravilo stejnou aktivitu ([AppModel.swift:933](../../ios-native/Loadwise/App/AppModel.swift#L933)); poté volá `api.sendActivity` na řádku954. Nutné je propojení Google, extra scope pro zápis aktivit a zapnuté `pushActivities`.

Runtime důkaz: [repro-google-exercise-operation.mjs](./repro-google-exercise-operation.mjs), původní synchronizační funkce, skutečné lokální SQLite a simulovaná síť: první výsledek `sent,remoteId:operations/exercise-1`, druhý stejný key změněných minut `sent,remoteId:operations/exercise-2`, oba požadavky POST na `/exercise/dataPoints`, žádný polling/PATCH. Podporovanou formu dlouhé operace potvrzuje vlastní komentář v kódu; odpovídající food export má polling a oddělený operation state v [food-google-sync.js:86](../../src/food-google-sync.js#L86), řádky86–109. Existující `tests/sync-destinations.test.mjs:147–161` pokrývá pouze synchronní odpověď s přímým resource name.

Oprava: uchovat operation name odděleně, stav pending/operation a polling až do `done`; teprve pak uložit skutečný resource name. Následné revize čekají a použijí PATCH. Testovat operaci pending→success, pending→error a změnu během operace. Jistota vysoká pro chování kódu při této podporované odpovědi; reálná Google API nebyla volána a četnost LRO u exercise není změřená.

**C2 — [P2] Smazaná aktivita z Intervals zůstává v aplikaci i po webhooku o smazání.** Primární místo [index.js:1199](../../src/index.js#L1199), řádky1199–1212, celá funkce `syncIntervalsActivities` začíná na1135. Webhook mapování [intervals-webhook.js:17](../../src/intervals-webhook.js#L17).

Import aktivit provádí pouze upserty aktuálního seznamu, bez odstranění dříve importovaných aktivit, které v kompletní odpovědi chybějí. `ACTIVITY_DELETED` pouze vyvolá tento import (`entrypoint.js:231–237`), ID smazané aktivity nepředá a žádná jiná větev ji nesmaže. Pro plánované události je naopak v `syncIntervalsEvents` implementované atomické nahrazení okna.

Scénář: nedávná aktivita se úspěšně importuje; uživatel ji odstraní přímo v Intervals; webhook a následný Refresh vrátí aktuální seznam bez ní. Starý `health_datapoints` řádek zůstane a dál může vstupovat do kalendáře, zátěže a výživy. Týká se i úplného importu s ročním oknem, nejen webhooku.

Runtime důkaz: [repro-intervals-deleted-activity.mjs](./repro-intervals-deleted-activity.mjs), původní funkce se skutečným SQLite a simulovaným kompletním prázdným provider listem; výstup `activities_found:0,activities_saved:0,retainedDeletedActivityRows:1`.

Oprava: přenášet do background práce konkrétní deleted ID nebo bezpečně rekonciliovat kompletní úspěšně načtené okno. Mazání provést až po ověření úplné odpovědi; zachovat app-owned/exportované kopie a obnovit primární roli případných spárovaných watch aktivit. Jistota vysoká; runtime důkaz funkce a statické trasování webhooku.

**C3 — [P2] Prázdné čtení výživy z HealthKit hromadně smaže importované jídlo a pití.** Primární místo [apple-food.js:127](../../src/apple-food.js#L127), řádky127–128, a141–142; přijetí úplnosti na řádku92.

`saveAppleFood` považuje přítomné prázdné pole za kompletní okno. Všechny dosavadní importované záznamy příslušného source v okně odstraní. Nativní `foodUpload` vrací `meals:[]`/`drinks:[]` i při prázdném čtení, pokud je kategorie zvolena ([AppleHealth.swift:689](../../ios-native/Loadwise/App/AppleHealth.swift#L689), návrat na730). HealthKit nemusí po odnětí oprávnění nebo obnově dat vracet chybu; prázdný výsledek není důkaz smazání. U workout/sleep backend již takové prázdné čtení chrání (`apple-health.js`), u jídla ne.

Runtime backend důkaz: [repro-apple-food-empty.mjs](./repro-apple-food-empty.mjs) s původní funkcí a skutečným SQLite: uložené jedno importované jídlo a jedno pití → upload stejných dnů s `meals:[],drinks:[]` → `removed:2`, oba stoly prázdné pro tyto řádky. Nativní část je staticky potvrzena; odnětí oprávnění nebylo spuštěno na zařízení.

Oprava: pro destruktivní synchronizaci používat explicitní HealthKit deleted object IDs/anchored queries a příznak úplnosti čtení; odmítnuté či neúplné čtení nesmí být deletion window. Dočasnou ochranu prázdných/hromadně mizejících oken sladit s workouts/sleep. Jistota vysoká pro backend a návaznost formátu; zařízení nebylo k dispozici. Tento nález koordinovat s nativním auditem a nepočítat ho dvakrát.

**Přehled pokrytí**

Hloubka „tok/detail“ znamená čtení implementace a sledování příslušného ukládání/volání; ne kompletní runtime integraci. „Přehled“ znamená cílené čtení relevantních částí, nikoli celého souboru.

| Soubory v `src/` | Hloubka | Předmět |
|---|---|---|
| `account-sync.js`, `dashboard-sync.js` | tok/detail | orchestrace, claims, dokončení a partial stavy |
| `connection-health.js`, `connection-secrets.js` | tok/detail | rozpoznání odmítnutí, refresh lease, AAD, účet/webhook index |
| `intervals-auth.js`, `intervals-oauth.js`, `intervals-reads.js`, `intervals-webhook.js` | tok/detail | OAuth, invalidace a cache, webhook dispatch |
| `intervals-athlete.js`, `intervals-sleep.js` | tok/detail | profil/zóny a doplnění chybějících nocí |
| `google-dashboard.js` | tok/detail | zdrojové metriky, denní a hodinové agregace |
| `whoop.js`, `ultrahuman.js` | tok/detail | tokeny, stránkování/denní import, normalizace a disconnect |
| `wahoo.js` | tok/detail | import, webhook a export local plans, retry/disconnect; sestavení kroků plánu pouze přehled |
| `apple-health.js` | tok/detail | validace, upsert, deletion windows, source replacement, status |
| `apple-food.js` | tok/detail | import jídla/pití, cross-provider dedupe, hiding a deletion windows |
| `sync-destinations.js`, `local-workouts.js`, `export-retry.js` | tok/detail | preferences, exports, remote identity, leases/revisions/retry |
| `weight-sync.js`, `wellness-sync.js`, `watch-forward.js`, `manual-pairs.js` | tok/detail | ledgery, preference, pravidla předávání a párování |
| `routes-sync.js` | tok/detail | dosažitelnost exportů a retry |
| `index.js` | přehled + detail1135–1320 | entry routing, seznam importních funkcí, kompletní activities/events/Intervals import |
| `entrypoint.js` | přehled | dispatch webhooků, jejich per-user scope; ne celá doménová logika |
| `routes-account.js` | přehled | account export/delete/reconnect návaznost |
| `google-scopes.js` | přehled | aktuální permissions a extra activity write scope |
| iOS `AppModel.swift`, `SyncModels.swift`, `AppleHealth.swift` | cílený tok | dosažitelnost opakovaných gym exportů a food window formátu |

Čtené testy: `tests/sync-destinations.test.mjs` (normalizace, preference, úspěšné a nejisté exporty); `tests/intervals-import.test.mjs` (cíleně import/retry a partial); v `tests/wahoo.test.mjs` pouze přehled souvisejících export scénářů. Ostatní testy connectorů byly pouze inventarizované, nikoli kompletně vyhodnocené. Standardní suite zde bez `src/private` není spustitelná; reprodukce ji nenahrazují.

**Další rizika a mezery ověření — nejsou další potvrzené chyby**

- Exportní `deliver` pro hotové aktivity nemá vlastní atomický claim. Dva současné ruční/cron požadavky mohou oba dojít k vytvoření remote aktivity. Úplný uživatelský scénář a deduplikace poskytovatele nebyly ověřeny; do potvrzených nálezů nezahrnovat.
- Refresh lease po vypršení patience připouští refresh bez získaného lease; chrání běžný souběh, nikoli všechny pomalé/mezní případy. Nutný cílený multi-isolate test proti rotujícím refresh tokenům, zde bez potvrzeného incidentu.
- WHOOP, Wahoo a Ultrahuman importy upsertují; průběžné odstranění již importovaných provider dat obecně vyžaduje testy. Nález C2 je úzce potvrzený pro Intervals s existujícím deleted webhookem; ostatní providery tím automaticky neoznačuji za vadné.
- Wahoo první export používá dvoukrokové vytvoření plánu a workoutu; zotavení po ztracené odpovědi od create vyžaduje test se skutečnou API idempotencí. Současný kód část remote identity uchovává průběžně.
- Stav `readSyncPrefs` při DB chybě vrací defaults. U preference pro odesílání citlivých dat stojí za zvážení odmítnout export při neznámém stavu; souběh se skutečnou DB chybou a uloženým opt-out zde nebyl reprodukován.
- Reálné API kontrakty, rate limits, push a kompletní importní cyklus nad skutečným účtem nebyly ověřeny. Všechna runtime ověření byla lokální, bez sítě.

**Ověřené užitečné vlastnosti**

Local workouts ukládají plán do vlastního úložiště dříve než remote export a u exportu sledují revision. Import Intervals weights běží odděleně od activities/calendar, takže jedno odmítnutí neztratí vše. Wellness sync respektuje typy povolené uživatelem, nepřepisuje cizí hodnoty Intervals bez ledgeru a vynechává WHOOP/Ultrahuman sleep při předávání. Apple workouts/sleep deletion mají ochrany prázdných a rozsáhle částečných oken. Tyto vlastnosti nejsou důkazem bezchybnosti všech konektorů.
