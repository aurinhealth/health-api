**Dokončení pokrytí veřejného backendu a servisních souborů**

Audit commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Toto doplnění nemění aplikaci. Původní JSON manifesty byly sloučeny, explicitně popsané skutečné průchody z `backend-recovery.md`, `platform-connectors.md` a `provoz.md` byly převedeny do manifestů a zbývajících 33 backendových modulů bylo skutečně dočteno alespoň přehledově. Samotný seznam souborů nebyl započítán jako četba.

Výsledný manifest [pokryti-sloucene.json](./pokryti-sloucene.json) obsahuje původ evidence a nejvyšší doloženou hloubku pro každý soubor. Veřejný backend `src/*.js` má **236/236 souborů alespoň přehledově pokrytých**: 43 `detail`, 76 `flow`, 117 `overview`. Tyto úrovně nejsou tvrzením, že ve všech souborech proběhl stejný počet scénářů nebo že je každý řádek bez vady. `flow` dokládá průchod konkrétním tokem; `overview` čtení architektury, funkcí a kontraktů bez úplného ověření všech větví. Soukromé prompty a reálné externí systémy nejsou tímto číslem zahrnuté.

**Jeden nový potvrzený nález — [P2] Označení dříve užité antikoncepční pilulky se po uložení ztratí z pohledu aplikace**

Místo: [cycle-model.js:79](../../src/cycle-model.js#L79), [cycle-store.js:43](../../src/cycle-store.js#L43), [cycle-store.js:71](../../src/cycle-store.js#L71). Dosažitelný vstup je potvrzený také na [CycleViews.swift:359](../../ios-native/Loadwise/Screens/CycleViews.swift#L359): pro minulý den UI posílá `pill:true`, pro dnešek čas `HH:MM`.

`saveCycleDay` převede `true` na kanonický řetězec `"taken"` a uloží ho do SQLite. Následný `dayOf` však znovu volá `normalizeCycleDay`, které přijímá pouze boolean `true` nebo čas `HH:MM`. Vlastní uloženou hodnotu `"taken"` převede na `null`. Stejné se stane při dalším načtení. Kalendář následně zobrazuje pilulku jako plánovanou, přestože ji uživatelka označila jako užitou. Fyzický řetězec v databázi zůstává; chyba je v jeho čtení a prezentaci. Netýká se větve s platným časem `HH:MM`.

Lokální reprodukce [repro-cycle-pill.mjs](./repro-cycle-pill.mjs) používá původní čistý model a původní store s lokální překladovou funkcí, skutečné SQLite přes existující testovací D1 fasádu a nevolá síť. Pro `2026-10-19`, dnešek `2026-10-20` a aktivní tabletový blistr vrací:

```json
{"input":true,"stored":"taken","response":null,"loaded":null,"calendar":"planned"}
```

Oprava: přijmout a zachovat kanonické `"taken"` při normalizaci a sjednotit normalizaci zápisu se čtením. Přidat regresi idempotence normalizátoru a skutečného `save → list → calendar` pro boolean `true`, řetězec `"taken"`, čas `HH:MM` a vymazání. Opravená verze musí pro první tři vstupy zachovat užití i po znovuotevření; vymazání musí nadále fungovat. Oprava nebyla součástí zadání auditu provedena.

**Skutečně doplněná četba**

| Oblast | Dočtené moduly | Hloubka a rozsah |
|---|---|---|
| Cyklus | `routes-cycle.js`, `cycle-store.js`, `cycle-model.js` | flow nastavení, záznamu dne, načtení a kalendáře; lokální SQLite reprodukce výše |
| Deník | `journal-catalog.js`, `journal-impact.js` | overview definic, validace, metrik, porovnání následujících rán, minimálních vzorků a vyloučených dnů |
| Společné helpery | `source-priority.js`, `lang.js`, `date-format.js`, `icons.js`, `dashboard-shared.js`, `design-system.js`, `health-point-json.js` | overview kontraktů, priority a seskupení zdrojů, formátů a lokalizace |
| WebAuthn | `webauthn.js` | overview CBOR/COSE a kontroly challenge, origin, RP, flags, signCount a podpisu; bez formálního kryptografického auditu |
| Přihlášení a konektory | `app-review.js`, `app-version.js`, `apple-app-site-association.js`, `connect-return.js`, `connections.js`, `google-login.js`, `google-oauth.js`, `native-connect.js`, `internal-auth.js` | overview přístupových a návratových kontraktů, ticketu, statusu a interního tokenu; bez providerů |
| Jídla a opakování zápisu | `google-food.js`, `idempotency.js` | overview importu, deduplikace a souběžného požadavku; známý souběhový problém idempotence je v hlavním auditu |
| Profil a datové helpery | `profile-suggestions.js`, `heart-rate-compaction.js`, `intervals-strength.js`, `intervals-zones.js` | overview profilu, tepových bucketů, formátu událostí a nastavení zón |
| Denní stav a trénink | `morning-checkin.js`, `illness-check.js`, `watch-detail.js`, `routes-training.js`, `routes-gym.js` | overview kontraktů, čtení a zápisů; podrobné scénáře domény jsou v dalších reportech |

Deníkové korelace nebyly klinicky validovány. Čtení kryptografického modulu neprokazuje absenci všech implementačních útoků. Externí exporty, push, App Store Connect a provozní doručení nebyly spuštěny. V tomto doplnění nepřibyly další potvrzené vady.

**Původ a rozsah servisního manifestu**

[doplneni-pokryti.json](./doplneni-pokryti.json) obsahuje 84 unikátních cest: explicitní existující průchody recovery/konektorů a výše uvedených 33 dočtených modulů. [provoz-pokryti.json](./provoz-pokryti.json) obsahuje 68 cest doložených tabulkami a závěrečným přehledem skutečné četby v [provoz.md](./provoz.md): všech 10 workflow, 20 `.mjs` skriptů a renderovací HTML, TestFlight Python, 30 migrací, tři SQL bootstrapy a tři provozní backendové helpery. Velké datové buildery mají úroveň `overview`; neúplné upstream datasety nebyly vydávány za zkontrolované.

Sloučený manifest má 528 unikátních cest napříč všemi oblastmi auditu. Všechny odkazované cesty existují; seznam chybějících veřejných `src/*.js` je prázdný. Číslo zahrnuje i testy a konfiguraci, proto není počtem aplikačních modulů. Repo aplikace po dokončení zůstává čisté (`git status --porcelain` bez výstupu).
