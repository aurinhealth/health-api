// Original model and template functions, localized without private imports.
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const root='/workspace/health-api/src/';
const source=name=>readFileSync(root+name,'utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const L=(cs,en)=>en;
const model=new Function('L',source('workout-model.js')+'\nreturn {buildWorkout,zoneOf,zonesFor,flattenSteps,totalMinutes,zoneMinutes};')(L);
const templates=new Function('L',...Object.keys(model),source('endurance-templates.js')+'\nreturn {cleanEnduranceTemplate,enduranceStructure,ownLibraryWorkout};')(L,...Object.values(model));
for(const [sport,low,high] of [['ride',70,81],['run',73,82]]){
 const template=templates.cleanEnduranceTemplate({sport,name:'Own easy workout',blocks:[{repeats:1,steps:[{seconds:1800,low,high}]}]});
 const structure=templates.enduranceStructure(template);
 const result=templates.ownLibraryWorkout({id:'review',sport,name:template.name,structure_json:JSON.stringify(structure)});
 assert.equal(result.primary_system,'sprint');
 console.log(JSON.stringify({sport,low,high,average:structure[0].power,system:result.primary_system,zones:JSON.parse(result.zone_minutes_json)}));
}
