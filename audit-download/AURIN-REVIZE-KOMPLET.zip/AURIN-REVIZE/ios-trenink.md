**Dílčí audit iOS — trénink, posilovna, plánování, aktivity a kouč**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Zdrojový kód aplikace nebyl změněn. Audit probíhá staticky; Xcode, simulátor a skutečné integrace nejsou dostupné. Tento dokument se doplňuje průběžně.

**T1 [P2] Přechodná chyba při potvrzení návrhu kouče odstraní možnost potvrzení zopakovat**

Primární místo: [CoachView.swift:312](../../ios-native/Loadwise/Screens/CoachView.swift#L312), řádky 312–313. Vykreslení výsledku: [CoachView.swift:466](../../ios-native/Loadwise/Screens/CoachView.swift#L466), řádky 466–479.

`decide()` při chybě požadavku vloží `error.localizedDescription` do stejného slovníku `bubble.decided`, který používá pro úspěšné dokončení akce. `ActionCard` při libovolném nenulovém výsledku odstraní tlačítka „Potvrdit“ a „Ne“ a zobrazí text v zelené barvě. Výsledkem je uzavřená karta i tehdy, když požadavek vůbec nedošel na server.

Scénář: kouč připraví změnu plánu; uživatel bez spojení klepne na Potvrdit nebo server odpoví 503 před provedením změny. Akce zůstane neprovedená, karta už však nemá retry tlačítko. Uživatel musí vytvořit nový návrh místo opakování stávajícího. Znovuotevření uloženého chatu navíc načítá textové tahy, nikoli znovu původní interaktivní kartu.

Oprava: oddělit stav akce na pending/sending/succeeded/rejected/failed; při přechodné chybě zachovat tlačítko retry a zobrazit chybový stav. Teprve potvrzený výsledek serveru smí zapsat `decided`. Při retry po nejistém výsledku použít stávající draft ID a serverovou idempotenci.

Regresní scénář: návrh s platným draftId → simulovaná offline chyba před odesláním → tlačítko Potvrdit zůstane dostupné → úspěšné opakování změní plán právě jednou. Druhý případ 503 a třetí nejistý timeout po přijetí požadavku.

Jistota vysoká ze statické analýzy UI a síťového volání; na zařízení nebylo provedeno.

**Známé nálezy z hlavního reportu, zde nezapočítané znovu**

- Starý snapshot gymu uložený po `loadMuscles()` může odškrtnout nově dokončenou sérii (`REVIZE.md`, nález 6).
- Backend sdílené vlastní šablony může změnit detail dříve naplánovaného tréninku; jeho reprodukce je v `repro-own-workout-snapshot.mjs` a souhrn doplní hlavní audit.

**T2 [P2] Neúspěšné načtení dne v živé posilovně může přepsat existující trénink prázdným nebo nově sestaveným plánem**

Primární místo: [GymLive.swift:324](../../ios-native/Loadwise/Screens/GymLive.swift#L324), řádky 323–334. Automatické uložení: [GymLive.swift:491](../../ios-native/Loadwise/Screens/GymLive.swift#L491). Aktivní UI cesta: [GymTools.swift:25](../../ios-native/Loadwise/Screens/GymTools.swift#L25), „Zopakovat minulou“; route je v `AppRoute.swift:182`.

`LiveGymView.load()` začne novým prázdným `GymDay`. Chybu `model.gymDay()` zahodí pomocí `try?`; prázdný den je poté považovaný za nový, dostane `startedAt` a automaticky se uloží přes `persist()`. U volby „Zopakovat minulou“ se místo původního dne mohou uložit nově navržené série podle historie. Neexistuje zde rozlišení mezi skutečně prázdným dnem a dnem, který se nepodařilo načíst.

Scénář: na serveru již existuje dnešní plán nebo zaznamenané série, ale telefon pro něj nemá cache. GET `/app/api/gym` dočasně selže s 503. Uživatel otevře Trénink → Zopakovat minulou; pozdější POST už uspěje a uloží fallback. Backend v [routes-gym.js:225](../../src/routes-gym.js#L225), řádky 225–233, sníží počet dokončených sérií podle nového snapshotu a přepíše celý `values_json`, takže může zmizet plán i původně zaznamenané série.

Další dosažitelná varianta téhož problému: backend GET při chybě `readGymPlan()` vrací HTTP 200 se `status:'partial',values:[]` (`routes-gym.js:145–147`). `GymDay` v `WorkoutModels.swift:84–87` žádný `status` nemá; `APIClient.gym()` výsledek dekóduje jako běžný prázdný den a `AppModel.gymDay()` jej může i uložit do cache. Tento částečný výsledek pak rovněž může být automaticky uložen zpět.

Oprava: při selhání/částečném čtení ponechat chybový stav, nabídnout retry a zakázat automatické ukládání fallbacku. API musí rozlišovat „není uložený plán“ a „úložiště nebylo možné přečíst“; typ klienta musí tuto informaci zachovat. Proti přepsání novějšího dne doplnit revision/conditional save.

Regresní scénář: existující dokončená série na serveru, prázdná lokální cache, první GET 503 a následný POST dostupný — otevření obrazovky nesmí poslat žádný zápis ani změnit plán. Stejný test pro HTTP 200 s `status:'partial'`.

Jistota vysoká ze statického trasování UI → AppModel/API → backend ukládání. Síťové pořadí a iOS UI nebyly spuštěny v simulátoru. Nejde o již známý závod starého snapshotu při `loadMuscles()`.

**Pokrytí**

Strojový manifest: [ios-trenink-pokryti.json](./ios-trenink-pokryti.json). `detail` znamená podrobnou kontrolu uvedených rizikových funkcí/toků; ne kontrolu každého vizuálního řádku souboru. `flow` znamená sledování načtení a mutací, `overview` cílený přehled API, stavů a struktury zobrazení, `inventory` pouze zařazení do inventáře. Žádná úroveň neznamená spuštění na telefonu.

| Oblast | Rozsah provedené kontroly |
|---|---|
| Kouč: `CoachView`, `CoachPlanning`, `CoachPick`, `CoachMemory`, `CoachTextCard` | Odeslání, stream, rozhodnutí/undo, obnova chatů, ukládání paměti, revision a chování při chybě. Potvrzen T1. |
| Posilovna: `GymLive`, `GymSessionView`, `GymLog`, `TrainingModeView` | Načtení, fallback/cache, úprava sérií, autosave/debounce, dokončení, discard a dosažitelnost obrazovek. Potvrzen T2, známý stale snapshot nezapočítán znovu. |
| Vybavení a návrhy: `GymTools`, `GymPlaces`, `GymPlanActions`, `PlanEditorSheet`, `GymStretching` | Preview/confirm, výměna cviku, výběr místa, autosave a přemístění/cancel. |
| Týden a plány: `WeekPlanView`, `TrainingPlans`, `PlanScreens`, `PlanSessionActions`, `TrainingCalendar` | Stav draftů a jednotlivých uložení, změna týdne, přesun a undo, start/stop a výběr dne. |
| Knihovna a aktivity: `MyWorkouts`, `EnduranceWorkouts`, `TrainingLibrary`, `WorkoutDetailViews`, `ActivityEditing`, `ActivityTypeSheet`, `WorkoutMerge`, `WorkoutRating` | Editace, plánování, detail, smazání, ruční korekce, hodnocení a přenos dat. Backend mutable vlastní šablony auditován zvlášť. |
| Dostupnost a stav: `AvailabilityView`, `AthleteStatusView`, `FocusSheet` | Načtení, validace a ukládání, rozlišení běžného/týdenního plánu, nemoc a návrat k tréninku. |
| Metriky a sharing | Cílený přehled načítání a struktury zobrazení; bez ověřeného renderingu grafů, obrázků, tisků či kompatibility Share Sheet/Instagram. Přesná úroveň po souborech v manifestu. |
| Relevantní XCTest | Přečtené názvy/scénáře a cílené assertions v gym set/intensity/edit/order, endurance template, live activity a sharing testech. Testy nebyly spuštěné. |

Doplněný skutečný přehled implementace původně pouze inventarizovaných souborů (všechny zdroje přečteny; hloubka v manifestu je nadále pouze `overview`):

| Soubor | Co bylo prověřeno v implementaci |
|---|---|
| `CoachMarkdown.swift` | Parser odstavců, nadpisů, obou druhů seznamů, tabulek a inline Markdownu; bezpečný fallback na obyčejný text, stabilita identifikátorů; napojení vizuálů na health/training/today a jejich lazy načtení. Parser není plná implementace CommonMark, například nepodporuje vnořené seznamy a escaped pipes; nejde zde o potvrzenou funkční regresi. |
| `FormDetailView.swift` | Napojení snapshotu formy, CTL/ATL, VO2 a čtyřtýdenních intenzit; podmínky prázdných dat, škálování weekly load a odlišení plánovaného/zapsaného týdne. Rendering a shoda vypočtené metriky se serverem nejsou tímto přehledem ověřené. |
| `StrainDetailView.swift` | Vstupy Today/Training, doplnění chybějících snapshotů, rozdělení zátěže na trénink/pohyb/plán, přerozdělení dle TSS, dial a accessibility label, generování lokálního výhledu kondice/únavy přes EWMA 42/7. Výhled je lokální odhad; společný kontraktový test s backendem a s dnešními dosud plánovanými session je vhodný, zde bez dalšího potvrzeného nálezu. |
| `ThresholdCheckCard.swift` | DTO a endpointy odhadu/testu, 15min cache, nabídka vhodných dní, schedule/cancel/apply/manual result a obnova po akci, převod imperiální vzdálenosti. U loadu je potlačená chyba a po selhání může karta zmizet; bez zařízení a řízeného API scénáře vedeno jako UX omezení k otestování, nikoli další započtená chyba. |
| `VO2maxDetailView.swift` | Parse a řazení denních vzorků, rozsahy 1/3/6 měsíců/Vše, výběr nejbližšího bodu, min/max a měsíční průměry/změna, ochrany prázdných a konstantních hodnot a popisy řádků pro accessibility. Při málo bodech záměrně zobrazí poslední dva; nehodnoceno jako bug. |
| `WeatherViews.swift` | WMO mapování, jednotky teploty/větru/srážek, fallback bez počasí, geocoding přes URLComponents, debounce a zrušení starého search, získání aproximované polohy a omezení aktualizace po 2h/10km, zachování zbytku week prefs při uložení místa. Skutečné Location/URLSession chování vyžaduje zařízení; lokální follow preferences je třeba zahrnout do testů změny účtu řešených v auditu jádra. |
| `ZonesDetailView.swift` | Chybějící data, větvení nové/legacy struktury zón, WHO cíl 150min, pořadí týdnů, tabulkové hodnoty a souhrnný accessibility label. WHO hodnoty přicházejí ze serveru; rendering a empirická správnost zón nebyly otestovány. |

**Technická a UX rizika — nezapočítaná jako další potvrzené chyby**

- Některé vedlejší akce kouče paměti/advice stav optimisticky odstraní a chybu potlačí (`CoachPlanning.swift:121–133`). Po neúspěchu může původní rada znovu přijít; pro konzistentní UX má být vidět chyba a retry. Nález T1 je užší, trvale uzavírá konkrétní akční kartu.
- Ukládání a pořadí operací jsou mezi GymLive, GymSessionView, TrainingModeView a GymDoneDetail implementované vícekrát. Před vydáním je vhodná stejná kontraktová matice pro edit/undo/discard/offline/obnovu pro všechny tyto vstupy.
- Optimistické pinování cviků (`RecordsView.swift:201–218`) nemá serializaci a při souběžném selhání vrací starší snapshot. Bez kompletního testu síťového pořadí není tento kandidát počítaný mezi potvrzené nálezy.
- Vygenerovaný týden ukládá jednotlivé session postupně a sleduje jejich vlastní stav. Je potřeba testovat selhání druhé/poslední session a retry po timeoutu, včetně serverového dedup. Samotné částečné uložení není automaticky bug — UI ho po session rozlišuje.
- Sdílené obrázky mají exportní rozměry a pevné typography záměrně; bez renderingu není doložený clipping. Běžné obrazovky, grafy a časovače vyžadují VoiceOver, velké písmo, Reduce Motion, češtinu/angličtinu a imperiální jednotky na zařízení.
- Po doplnění sedmi souborů není v tomto dílčím manifestu žádná obrazovka pouze na úrovni inventáře. To stále není tvrzení stejné hloubky všech částí; části s čistým zobrazením a lokálními výpočty mají pouze statický `overview`.

**Neověřeno a doporučené testy**

1. Dva potvrzené regresní scénáře T1/T2 s řízenými chybami a pořadím odpovědí.
2. Dokončit a zahodit gym při čekajícím autosave, včetně zamčeného telefonu a background wake.
3. Přesunout gym/Intervals/local plán a použít undo, poté aplikaci ukončit během toastu a znovu načíst kalendář.
4. Změnit délku/sport/prostředí draftu, naplánovat více dní, simulovat částečné selhání a ověřit právě jednu remote aktivitu.
5. Reálné Wahoo/Intervals/Google, workout route z HealthKit, Share Sheet, APNs, live activities a locale/rendering ověřit na iOS. Jejich funkčnost tento statický audit necertifikuje.
