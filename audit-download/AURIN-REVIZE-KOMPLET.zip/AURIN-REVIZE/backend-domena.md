**Dílčí audit backendu — tréninky, plány, aktivity a kouč**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Aplikační kód ani vzdálená data nebyly změněny. Tento dokument doplňuje původních devět nálezů z [REVIZE.md](./REVIZE.md). Tři nové nálezy níže byly znovu ověřeny původními funkcemi; report zdraví a regenerace je samostatně v [backend-recovery.md](./backend-recovery.md).

**D1 — [P2] Synchronizace Wahoo přepíše ručně opravený typ aktivity a kalorie**

Primární místo: [wahoo.js:188](../../src/wahoo.js#L188), řádky 184–190. Ruční změna typu: [activity-type.js:187](../../src/activity-type.js#L187), řádky 187–191. Ruční kalorie: [activity-edits.js:49](../../src/activity-edits.js#L49).

Import Wahoo při konfliktu nahradí celý `payload_json` novou odpovědí poskytovatele. Větev ruční změny typu pro Wahoo přitom zapisuje opravu pouze do `payload.type`, bez samostatného markeru. `setActivityKcal()` drží ruční hodnotu a původní hodnotu v `loadwiseKcal`/`loadwiseKcalDevice`, ale ani tyto klíče upsert nepřenese.

Scénář: uživatel opraví Wahoo aktivitu z Run na Walk a z 600 na 250 kcal. Následující webhook nebo pravidelná synchronizace Wahoo přinese stejnou původní aktivitu a opravu zahodí. Uživatel znovu vidí Run a 600 kcal; dopad může být i na typové filtrování, kalorický rozpočet a tréninkovou historii. Dosažitelnost z aplikace potvrzují endpointy [routes-sync.js:36](../../src/routes-sync.js#L36) a [routes-sync.js:49](../../src/routes-sync.js#L49).

Runtime ověření spouští původní `changeActivityType`, `setActivityKcal` a Wahoo `upsert` nad skutečným SQLite. Výsledek před synchronizací: `type:Walk,calories:250,loadwiseKcal:250`; po totožném importu: `type:Run,calories:600`, marker chybí. Síťové API se nevolalo.

Oprava: oddělit uživatelské overrides od provider payloadu nebo v upsertu explicitně zachovat jejich klíče. Pro změnu typu Wahoo uložit trvalý override a použít jej ve všech čtecích cestách. Při sjednocování pravidel zkontrolovat i app-owned merge/hide metadata, jejich ztrátu tato reprodukce samostatně netestovala.

Regresní ověření: import → ruční typ/kalorie → opakovaný identický i změněný import; ruční oprava musí zůstat, ostatní skutečně změněné hodnoty se aktualizují. Uživatel musí mít možnost override zrušit a vrátit se k provider hodnotě.

Reprodukce: [repro-wahoo-overrides.mjs](./repro-wahoo-overrides.mjs). Jistota vysoká.

**D2 — [P2] Desetinná intenzita mezi hranicemi zón se klasifikuje jako sprint**

Primární místo: [workout-model.js:39](../../src/workout-model.js#L39). Pásma na řádcích 29–36 jsou celočíselná: například endurance končí 75 a tempo začíná 76. `zoneOf()` používá obě uzavřené hranice, takže 75,5 nepatří do žádného pásma. Fallbackem je poslední pásmo, tedy sprint. U běhu se totéž děje mezi 77 a 78 a u dalších hranic.

Nejde o nepovolený vstup: editor vlastního tréninku přijímá celé dolní/horní procento a `enduranceStructure()` pracuje s jejich průměrem. Validní 30minutový úsek 70–81 % FTP má průměr 75,5. Původní `cleanEnduranceTemplate()` → `enduranceStructure()` → `ownLibraryWorkout()` ho klasifikuje jako `primary_system:sprint` a všech 30 minut započte do sprintu. U běhu 73–82 % prahové rychlosti je průměr 77,5 a výsledek stejný.

Dopad: chybné zóny a klasifikace vlastního tréninku; navazující systémy mohou pracovat s nesprávnými hard minutes. `ai-workout-pick.js:42` používá stejný lookup při započítání náročných minut. Nález netvrdí konkrétní reálnou odpověď AI; doložená je chybná vstupní klasifikace.

Oprava: definovat spojitá pásma s jednou rozhodující hranicí nebo před lookupem použít jednotné zdokumentované zaokrouhlení. Nedostatky pásma nesmí implicitně znamenat nejvyšší intenzitu. Doplnit hraniční testy těsně pod, na a nad každou hranicí v obou sportech a zkontrolovat rampy s desetinným průměrem.

Reprodukce: [repro-zone-gaps.mjs](./repro-zone-gaps.mjs). Původní modely a validátor, lokálně izolovaná lokalizace; bez soukromých promptů. Jistota vysoká.

**D3 — [P2] Nové naplánování upravené vlastní šablony změní detail staršího naplánovaného tréninku**

Primární místo: [workout-templates.js:212](../../src/workout-templates.js#L212), řádky 210–213. Čtení aktuální struktury: [workout-library.js:64](../../src/workout-library.js#L64), řádky 64–68; navazující `scheduledLink()` začíná na řádku 490.

Při každém naplánování vlastní šablony endpoint přepíše jediný `saved_workouts.structure_json` a vytvoří schedule link na neměnné ID `own-<id>`. Starší schedule links ale nesou snapshot pouze vazby a při načítání detailu znovu čtou současnou strukturu této šablony. Neexistuje samostatná verze struktury pro každý výskyt v kalendáři.

Scénář: uživatel naplánuje vlastní 30minutový trénink na pondělí. Šablonu potom upraví na 90 minut a naplánuje ji na čtvrtek. Pondělní uložená událost a dřívější export zůstanou 30minutové, ale detail pondělního tréninku načítaný přes schedule link nyní uvádí 90 minut. Totéž může nastat při změně prahového tempa mezi dvěma naplánováními běžecké šablony s úseky podle vzdálenosti.

Runtime ověření používá původní `scheduledLink`, `getWorkout` a `ownLibraryWorkout`, skutečný SQLite a stejný UPDATE struktury jako plánovací endpoint. Detail stejného pondělního linku se po přepsání změní z 30 na 90 minut, bez změny pondělní události. Nativní tok úprava → další plánování → detail byl trasován z MyWorkouts při předchozí části auditu, zde nebyl spouštěn v simulátoru.

Oprava: ukládat neměnný snapshot struktury, názvu, sportu a relevantních parametrů k jednotlivému schedule linku/události nebo vytvořit verzovanou knihovní instanci při každém plánování. Detail, export i hodnocení musí odkazovat na stejnou verzi.

Regresní ověření: naplánovat tutéž šablonu na dva dny s úpravou mezi nimi; oba detaily, minuty, exportované kroky a následné hodnocení musejí odpovídat své vlastní naplánované verzi.

Reprodukce: [repro-own-workout-snapshot.mjs](./repro-own-workout-snapshot.mjs). Jistota vysoká.

**Rozsah a poctivost pokrytí**

[backend-domena-inventory.json](./backend-domena-inventory.json) je původní inventář názvů funkcí a exportů 107 doménových modulů. Po pokračování auditu byly u všech těchto modulů skutečně čteny implementační části: veřejné výpočty a kontrakty, reprezentativní větve validace, návratové a chybové stavy, relevantní zápisy/čtení a u větších algoritmů jejich hlavní rozhodovací tok. Úroveň `overview` neznamená přečtení každého řádku ani matematický důkaz všech větví; jde o cílený přehled implementace. `flow` navíc sleduje konkrétní návaznost vstup → výpočet → uložení/odpověď. Větší datové katalogy cviků byly kontrolovány strukturálně, nikoli jednotlivě z hlediska správnosti cvičební techniky.

Aktuální jednotlivé soubory a úrovně jsou v [backend-domena-pokryti.json](./backend-domena-pokryti.json): 111 cest včetně souvisejících Wahoo/routes/entrypoint, z toho 4 `detail`, 18 `flow`, 89 `overview`; žádná cesta už není označena pouze `inventory`.

| Soubor / oblast | Hloubka ověření v této části |
|---|---|
| `src/workout-model.js` | Detail výpočtu a pásmování zón, flatten/total, navazující modelové funkce přehled; runtime klasifikace |
| `src/endurance-templates.js` | Detail validace a převodu vlastní šablony, intensity range a system classification; runtime celý převod |
| `src/workout-library.js` | Detail getWorkout a scheduledLink; cílený přehled generování, resize, klasifikace a feedback persistence |
| `src/workout-templates.js` | Detail create/copy/receive/schedule a mutable structure flow; ostatní sdílení přehled |
| `src/activity-type.js` | Detail ručních změn typu a odlišných provider větví; runtime Wahoo |
| `src/activity-edits.js` | Detail calorie override a per-user SQL; delete části přehled; runtime calorie edit |
| `src/wahoo.js` | Detail formátu a upsertu dokončené aktivity; ostatní konektor řeší platformní audit |
| `src/routes-sync.js` | Detail dosažitelnosti type/kcal/sync API a guardů; ostatní části přehled |
| `src/planned-workout.js`, `src/planned-detail.js` | Tok: precedence lokálního plánu, schedule link a provider detailu; převod workout_doc/popisu |
| `src/planned-events.js`, `src/plan-context.js` | Tok/detail move/delete/environment, lokální versus provider zápis, cancellation, plán a historie |
| `src/coach-actions.js` | Tok a cílené čtení validátoru: typy akcí, per-day limity, status/illness, hard days, ověřené cíle aktivit; soukromé instrukce nepřístupné |
| `src/ai-workout-pick.js`, `src/ai-workout-compose.js` | Cílený tok hard-minute omezení a návaznosti na model; soukromé promptové instrukce a živé AI odpovědi netestovány |
| `src/coach-pick.js` | Přehled kontraktů, volby a uloženého stavu dne; ne úplná runtime matice |
| `src/coach-assistant.js`, `src/ai-usage.js`, `src/coach-allowance.js` | Tok requestu na AI: model/task timeout, reservation, per-user den/měsíc, počítání zpráv a release, neúplný výstup a schema parsing; soukromé instrukce nepřístupné |
| `src/training-plans.js` | Tok phase/week/apply, přesuny/skip/shorten, return/repeat/light/undo a active persistence; data jednotlivých týdnů strukturálně |
| `src/strength-generator.js`, `src/strength-intelligence.js`, `src/strength-history.js`, `src/strength-context.js` | Tok context → completed history → selection/protection/deload → progression/load → rows; čtena ochrana před paused/red/ill, vybavení, objem, první trénink, čtení a ukládání historie |
| `src/strength-timing.js`, `src/strength-balance.js` | Detail výpočtu času/superset/drop a sportovní svalové dávky/coverage; bez runtime empirické validace |
| `src/strength-gateway.js`, `src/gym-plan-store.js`, `src/energy-profile.js` | Cílený přehled veřejných funkcí, persistencí, validace a error větví; ne úplná runtime matice |
| `src/cycling-coach-v2.js` | Tok readiness a load cap → novice/paused/illness/return → session kind/length; zohlednění jiného sportu a hlavního eventu; ne empirická validace modelu |
| `src/energy-budget.js`, `src/adaptive-engine.js` | Přehled vstupů a návaznosti na history/plánování |
| `src/entrypoint.js` | Cílený přehled endpointové dosažitelnosti; společný soubor má i další auditní oblasti |
| Zbývající moduly z doménového inventáře | Cílený přehled implementačních výřezů, validací, návratových stavů, chyb a persistence; jednotlivé cesty s úrovní `overview` v JSON |

Dokončený přehled zbývajících skupin:

- **Aktivity a historie:** `activity-chat-edits`, `activity-detail`, `activity-energy-*`, `activity-match/origin`, `manual-heart-rate/pairs`, `plan-match`, `workout-merge`. Čteny identifikátory, per-user SQL, primární/duplicitní role, stejné datum/sport u slučování, meze časového rozestupu, undo, coverage energetických vzorků a nedostupné remote streams. U reprezentativních endpointů byly trasovány příslušné guardy; D1 zachycuje konkrétní ztrátu uživatelské opravy.
- **Obrazovkové modely a sdílení:** `app-calendar/training/milestones`, `share-week/milestone`, `fitness-insights`, `performance-trends`, `trend-facts`. Čteno mapování aktivit a plánů, rozlišení done/planned, nulová a chybějící data, výběr časových oken a součty; sdílení neznamená automatický externí zápis.
- **Kouč a AI:** `assistant-app-context/chats/stream`, `athlete-focus/state/weight`, `chat-ask`, `coach-*`, `screen-texts`, `ai-routes/usage`. Čteny whitelist kontextu, validace cíle/dne, vazba chatů na uživatele, souhrny a fallback texty, stream completed/error, sanitizace návrhů a per-user persistence. Skutečné privátní systémové instrukce ani chování živého LLM nebyly dostupné.
- **Gym nástroje:** `gym-adjust/catalog/equipment/equipment-ai/intensity/review/set-options/sides/trim`, `exercise-feedback/photos/technique`, `pinned-exercises`, `strength-normalization`. Čteny limity plánu, normalizace jmen, vybavení, odstranění už zapsaných hodnot z nového AI návrhu, validace video URL a whitelist cviků, supersérie/strany/intenzita a upřesnění váhy z historie. U velkých seznamů je přehled strukturální, ne odborné schválení všech cviků.
- **Týdenní plánování a progrese:** `adaptive-week`, `week-ai/planner/revision`, `threshold-check/state`, `training-availability/history/profile/status/zones`, `training-load`, `workload-ratio`, `library/local-workouts`, `onboarding`. Čteny minima/maxima, aktuální stav sportovce, dostupnost, vlastní explicitní volba, posun a reset, pending/decided stavy, threshold validace a pozdější ukládání. Původní dva běžecké bugs zůstávají platné, nejsou zde novým nálezem.
- **Knihovna a instrukce:** `cycling/running-workouts`, `workout-explanation/i18n`, `stretching` a datové katalogy cviků. Čteno sestavení warm-up/core/cool-down, délky/opakování, fallbacky a převody paces/watts, lokalizace a výběr rutiny. Strukturálně byly spuštěny čtyři původní datové moduly: 322 českých a 322 anglických technique záznamů, odpovídající 322+322 feel párů, žádný chybějící anglický/feel klíč a žádné neplatné setup/steps/mistakes textové pole. To není odborná validace jejich obsahu.

Samostatný recovery audit má podrobné pokrytí recovery/readiness/sleep/muscle/load/Today/Health a tři vlastní potvrzené nálezy. Původní report má dva potvrzené bugs v běžeckém týdenním rozpočtu. Tyto výsledky se nemají počítat podruhé.

**Technická rizika, testovací mezery a nedokončené ověření**

- Stejná struktura tréninku prochází editor → model → knihovna → kalendář → export → hodnocení. Potvrzené D2 a D3 ukazují chybějící kontraktové testy přes všechny tyto kroky. Doporučuji stejný vstup porovnat napříč detailem, exportem a odhadem zátěže.
- Provider payloady a uživatelské opravy jsou místy ve stejném JSON. D1 je konkrétní důkaz, že je nutné odlišit vlastnictví polí; podobná metadata se mají auditovat jako skupina a chránit před pozdějším importem.
- Stav dávky tréninků, šablony, jejího výskytu a odpovědi kouče má několik samostatných reprezentací. Testy mají ověřovat stabilitu uložené historie po dalších editacích, nikoli pouze validitu aktuálního JSON.
- Chybějící `src/private` blokuje úplný import mnoha modulů a standardní testovací sadu. Reprodukce záměrně izolují původní veřejné funkce a jejich lokalizaci; nejsou testem celého Workeru ani soukromých bezpečnostních instrukcí.
- Změny tréninků přes AI jsou validované veřejným `validateCoachActions()`, ale bez soukromých instrukcí a skutečných odpovědí nebylo provedeno end-to-end ověření prompt injection, nejednoznačných pokynů ani konverzační paměti. Není namístě vydat závěr, že AI vrstva je bezpečná nebo že neobsahuje další chyby.
- Hlavní strength/progression a event phase algoritmy již prošly čtením toku a ochranných podmínek. Nebyla však matematicky ověřena každá kombinace koeficientů, délka každé předdefinované šablony ani individuální přenos sil mezi cviky. Přísné tvrzení „každý algoritmus je prokázaně správný“ by tak nebylo oprávněné; vyžaduje property/kontraktové testy a empirická data.
- Zdravotní a tréninkové modely nebyly validovány klinicky ani na reálných datech různých sportovců. Dokumentovaná heuristika se nepovažuje automaticky za bug; vyžaduje samostatnou empirickou validaci.

**Lokální ověření**

```sh
node /workspace/aurin-review/repro-wahoo-overrides.mjs
node /workspace/aurin-review/repro-zone-gaps.mjs
node /workspace/aurin-review/repro-own-workout-snapshot.mjs
```

Všechny tři skripty při dokončení této části znovu prošly a jejich assertions potvrdily výše popsané chyby. Pro reprodukce se nezískávaly tajné hodnoty, nevytvářely se soukromé promptové soubory a nevolaly se externí služby.
