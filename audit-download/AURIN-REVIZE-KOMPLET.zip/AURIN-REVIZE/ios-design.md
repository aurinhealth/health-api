**Dílčí audit iOS — sdílené vizuální komponenty, grafy, gesta a smoke testy**

Revidovaný commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Přečteno `CLAUDE.md`. Dokončena poslední nepřiřazená skupina 17 Swift souborů. Kód aplikace nebyl změněn, externí služby nebyly volány. Xcode, simulátor a fyzický telefon zde nebyly dostupné.

**Výsledek**

V této skupině nepřibyl nový dostatečně doložený funkční nález do prioritizovaného počtu. Níže jsou konkrétní ověřené vlastnosti a rizika, která patří do testovacího plánu. Nezaměňuji viditelný vzor nebo potenciální chybu vstupu za skutečně dosažitelný pád v aplikaci.

**Skutečné pokrytí**

| Soubor | Hloubka | Co bylo zkontrolováno |
|---|---|---|
| `Design/AurinMark.swift` | přehled | Canvas geometrie, velikost, světlé/tmavé barvy a dekorativní accessibility hiding |
| `Design/Avatar.swift` | tok | PhotosPicker → data → ořez 600 px → atomické JPEG uložení, chybový návrat, odstranění, invalidace verze a dostupný popisek ovládání |
| `Design/BodyFigure.swift` | přehled | Struktura SVG dat, celý podporovaný parser M/L/Q/C/Z, aspect-fit transformace, hit testing, prahy svalové zátěže a souhrn VoiceOver; anatomická správnost všech souřadnic nebyla vizuálně měřena |
| `Design/Charts.swift` | tok | Normalizace a clamp hodnot, nuly/konstantní data, prázdné seznamy, styles a několik konkrétních callers, trendové tečky a škálování |
| `Design/Components.swift` | přehled | Card, progress/range, popisky čísel a ikon, Liquid Glass fallback, environment scroll callbacks, pinned/tab bars a PageScroll; ne pixelová kontrola layoutu |
| `Design/DrinkFigure.swift` | přehled | Volba a persistence postavičky, clamp zlomku, animace a zastavení, Canvas kreslicí cesty a souhrn accessibility; každý bod kresby není validovaný proti referenčnímu obrázku |
| `Design/Format.swift` | tok | Číselné a časové formáty, relativní dny, CS/EN tvary, lokální versus UTC kalendář a zamčená cache DateFormatterů |
| `Design/HorizontalPan.swift` | detail | Připojení a demontáž UIKit recognizeru, oslabené reference, marker bounds, rozlišení vodorovného/svislého směru a vnořený horizontální scroll |
| `Design/Muscle3D.swift` | tok | Binární hlavička a rozsahy, rozdělení mesh dat, cache a selhání stahování, detached parse, SceneKit instance, výběr a paint, pan/tap/focus a fallbacková návaznost |
| `Design/MuscleFigure.swift` | přehled | Struktura svalových ID/path dat, zrcadlení transformace, front/back, selekce a hit testing; bez renderingu |
| `Design/SettingsRows.swift` | přehled | Disabled stav, custom toggle a accessibility value, textová pole, min-height, picker binding a návrat z variant |
| `Design/SwipeBack.swift` | detail | Podmínka více než jednoho controlleru pro interactive pop a chování delegáta |
| `Design/SwipeRow.swift` | detail | Swipe offsety, prahy, reset, disabled absence actions a samostatné accessibility actions |
| `Design/TrendChart.swift` | tok | Třídění datumů, klouzavý průměr, rozsahy 7/30/90, výběr bodu, prázdné vstupy, band a souhrn pro VoiceOver |
| `Design/Typography.swift` | detail | RelativeTo custom fonts, Dynamic Type limity a zmenšování dlouhých čísel |
| `Screens/RoutineSettings.swift` | tok | Pauzy gymu, zachování aspoň jednoho meal slotu, SettingsStore načtení a návrat chyby uložení, refreshFood, Bluetooth scan/connect/stop lifecycle |
| `LoadwiseUITests/SmokeTests.swift` | přehled testových assertions | Všechny čtyři test metody a helpers: první spuštění, demo taby/detaily, stav sportovce CS/EN, neblokující webové snímky, wait/tap a screenshot attachment |

Strojový seznam: [ios-design-pokryti.json](./ios-design-pokryti.json). `detail` označuje detail malé komponenty, `flow` sledovaný konkrétní tok, `overview` skutečné čtení struktury a implementačních větví. Žádná úroveň neznamená spuštění na iOS nebo ruční kontrolu každého grafického souřadnicového bodu.

**Rizika a konkrétní následné testy — nejsou další potvrzené vady**

- **Grafy přes změnu letního času.** `TrendChart.swift:41` používá pro sedmidenní okno pevný počet sekund, zatímco `ISODay.date()` produkuje kalendářní dny v místní zóně. Ověřit řadu místních půlnocí přes oba DST přechody a skutečný počet zahrnutých kalendářních dní. Pro kalendářní okno je vhodnější `Calendar.date(byAdding: .day, ...)`. Nebyl zde spuštěn Swift výpočet a nechci tvrdit naměřený dopad na UI.
- **Defenzivní kontrakt BarChart.** `Charts.swift:31` předpokládá neprázdné `styles`, pokud existují `values`. Prověřené callers vytvářejí styly ze stejného seznamu nebo explicitní pevné sady; nenašel jsem dosažitelný běžný případ prázdných styles a neprázdných hodnot. Doporučit fallback styl a unit test pro samostatnou komponentu, ne hlásit aktuálně potvrzený crash.
- **Reduce Motion.** `DrinkFigure` má vlastní přepínač animace, ale v implementaci timeline není systémový `accessibilityReduceMotion`. `Muscle3D` používá animované přesuny kamery a setrvačné otáčení. Ověřit chování se systémovým Omezit pohyb a upravit respektování preference tam, kde se animace nepřizpůsobuje; nepředstavuje to důkaz zdravotního incidentu nebo nefunkčního ovládání.
- **VoiceOver a svalové mapy.** BodyMap nabízí souhrnný popis a charts mají souhrny nebo jsou skryté jako dekorace. Výběr jednotlivého svalu v 3D a na tap-only regionech ale vyžaduje ověření dostupné alternativy v celé obrazovce. Samotné `isAccessibilityElement=false` na SceneKit view není důkaz, že obrazovka nemá jinou ovládací cestu.
- **Velký text.** `Typography.swift` záměrně omezuje některé obrazovky na accessibility1 a husté komponenty na xxxLarge; některá číselná pole se ještě zmenšují. Před vydáním prověřit největší podporovaný text, malý iPhone, CS/EN, čitelnost tooltipů a hodnot a dotykové cíle 36–40 bodů. Statika neprokazuje skutečné oříznutí.
- **Životnost média a generace účtu.** Avatar picker a model downloader čekají asynchronně a používají společné místní úložiště. Stojí za test odhlášení/přepnutí účtu během čekajícího pickeru a ukončení aplikace během prvního model downloadu. Existující cache modelu má atomický zápis a parser při neplatné hlavičce/velikosti vrací nil; žádný nový konkrétní přenos fotografie zde nebyl reprodukován.
- **Robustnost 3D vstupu.** Parser hlídá magic, verzi, délky a přesnou velikost dat. Vhodné doplnit test extrémních počtů, indexů mimo vertex range, počtu indexů nedělitelného třemi a nefinálních floatů. Licencovaný binární model nebyl v repozitáři, tedy nebyl validován konkrétní produkční asset.
- **Gesta na zařízení.** HorizontalPan odstraňuje recognizer při demontáži a ponechává vnořené horizontální scrolly. SwipeRow poskytuje VoiceOver actions. Nutná integrace s interactive pop, edge swipy, scroll view a otevřenou klávesnicí; skutečné priority UIKit recognizerů se bez zařízení neověřily.

**Co smoke testy skutečně dokazují podle kódu**

První tři testy kontrolují existenci základních obrazovek, vybrané taby, několik tapů a běžící foreground aplikaci; používají demo data. Neověřují skutečné přihlášení, backendovou persistenci, výpadky sítě, změnu účtu ani HealthKit/BT.

`test4WebsiteScenes()` je úmyslně neblokující průchod pro vytváření obrázků. `tapIfThere` vrací false, pokud se element nenajde, a test pokračuje. Zelený tento test tedy neprokazuje, že každá plánovaná interakce a scéna opravdu proběhla. Snímky jsou attachments a případně soubory; neporovnávají se s referenčním obrazem. Proto není správné brát tyto testy za kompletní vizuální regresi nebo úplný end-to-end test aplikace.

**Kontrola před vydáním**

Na macOS spustit nativní testy a zkontrolovat jejich attachments. Na telefonu projít DST/časové zóny u grafů, VoiceOver výběr svalů a swipe actions, Dynamic Type, Reduce Motion, světlo/tma, překrývání pinned barů a kombinace edge swipe + svislý scroll. Otestovat načtení poškozeného/chybějícího mesh souboru a bezpečný fallback. V tomto read-only auditu tyto runtime scénáře provedené nebyly.
