**Dílčí audit backendu — zdraví, spánek, regenerace, svaly a zátěž**

Commit `02d575e570a179a5c156bcc9708877a2c18f3de8`. Aplikační kód nebyl měněn. Výsledkem jsou tři nové doložené chyby P2; neobsahuje devět již známých nálezů v hlavním reportu.

**R1 [P2] Aktivita pouze z Wahoo se nezapočítá do svalové únavy ani do doby regenerace**

Místo: [muscle-fatigue.js:337](../../src/muscle-fatigue.js#L337).

`loadTrainingDoses()` povoluje v obou částech SQL podmínky pouze Intervals, local, Google a Apple. Wahoo ale ukládá dokončené aktivity pod `source_family='wahoo', data_type='activity'` ([wahoo.js:181](../../src/wahoo.js#L181), ukládání ř. 185–190). Tyto aktivity se jinak normálně zobrazují a účastní výpočtu kondice; například `fitness-insights.js:277` Wahoo explicitně bere.

Pokud uživatel importuje dlouhou jízdu nebo běh pouze z Wahoo a nemá jeho kopii z jiného zdroje, Svaly tento trénink nevidí. Ani Today `recoveryTime` z něj nevypočte potřebný odpočinek, protože čte stejnou funkci (entrypoint.js:825, 840 a 1769). Uživatel tak může dostat stav odpočatých nohou a chybějící dobu regenerace po náročné aktivitě. Netvrdím, že tím byl prokazatelně vygenerován nebezpečný trénink; doloženým dopadem jsou nesprávné podklady a zobrazení regenerace.

Ověření původní `loadTrainingDoses()` se skutečným lokálním SQLite: totožná aktivita Ride, 180 TSS, source Wahoo → `activities.length=0`; změna jediného pole `source_family` na Intervals → `activities.length=1`, `tss=180`.

Oprava: doplnit Wahoo do obou source podmínek a zachovat existující deduplikaci/matching. Regresně projít stejnou aktivitu ze všech podporovaných zdrojů, včetně případu Wahoo + Apple kopie.

Jistota vysoká; SQL a původní loader byly spuštěny, metadata/parsery okolí byly v harnessu izolovány.

**R2 [P2] Zdraví vykazuje jiný spánkový dluh než Dnes, protože zahazuje zdřímnutí**

Místo: [app-health.js:85](../../src/app-health.js#L85).

`buildHealth()` předává do `sleepDebtMinutes()` pouze `primaryNights`, tedy hlavní noci s alespoň 180 minutami, bez naps. Model v `recovery-model.js:89–104` přitom výslovně započítává denní zdřímnutí a Today mu předává všechny spánkové sessions. Stejná naps modelu zároveň snižují potřebu další noci.

Doložený scénář: sedmihodinová noc a hodinové odpolední zdřímnutí při základní potřebě osm hodin. Původní `buildToday()` vrátí `strain.target.debt=0`, ale původní `buildHealth()` ve stejné chvíli a nad stejnými vstupy `sleep.debt.minutes=60`. Není to jen odlišný popisek: obě místa mají jiný součet týchž dat. Při více dnech se rozdíl kumuluje.

Oprava: pro dluh ve Zdraví použít stejné sessions a pravidla jako pro Today, nebo vytvořit jeden sdílený výpočet. Do testu přidat noc + odpolední nap a ověřit rovnost dluhu mezi obrazovkami.

Jistota vysoká; obě původní build funkce byly spuštěny s reálnými recovery/readiness funkcemi. Závislosti na vykreslování tréninků a lokalizaci, které výpočet dluhu neovlivňují, byly izolované.

**R3 [P2] Importovaná váha se při překročení UTC půlnoci přiřadí špatnému dni a může se skrýt**

Místa: [app-health.js:121](../../src/app-health.js#L121) a [app-today.js:196](../../src/app-today.js#L196).

Oba sestavovače získávají datum vážení pomocí `timestamp.slice(0,10)`, i když `date` obrazovky je v uživatelově časové zóně. Apple Health i Google mohou vracet UTC čas. Naproti tomu svalová hmota ve stejné Health odpovědi už používá správné `localDate()`.

Doložený scénář v `America/New_York`: `2026-10-20T01:00:00Z` je 19. října ve 21:00. Při načtení 19. října se 80kg vážení vyhodnotí jako budoucí (`2026-10-20 > 2026-10-19`) a oba původní buildy vrátí `weight:null`, pokud jiný záznam neexistuje. S historií zůstane zobrazená starší hodnota. V kladné UTC zóně se časné ranní vážení může přesunout do předchozího dne; po cestování může být chybně i trend.

Oprava: přidělovat den přes `localDate(sample_time || start_time)` a následně řadit chronologicky. Stejné pravidlo sdílet v obou obrazovkách. Testovat UTC timestamp i explicitní offset v UTC− a UTC+ zóně.

Jistota vysoká; původní buildy byly spuštěny uvnitř skutečného `withTimeZone('America/New_York')` a skutečné `localDate()` ověřilo správný den.

**Reprodukce a kontroly**

`node /workspace/aurin-review/repro-recovery.mjs`

Výstup:

```json
{"proof":"naps omitted from Health debt","healthDebt":60,"todayDebt":0}
{"proof":"weight assigned to UTC day and hidden","at":"2026-10-20T01:00:00Z","actualLocalDate":"2026-10-19","requestedDate":"2026-10-19","healthWeight":null,"todayWeight":null}
{"proof":"same workout omitted for Wahoo but included for Intervals","wahooActivities":0,"intervalsActivities":1,"tss":180}
```

Reprodukce používá původní funkce načtené do lokální funkční izolace, skutečný recovery-model/readiness/user-time a SQLite. Nepoužívá produkční API a nevytváří žádné soukromé prompty. Nenahrazuje test celého Workeru.

**Pokrytí souborů**

| Soubor | Hloubka a zaměření |
|---|---|
| `src/recovery-hours.js` | Detail: intenzita, fallback TSS, limity hodin, vstupy detailu aktivity |
| `src/recovery-model.js` | Detail: baseline a source baseline, scoring, nap/debt/sleep need, strain, merge wellness; publikované koeficienty posouzeny jako dokumentované odhady |
| `src/recovery-plan.js` | Detail: routine/kinds, minuty, per-user zápisy, done/remove; bez nového potvrzeného bugů |
| `src/recovery-time.js` | Detail: loadTrainingDoses cesta, časy aktivit, svalové dávky, ranní penalizace, výpočet readiness/lightAt |
| `src/recovery-today.js` | Detail: výběr dne, hotové/plánované session, svalové oblasti, návrh stretch/sauna |
| `src/recovery-validation.js` | Detail: Pearson/Fisher/RM correlation, výběr pairs, známá omezení kalibrace; soukromá AI netestována |
| `src/readiness.js` | Detail: merge/input range, primary night, lock použití, check-in a sleep index; využito i v reprodukci |
| `src/readiness-lock.js` | Detail: vytvoření/použití locku, prodloužená noc a per-user SQL |
| `src/muscle-detail.js` | Detail: e1RM, per-week výběr, calendar/recent a databázové filtry |
| `src/muscle-fatigue.js` | Detail: čas gymu, dávky a decay, svalové skupiny, doporučení, DB source filtry; runtime ověření source chyby |
| `src/muscle-model.js` | Detail krátkého modulu: verze, R2, conditional response a komprese |
| `src/sleep-sessions.js` | Detail: trvání a stages, nap, WASO, slučování rozdělených nocí |
| `src/night-detail.js` | Detail: výběr hlavní noci, timeline, HR/HRV query a stats; chybějící signály považovány za omezení zdrojů, ne automaticky za bug |
| `src/workload-ratio.js` | Detail: denní load series, history window, ACWR/monotony a nulové hodnoty |
| `src/training-load.js` | Detail: sRPE/TRIMP/power fallback, gym estimation, EWMA, watch-only a addLoads |
| `src/own-fitness.js` | Detail: načtení a deduplikace aktivit, gym sessions, athlete inputs, warm-up série |
| `src/training-zones.js` | Detail: vstupní validace, FTP/pace metody, custom bounds, generování zón a překlady; některé extrémní kombinace HR referencí jsou kandidátem na produktovou validaci, nikoli potvrzený incident |
| `src/app-health.js` | Detail všech sestavovaných metrik; runtime ověření naps a lokálního dne vážení |
| `src/app-today.js` | Detail Today flow včetně readiness, strain/debt, plán/sleep/cycle/recovery/weight; runtime ověření naps a lokálního dne vážení |
| `src/fitness-insights.js` | Související přehled+detail `storedActivities`, muscle events a SQL source list; porovnání podpory Wahoo |
| `src/activity-match.js` | Související přehled, použity skutečné `sessionOf` a `sameSession` |
| `src/user-time.js`, `src/athlete-weight.js` | Související detail timestamp API a kontraktu váhy |
| `src/wahoo.js` | Související detail formátu a ukládání dokončené aktivity, zbytek delegovaný integračnímu auditu |
| `src/entrypoint.js` | Dosažitelnost Today/Health/recovery a svalových endpointů; zbytek mimo tento dílčí rozsah |
| `tests/recovery-model.test.mjs`, `tests/app-health.test.mjs`, `tests/app-today.test.mjs`, `tests/training-load.test.mjs`, `tests/sleep-split-night.test.mjs`, `tests/night-detail.test.mjs`, `tests/wahoo.test.mjs` | Přehled relevantních assertions a absence uvedených regresí; nebyly všechny spuštěné kvůli nedostupným soukromým importům |

**Technická rizika a testovací mezery — oddělené od potvrzených chyb**

- Stejná metrika je na Today a Health sestavována různými cestami. Nalezený rozdíl v dluhu je konkrétní důkaz; další metriky potřebují společné kontraktové testy obou obrazovek se stejnými daty.
- Výčet providerů je ručně opakovaný v mnoha SQL dotazech. Wahoo se jednou přidalo do fitness insights a own fitness, ale ne do recovery. Vhodná je sdílená definice podporovaných druhů aktivit a testová matice provider × obrazovka/výpočet.
- Zjednodušené koeficienty regenerace, minut bez HR a nulové počáteční CTL jsou v kódu dokumentované modelové volby. Jejich existenci neoznačuji automaticky jako chybu. Přenos kalibrace z jednoho sportovce na širokou populaci zde nebyl empiricky ověřen.
- Některé loaders zachytí libovolnou SQL chybu a nahradí ji prázdným seznamem. Není prokázaný konkrétní produkční výpadek, ale pro health/recovery endpointy je vhodné odlišovat „není data“ od „data nebylo možné načíst“ stejně jako na Today.
- Chybí cílené regresní testy na lokální den váhy kolem UTC půlnoci, na shodu debt s naps a na všechny aktivity ze všech providerů.

**Neověřeno**

Skutečné HealthKit/Google/WHOOP/Wahoo senzory a metadata, APNs, produkční databáze, reálná zdravotní validita doporučení, Xcode/iOS rendering a soukromé AI prompty nebyly v tomto dílčím auditu dostupné. Výsledky proto netvrdí klinickou validaci ani úplný integrační test nasazení.
