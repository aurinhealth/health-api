// Runs only the original job definitions and their selection predicates.
// No job body, network operation, private module or database is executed.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync('/workspace/health-api/src/entrypoint.js', 'utf8');
const begin = source.indexOf('const minute = (cron,');
const end = source.indexOf('export function dueUserJobs(');
assert.ok(begin >= 0 && end > begin);
const jobs = new Function(source.slice(begin, end) + '\nreturn USER_JOBS;')();
const now = new Date('2026-10-19T07:25:00Z');
for (const connected of [[], ['whoop'], ['ultrahuman'], ['google'], ['intervals']]) {
  const selected = jobs.filter(job => job.due('* * * * *', now) && job.providers.some(provider => connected.includes(provider)));
  const hasPushJob = selected.some(job => job.name === 'sync');
  if (!connected.includes('google') && !connected.includes('intervals')) assert.equal(hasPushJob, false);
  else assert.equal(hasPushJob, true);
  console.log(JSON.stringify({ connected, selectedJobs: selected.map(job => job.name), hasPushJob }));
}
