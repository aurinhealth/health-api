// Original food functions with only their unrelated imports isolated.
// Uses the repository's actual SQLite-backed D1 facade. No network or prompts.
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
const root='/workspace/health-api/src/';
const source=name=>readFileSync(root+name,'utf8').replace(/^import .*;\r?\n/gm,'').replace(/\bexport /g,'');
const context=vm.createContext({console,Date,Response,Request,JSON,Number,Set,Map,Math,L:(cs,en)=>en,
  scaleMicros:(v,f)=>v, hideAppleFood:async()=>{throw new Error('unused');},OTHER_APP_SOURCES:['apple-health','google-health']});
const timeFns=vm.runInContext(`(()=>{${source('food-google-sync.js')}\nreturn {foodGooglePayload};})()`,context);
const row={consumed_date:'2026-10-19',consumed_at:'2026-10-19T07:30:00',recipe_title:'Breakfast',kcal:300,protein_g:10,carbs_g:50,fat_g:6,note:'{"mealType":"breakfast"}'};
const payload=timeFns.foodGooglePayload(row);
assert.equal(payload.nutritionLog.interval.startTime,'2026-10-19T12:00:00.000Z');
console.log(JSON.stringify({proof:'food export discards local meal time',input:row.consumed_at,googleStart:payload.nutritionLog.interval.startTime}));

const foodFns=vm.runInContext(`(()=>{${source('food-entry-management.js')}\nreturn {bulkFoodEntries};})()`,context);
const db=createD1(); db.userId=7;
db.sqlite.exec(`CREATE TABLE food_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,consumed_date TEXT,consumed_at TEXT,cookbook_page INTEGER,recipe_title TEXT,servings REAL,kcal REAL,protein_g REAL,carbs_g REAL,fat_g REAL,fiber_g REAL,source TEXT,note TEXT);
INSERT INTO food_logs VALUES(1,7,'2026-10-19','2026-10-19T07:30:00',NULL,'Breakfast',1,300,10,50,6,2,'package_label','{}');`);
let failed=false;
try{await foodFns.bulkFoodEntries(db,{action:'copy',ids:[1,999],date:'2026-10-20'});}catch{failed=true;}
const firstCopyCount=db.sqlite.prepare("SELECT COUNT(*) n FROM food_logs WHERE consumed_date='2026-10-20'").get().n;
assert.equal(failed,true); assert.equal(firstCopyCount,1);
try{await foodFns.bulkFoodEntries(db,{action:'copy',ids:[1,999],date:'2026-10-20'});}catch{}
const retryCopyCount=db.sqlite.prepare("SELECT COUNT(*) n FROM food_logs WHERE consumed_date='2026-10-20'").get().n;
assert.equal(retryCopyCount,2);
console.log(JSON.stringify({proof:'bulk copy returns failure after partial commit and duplicates on retry',failed,firstCopyCount,retryCopyCount}));
