// Executes the original auth modules in isolation. No network or repository changes.
// Only irrelevant language/tenancy/OIDC imports are replaced with local test doubles.
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
const root = '/workspace/health-api/src';
const writes = [];
const db = { epoch: 0, prepare(sql) { return { bind(...args) { this.args = args; return this; },
  async first() { return { session_epoch: db.epoch }; },
  async run() { if (sql.startsWith('INSERT INTO connection_credentials')) writes.push({ uid: this.args[0], provider: this.args[1] }); return { meta: { changes: 1 } }; }
}; } };
const context = vm.createContext({ console, crypto: webcrypto, TextEncoder, TextDecoder, Headers, Request, Response, URL, URLSearchParams, btoa, atob, Date, Uint8Array,
  fetch: async () => Response.json({ refresh_token: 'test-refresh-only', scope: 'test-scope' }) });
const modules = new Map();
const doubles = {
  'lang.js': { L: (cs, en) => en },
  'tenancy.js': { ensureTenancy: async () => {}, signInGoogleUser: async () => ({id: 11}), bumpSessionEpoch: async () => ++db.epoch },
  'github-oidc.js': { verifyGitHubActionsToken: async () => { throw new Error('unused'); } }
};
async function load(file) {
  const name = path.basename(file);
  if (modules.has(file)) return modules.get(file);
  let m;
  if (doubles[name]) {
    const values = doubles[name];
    m = new vm.SyntheticModule(Object.keys(values), function () { for (const [k,v] of Object.entries(values)) this.setExport(k,v); }, {context, identifier:file});
  } else {
    const source = fs.readFileSync(file,'utf8') + (name === 'google-login.js' ? '\nexport {appHandoffToken as issueForProof};' : '');
    m = new vm.SourceTextModule(source,{context,identifier:file});
  }
  modules.set(file,m);
  await m.link((specifier,ref) => load(path.resolve(path.dirname(ref.identifier),specifier)));
  return m;
}
const login = await load(path.join(root,'google-login.js'));
await login.evaluate();
const auth = modules.get(path.join(root,'dashboard-auth.js')).namespace;
const env = { DB:db, GOOGLE_CLIENT_ID:'test-client', GOOGLE_CLIENT_SECRET:'test-client-secret', SESSION_SECRET:'test-session-secret-not-real', OWNER_EMAIL:'test@example.invalid' };
const verifier = 'v'.repeat(43);
const digest = await webcrypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier));
const challenge = Buffer.from(digest).toString('base64url');
const token = await login.namespace.issueForProof(11,challenge,env.SESSION_SECRET);
const exchange = () => login.namespace.handleGoogleLogin(new Request('https://aurin.health/auth/app/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,verifier})}),env,'/auth/app/session');
const first = await exchange();
assert.equal(first.status,200);
db.epoch++;
const replay = await exchange();
const cookie = replay.headers.get('Set-Cookie').split(';')[0];
const session = await auth.verifyDashboardSession(new Request('https://aurin.health/app/api/me',{headers:{Cookie:cookie}}),env.SESSION_SECRET);
assert.equal(replay.status,200);
assert.equal(session.epoch,1);
assert.equal(auth.sessionMatchesUser({kind:'user',epoch:session.epoch},{sessionEpoch:db.epoch}),true);
console.log(JSON.stringify({proof:'handoff reuse after revocation',firstStatus:first.status,replayStatus:replay.status,newSessionEpoch:session.epoch,matchesCurrentEpoch:true}));

const oauth = await load(path.join(root,'google-oauth.js'));
await oauth.evaluate();
const start = await oauth.namespace.handleGoogleOAuth(new Request('https://aurin.health/oauth/google?consent=1&return=native'),{...env,USER_ID:11,CONNECTION_KEY:'k'.repeat(40)},'/oauth/google');
const state = new URL(start.headers.get('Location')).searchParams.get('state');
const stateCookie = start.headers.get('Set-Cookie').split(';')[0];
const result = await oauth.namespace.handleGoogleOAuth(new Request('https://aurin.health/oauth/google/callback?code=test&state='+state,{headers:{Cookie:stateCookie}}),{...env,USER_ID:22,CONNECTION_KEY:'k'.repeat(40)},'/oauth/google/callback');
assert.equal(result.status,302);
assert.deepEqual(writes.map(x=>x.uid),[22,22]);
console.log(JSON.stringify({proof:'connector callback after session changes account',startedAs:11,callbackAs:22,resultStatus:result.status,credentialsSavedFor:writes}));
