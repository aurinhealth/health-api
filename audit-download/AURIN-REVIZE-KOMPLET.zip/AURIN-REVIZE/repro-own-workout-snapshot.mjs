// Original scheduledLink/getWorkout/ownLibraryWorkout functions and real SQLite.
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
const root='/workspace/health-api/src/';
const source=name=>readFileSync(root+name,'utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const L=(cs,en)=>en;
const model=new Function('L',source('workout-model.js')+'\nreturn {buildWorkout,zoneOf,zonesFor,flattenSteps,totalMinutes};')(L);
const {ownLibraryWorkout}=new Function('L',...Object.keys(model),source('endurance-templates.js')+'\nreturn {ownLibraryWorkout};')(L,...Object.values(model));
const library=readFileSync(root+'workout-library.js','utf8');
const between=(a,b)=>library.slice(library.indexOf(a),library.indexOf(b)).replace(/\bexport /g,'');
const getSource=between('export async function getWorkout(', 'export async function getCapabilities(');
const linkSource=between('export async function scheduledLink(', 'export async function markScheduleCompleted(');
const {scheduledLink}=new Function('ownLibraryWorkout','builtInById','ensureTrainingTables',getSource+'\n'+linkSource+'\nreturn {scheduledLink};')(ownLibraryWorkout,()=>new Map(),async()=>{});
const DB=createD1(); DB.userId=3;
DB.sqlite.exec(`CREATE TABLE saved_workouts(user_id INTEGER,id TEXT,sport TEXT,name TEXT,structure_json TEXT);
CREATE TABLE workout_schedule_links(id INTEGER PRIMARY KEY,user_id INTEGER,workout_id TEXT,scheduled_date TEXT,intervals_event_id TEXT);
CREATE TABLE scheduled_event_snapshot(duration_minutes INTEGER); INSERT INTO scheduled_event_snapshot VALUES (30);`);
const structure=minutes=>JSON.stringify([{durationMinutes:minutes,power:65}]);
DB.sqlite.prepare('INSERT INTO saved_workouts VALUES (3,?,?,?,?)').run('abcdefghij','ride','Own workout',structure(30));
DB.sqlite.prepare('INSERT INTO workout_schedule_links VALUES (1,3,?,?,?)').run('own-abcdefghij','2026-10-19','local-monday');
const before=await scheduledLink(DB,'own-abcdefghij','2026-10-19'); assert.equal(before.duration_minutes,30);
// Same UPDATE as /my-workouts/:id/schedule after editing/rescheduling the template.
await DB.prepare('UPDATE saved_workouts SET structure_json=? WHERE user_id=? AND id=?').bind(structure(90),3,'abcdefghij').run();
const after=await scheduledLink(DB,'own-abcdefghij','2026-10-19'); assert.equal(after.duration_minutes,90);
console.log(JSON.stringify({oldScheduledDate:before.scheduled_date,oldEventMinutes:30,detailBefore:before.duration_minutes,detailAfterSchedulingEditedTemplate:after.duration_minutes}));
