// Run: node /workspace/aurin-review/repro-idempotency.mjs
// Uses the original handler and repository SQLite facade; no prompt modules or services.
import assert from 'node:assert/strict';
import { withIdempotency } from '../health-api/src/idempotency.js';
import { createD1 } from '../health-api/tests/helpers/d1.mjs';

const DB = createD1();
const env = { DB, USER_ID: 7 };
const url = new URL('https://app.test/app/api/fluids');
const request = () => new Request(url, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ ml: 250, requestId: 'review-pending-00001' })
});
let entered, release;
const enteredPromise = new Promise(resolve => { entered = resolve; });
const gate = new Promise(resolve => { release = resolve; });
let writes = 0;
const first = withIdempotency(request(), env, url, async () => {
  entered();
  await gate;
  return Response.json({ message: 'simulated storage failure before write' }, { status: 500 });
});
await enteredPromise;
const replay = await withIdempotency(request(), env, url, async () => {
  writes++;
  return Response.json({ status: 'ok' });
});
const replayBody = await replay.json();
assert.equal(replay.status, 200);
assert.deepEqual(replayBody, { status: 'ok', duplicate: true });
release();
const firstResponse = await first;
assert.equal(firstResponse.status, 500);
const claims = DB.sqlite.prepare('SELECT COUNT(*) AS n FROM client_requests').get().n;
assert.equal(claims, 0);
assert.equal(writes, 0);
console.log(JSON.stringify({ firstStatus: firstResponse.status, replayStatus: replay.status, replayBody, writes, claims }));
