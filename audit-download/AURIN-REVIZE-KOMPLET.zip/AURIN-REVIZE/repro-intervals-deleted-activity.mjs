// Executes original activity import function over local SQLite; provider returns an empty complete list.
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
const source=readFileSync('/workspace/health-api/src/index.js','utf8');
const start=source.indexOf('async function syncIntervalsActivities(');
const end=source.indexOf('async function syncIntervalsEvents(',start);
const original=source.slice(start,end);
const importActivities=new Function('dateDaysAgo','dateDaysFromNow','intervalsGet','sentIntervalsIds','readSyncPrefs','CONFIG',original+'\nreturn syncIntervalsActivities;')(
  ()=>'2026-10-01',()=>'2026-10-20',async()=>[],async()=>new Set(),async()=>({pullActivities:true}),{activityDays:365});
const DB=createD1();
DB.sqlite.exec('CREATE TABLE health_datapoints(user_id INTEGER,source_family TEXT,data_type TEXT,external_id TEXT,start_time TEXT,payload_json TEXT)');
DB.sqlite.prepare("INSERT INTO health_datapoints VALUES(7,'intervals','activity','activity:removed-at-provider','2026-10-19T10:00:00','{}')").run();
const result=await importActivities({DB,USER_ID:7});
const retained=DB.sqlite.prepare('SELECT COUNT(*) AS n FROM health_datapoints').get().n;
assert.equal(result.activities_found,0);
assert.equal(retained,1);
console.log(JSON.stringify({result,retainedDeletedActivityRows:retained}));
