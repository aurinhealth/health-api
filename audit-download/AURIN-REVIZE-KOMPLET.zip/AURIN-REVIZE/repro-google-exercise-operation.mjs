// Runs original activity-sync source with real local SQLite and a fake Google API.
// No repository edits, private prompt modules or external requests.
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createD1 } from '/workspace/health-api/tests/helpers/d1.mjs';
import { localDateTime } from '/workspace/health-api/src/user-time.js';
import { intervalsAuthorization } from '/workspace/health-api/src/intervals-auth.js';
import { grantedExtras, hasGoogleScope, HEALTH_PERMISSIONS, HEALTH_SCOPES, EXTRA_SCOPES } from '/workspace/health-api/src/google-scopes.js';
const source = readFileSync('/workspace/health-api/src/sync-destinations.js','utf8').replace(/^import .*;\n/gm,'').replace(/\bexport /g,'');
const functions = new Function('L','localDateTime','intervalsAuthorization','grantedExtras','hasGoogleScope','HEALTH_PERMISSIONS',source+'\nreturn {sendActivity,saveSyncPrefs};')((cs,en)=>en,localDateTime,intervalsAuthorization,grantedExtras,hasGoogleScope,HEALTH_PERMISSIONS);
const DB=createD1();
await functions.saveSyncPrefs(DB,7,'google',{pushActivities:true});
const env={DB,USER_ID:7,GOOGLE_REFRESH_TOKEN:'test-only',GOOGLE_SCOPES:[...HEALTH_SCOPES,EXTRA_SCOPES.activityWrite]};
const calls=[];
const fetchImpl=async(url,options={})=>{calls.push({url:String(url),method:options.method||'GET'});return Response.json({name:'operations/exercise-'+calls.length,done:false});};
const activity={key:'gym:2026-10-19',sport:'gym',name:'Gym',date:'2026-10-19',start:'2026-10-19T10:00:00Z',minutes:45};
const first=await functions.sendActivity(env,activity,{fetchImpl,googleToken:async()=>'test-token'});
const edited=await functions.sendActivity(env,{...activity,minutes:50},{fetchImpl,googleToken:async()=>'test-token'});
assert.equal(first.sends[0].status,'sent');
assert.equal(first.sends[0].remoteId,'operations/exercise-1');
assert.deepEqual(calls.map(c=>c.method),['POST','POST']);
assert.equal(edited.sends[0].remoteId,'operations/exercise-2');
console.log(JSON.stringify({first:first.sends[0],edited:edited.sends[0],calls}));
